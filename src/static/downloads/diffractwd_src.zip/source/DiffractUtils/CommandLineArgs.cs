﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/


using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace UtilsWD
{
    public class CommandLineArgs
    {
        private static List<string> _requestedFileList = null;
        private static List<string> _parameterList = null;
        private static List<string> requestedFileList
        {
            get 
            {
                if (_requestedFileList == null) Initialize();
                return _requestedFileList;
            }
        }

        private static List<string> parameterList
        {
            get
            {
                if (_parameterList == null) Initialize();
                return _parameterList;
            }
        }

        
        private static void Initialize()
        {
            _requestedFileList  = new List<string>();
            _parameterList      = new List<string>();

            string[] args = System.Environment.GetCommandLineArgs();

            foreach (string arg in args)
            {
                if (arg.Length == 0) continue;
                if (arg[0] == '-' || arg[0] == '/')
                {
                    int markerLength = 1;

                    if (arg.Length >= 2 && arg[0] == '-' && arg[1] == '-')
                    {
                        markerLength = 2;
                    }

                    _parameterList.Add(arg.Substring(markerLength).ToLower());
                }
                else
                {
                    _requestedFileList.Add(arg);
                }
            }               
        }


        public static string[] ParameterList
        {
            get
            {
                return parameterList.ToArray();
            }
        }

        public static string[] RequestedFileList
        {
            get
            {
                return requestedFileList.ToArray();
            }
        }

        public static bool ContaineParameter(string key)
        {
            return parameterList.Contains(key.ToLower());            
        }

    }
}
