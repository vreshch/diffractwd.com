﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Windows.Forms;
using ICSharpCode.Core;
using Base;
using System.Diagnostics;
using System.Threading;
using UtilsWD;


namespace Startup
{
	public static class Start
	{
        static string[] commandLineArgs = null;

        public static string[] CommandLineArgs
        {
            get
            {
                return commandLineArgs;
            }
        }
        
        [STAThread]
		public static void Main(string[] args)
		{
            //Setup Error Trap
           UnhandledExceptionDlg exDlg = new UnhandledExceptionDlg(); 
           
           //Run Application                
           Run();
		}

        static void Run()
        {
            #if DEBUG
                   Control.CheckForIllegalCrossThreadCalls = true;
            #endif

            bool noLogo = UtilsWD.CommandLineArgs.ContaineParameter("nologo"); 
 
            Application.SetCompatibleTextRenderingDefault(false);        

            if (!noLogo) SplashScreenForm.ShowSplashScreen();
            
            try
            {
                RunApplication();                
            }
            finally
            {
                if (SplashScreenForm.SplashScreen != null) SplashScreenForm.SplashScreen.Dispose();                
            }           
        }

     

        static void RunApplication()
        {            
            LoggingService.Info("Starting Application ");
            
            Assembly exe = typeof(Start).Assembly;

            FileUtility.ApplicationRootPath = Path.GetDirectoryName(exe.Location);

            LoggingService.Info("Starting core services...");

            CoreStartup coreStartup = new CoreStartup("DiffractWD");

            coreStartup.PropertiesName = "AppProperties";

            coreStartup.StartCoreServices();

            ResourceService.RegisterNeutralStrings(new ResourceManager("Startup.StringResources", exe));
            ResourceService.RegisterNeutralImages(new ResourceManager("Startup.ImageResources", exe));

            LoggingService.Info("Looking for AddIns...");

            coreStartup.AddAddInsFromDirectory(Path.Combine(FileUtility.ApplicationRootPath, "AddIns"));
            coreStartup.ConfigureExternalAddIns(Path.Combine(PropertyService.ConfigDirectory, "AddIns.xml"));
            coreStartup.ConfigureUserAddIns(Path.Combine(PropertyService.ConfigDirectory, "AddInInstallTemp"), Path.Combine(PropertyService.ConfigDirectory, "AddIns"));


            foreach (string parameter in UtilsWD.CommandLineArgs.ParameterList)
            {
                if (parameter.StartsWith("addindir:", StringComparison.OrdinalIgnoreCase))
                {
                    coreStartup.AddAddInsFromDirectory(parameter.Substring(9));
                }
            }
            

            LoggingService.Info("Loading AddInTree...");
            coreStartup.RunInitialization();


            LoggingService.Info("Initializing Workbench...");                                 
            Workbench.Instance.Initialize();

            // Show SplashScreenForm
            if (SplashScreenForm.SplashScreen != null)
            {
                SplashScreenForm.SplashScreen.BeginInvoke(new MethodInvoker(SplashScreenForm.SplashScreen.Dispose));
                SplashScreenForm.SplashScreen = null;
            }


            LoggingService.Info("Loading Command List Files...");  
            // Load Files From Command Prompt
            int i = 0;
            foreach (string file in UtilsWD.CommandLineArgs.RequestedFileList)
            {
                i++; if (i == 1) continue; // Skip File - its Application Name
                if (File.Exists(file))
                {
                    ProjectService.IsSupportedFileType(Path.GetExtension(file));
                    {
                        ProjectService.LoadFile(Workbench.Instance, file);
                    }
                }
            }

            try
            {
                LoggingService.Info("Running Event :: OnBeforeLoad...");                                
                foreach (AbstractCommand beforeloadevent in  AddInTree.BuildItems("/Workspace/OnBeforeLoad",null,false))
                {
                    beforeloadevent.Run();
                }

                LoggingService.Info("Running application...");
                Application.Run(Workbench.Instance);


                LoggingService.Info("Running Event :: OnAfterLoad...");
                foreach (AbstractCommand afterloadevent in AddInTree.BuildItems("/Workspace/OnAfterLoad", null, false))
                {
                    afterloadevent.Run();
                }

            }
            //  Save setings of the application                        
            finally
            {
                try
                {
                    // Save changed properties
                    PropertyService.Save();
                }
                catch (Exception ex)
                {
                    MessageService.ShowError(ex, "Error storing properties");
                }
            }

            LoggingService.Info("Application shutdown");
        }

	}
}
