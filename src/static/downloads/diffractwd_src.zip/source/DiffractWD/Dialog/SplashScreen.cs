﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/


using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Startup
{
    public class SplashScreenForm : Form
    {
        public const string VersionText = "DiffractWD " + RevisionClass.FullVersion;

        static SplashScreenForm splashScreen;
        static List<string> requestedFileList = new List<string>();
        static List<string> parameterList = new List<string>();
        Bitmap bitmap;

        public static SplashScreenForm SplashScreen
        {
            get
            {
                return splashScreen;
            }
            set
            {
                splashScreen = value;
            }
        }

        public SplashScreenForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ShowInTaskbar = false;
            
            #if DEBUG
            string versionText = VersionText + " (debug)";
            
            #else
			string versionText = VersionText;
            #endif


            // Stream must be kept open for the lifetime of the bitmap            
            System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
            string[] n = thisExe.GetManifestResourceNames();
            System.IO.Stream fStream = thisExe.GetManifestResourceStream("Startup.data.logo.png");
            Bitmap bitmap = new Bitmap(fStream);

            this.ClientSize = bitmap.Size;

            using (Font font = new Font("Sans Serif", 12))
            {
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    g.DrawString(versionText, font, Brushes.Black, 100, 162);
                }
            }
            BackgroundImage = bitmap;
        }

        public static void ShowSplashScreen()
        {
            splashScreen = new SplashScreenForm();
            splashScreen.Show();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (bitmap != null)
                {
                    bitmap.Dispose();
                    bitmap = null;
                }
            }
            base.Dispose(disposing);
        }
                

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SplashScreenForm));
            this.SuspendLayout();
            // 
            // SplashScreenForm
            // 
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SplashScreenForm";
            this.ResumeLayout(false);

        }
    }
}
