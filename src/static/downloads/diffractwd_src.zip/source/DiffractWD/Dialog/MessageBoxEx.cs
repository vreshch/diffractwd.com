﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Resources;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace Startup
{
    /// <summary>
    /// An extended MessageBox with lot of customizing capabilities.
    /// </summary>
    public class MessageBoxEx
    {
        #region Fields
        private MessageBoxExForm _msgBox = new MessageBoxExForm();

        private bool _useSavedResponse = true;
        private string _name = null;
        #endregion

        #region Properties
        internal string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        /// <summary>
        /// Sets the caption of the message box
        /// </summary>
        public string Caption
        {
            set { _msgBox.Caption = value; }
        }

        /// <summary>
        /// Sets the text of the message box
        /// </summary>
        public string Text
        {
            set { _msgBox.Message = value; }
        }

        /// <summary>
        /// Sets the icon to show in the message box
        /// </summary>
        public Icon CustomIcon
        {
            set { _msgBox.CustomIcon = value; }
        }

        /// <summary>
        /// Sets the icon to show in the message box
        /// </summary>
        public MessageBoxExIcon Icon
        {
            set { _msgBox.StandardIcon = (MessageBoxIcon)Enum.Parse(typeof(MessageBoxIcon), value.ToString()); }
        }


        public bool ResponseCheckBox
        {
            set
            {
                _msgBox.chbSaveResponse.Checked = value;
            }
            get
            {
                return _msgBox.chbSaveResponse.Checked;
            }
        }

        /// <summary>
        /// Sets the font for the text of the message box
        /// </summary>
        public Font Font
        {
            set { _msgBox.Font = value; }
        }

        /// <summary>
        /// Sets or Gets the ability of the  user to save his/her response
        /// </summary>
        public bool AllowSaveResponse
        {
            get { return _msgBox.AllowSaveResponse; }
            set { _msgBox.AllowSaveResponse = value; }
        }

        /// <summary>
        /// Sets the text to show to the user when saving his/her response
        /// </summary>
        public string SaveResponseText
        {
            set { _msgBox.SaveResponseText = value; }
        }

        /// <summary>
        /// Sets or Gets wether the saved response if available should be used
        /// </summary>
        public bool UseSavedResponse
        {
            get { return _useSavedResponse; }
            set { _useSavedResponse = value; }
        }

        /// <summary>
        /// Sets or Gets wether an alert sound is played while showing the message box.
        /// The sound played depends on the the Icon selected for the message box
        /// </summary>
        public bool PlayAlsertSound
        {
            get { return _msgBox.PlayAlertSound; }
            set { _msgBox.PlayAlertSound = value; }
        }

        /// <summary>
        /// Sets or Gets the time in milliseconds for which the message box is displayed.
        /// </summary>
        public int Timeout
        {
            get { return _msgBox.Timeout; }
            set { _msgBox.Timeout = value; }
        }

        /// <summary>
        /// Controls the result that will be returned when the message box times out.
        /// </summary>
        public TimeoutResult TimeoutResult
        {
            get { return _msgBox.TimeoutResult; }
            set { _msgBox.TimeoutResult = value; }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Shows the message box
        /// </summary>
        /// <returns></returns>
        public string Show()
        {
            return Show(null);
        }

        /// <summary>
        /// Shows the messsage box with the specified owner
        /// </summary>
        /// <param name="owner"></param>
        /// <returns></returns>
        public string Show(IWin32Window owner)
        {
            if (_useSavedResponse && this.Name != null)
            {
                string savedResponse = MessageBoxExManager.GetSavedResponse(this);
                if (savedResponse != null)
                    return savedResponse;
            }

            if (owner == null)
            {
                _msgBox.ShowDialog();
            }
            else
            {
                _msgBox.ShowDialog(owner);
            }

            if (this.Name != null)
            {
                if (_msgBox.AllowSaveResponse && _msgBox.SaveResponse)
                    MessageBoxExManager.SetSavedResponse(this, _msgBox.Result);
                else
                    MessageBoxExManager.ResetSavedResponse(this.Name);
            }
            else
            {
                Dispose();
            }

            return _msgBox.Result;
        }

        /// <summary>
        /// Add a custom button to the message box
        /// </summary>
        /// <param name="button">The button to add</param>
        public void AddButton(MessageBoxExButton button)
        {
            if (button == null)
                throw new ArgumentNullException("button", "A null button cannot be added");

            _msgBox.Buttons.Add(button);

            if (button.IsCancelButton)
            {
                _msgBox.CustomCancelButton = button;
            }
        }

        /// <summary>
        /// Add a custom button to the message box
        /// </summary>
        /// <param name="text">The text of the button</param>
        /// <param name="val">The return value in case this button is clicked</param>
        public void AddButton(string text, string val)
        {
            if (text == null)
                throw new ArgumentNullException("text", "Text of a button cannot be null");

            if (val == null)
                throw new ArgumentNullException("val", "Value of a button cannot be null");

            MessageBoxExButton button = new MessageBoxExButton();
            button.Text = text;
            button.Value = val;

            AddButton(button);
        }

        /// <summary>
        /// Add a standard button to the message box
        /// </summary>
        /// <param name="buttons">The standard button to add</param>
        public void AddButton(MessageBoxExButtons button)
        {
            string buttonText = MessageBoxExManager.GetLocalizedString(button.ToString());
            if (buttonText == null)
            {
                buttonText = button.ToString();
            }

            string buttonVal = button.ToString();

            MessageBoxExButton btn = new MessageBoxExButton();
            btn.Text = buttonText;
            btn.Value = buttonVal;

            if (button == MessageBoxExButtons.Cancel)
            {
                btn.IsCancelButton = true;
            }

            AddButton(btn);
        }

        /// <summary>
        /// Add standard buttons to the message box.
        /// </summary>
        /// <param name="buttons">The standard buttons to add</param>
        public void AddButtons(MessageBoxButtons buttons)
        {
            switch (buttons)
            {
                case MessageBoxButtons.OK:
                    AddButton(MessageBoxExButtons.Ok);
                    break;

                case MessageBoxButtons.AbortRetryIgnore:
                    AddButton(MessageBoxExButtons.Abort);
                    AddButton(MessageBoxExButtons.Retry);
                    AddButton(MessageBoxExButtons.Ignore);
                    break;

                case MessageBoxButtons.OKCancel:
                    AddButton(MessageBoxExButtons.Ok);
                    AddButton(MessageBoxExButtons.Cancel);
                    break;

                case MessageBoxButtons.RetryCancel:
                    AddButton(MessageBoxExButtons.Retry);
                    AddButton(MessageBoxExButtons.Cancel);
                    break;

                case MessageBoxButtons.YesNo:
                    AddButton(MessageBoxExButtons.Yes);
                    AddButton(MessageBoxExButtons.No);
                    break;

                case MessageBoxButtons.YesNoCancel:
                    AddButton(MessageBoxExButtons.Yes);
                    AddButton(MessageBoxExButtons.No);
                    AddButton(MessageBoxExButtons.Cancel);
                    break;
            }
        }
        #endregion

        #region Ctor
        /// <summary>
        /// Ctor is internal because this can only be created by MBManager
        /// </summary>
        internal MessageBoxEx()
        {
        }

        /// <summary>
        /// Called by the manager when it is disposed
        /// </summary>
        internal void Dispose()
        {
            if (_msgBox != null)
            {
                _msgBox.Dispose();
            }
        }
        #endregion
    }

    /// <summary>
    /// Internal DataStructure used to represent a button
    /// </summary>
    public class MessageBoxExButton
    {
        private string _text = null;
        /// <summary>
        /// Gets or Sets the text of the button
        /// </summary>
        public string Text
        {
            get { return _text; }
            set { _text = value; }
        }

        private string _value = null;
        /// <summary>
        /// Gets or Sets the return value when this button is clicked
        /// </summary>
        public string Value
        {
            get { return _value; }
            set { _value = value; }
        }

        private string _helpText = null;
        /// <summary>
        /// Gets or Sets the tooltip that is displayed for this button
        /// </summary>
        public string HelpText
        {
            get { return _helpText; }
            set { _helpText = value; }
        }

        private bool _isCancelButton = false;
        /// <summary>
        /// Gets or Sets wether this button is a cancel button. i.e. the button
        /// that will be assumed to have been clicked if the user closes the message box
        /// without pressing any button.
        /// </summary>
        public bool IsCancelButton
        {
            get { return _isCancelButton; }
            set { _isCancelButton = value; }
        }
    }

    /// <summary>
    /// Standard MessageBoxEx buttons
    /// </summary>
    public enum MessageBoxExButtons
    {
        Ok = 0,
        Cancel = 1,
        Yes = 2,
        No = 4,
        Abort = 8,
        Retry = 16,
        Ignore = 32
    }
    /// <summary>
    /// Standard MessageBoxEx icons
    /// </summary>
    public enum MessageBoxExIcon
    {
        None,
        Asterisk,
        Error,
        Exclamation,
        Hand,
        Information,
        Question,
        Stop,
        Warning
    }



    /// <summary>
    /// Manages a collection of MessageBoxes. Basically manages the
    /// saved response handling for messageBoxes.
    /// </summary>
    public class MessageBoxExManager
    {
        #region Fields
        private static Hashtable _messageBoxes = new Hashtable();
        private static Hashtable _savedResponses = new Hashtable();

        private static Hashtable _standardButtonsText = new Hashtable();
        #endregion

        #region Static ctor
        static MessageBoxExManager()
        {
            /*
            try
            {
                Assembly current = typeof(MessageBoxExManager).Assembly;
                string[] resources = current.GetManifestResourceNames();
                ResourceManager rm = new ResourceManager("Utils.MessageBoxExLib.Resources.StandardButtonsText", typeof(MessageBoxExManager).Assembly);
                _standardButtonsText[MessageBoxExButtons.Ok.ToString()] = rm.GetString("Ok");
                _standardButtonsText[MessageBoxExButtons.Cancel.ToString()] = rm.GetString("Cancel");
                _standardButtonsText[MessageBoxExButtons.Yes.ToString()] = rm.GetString("Yes");
                _standardButtonsText[MessageBoxExButtons.No.ToString()] = rm.GetString("No");
                _standardButtonsText[MessageBoxExButtons.Abort.ToString()] = rm.GetString("Abort");
                _standardButtonsText[MessageBoxExButtons.Retry.ToString()] = rm.GetString("Retry");
                _standardButtonsText[MessageBoxExButtons.Ignore.ToString()] = rm.GetString("Ignore");
            }
            catch (Exception ex)
            {
             */
            //System.Diagnostics.Debug.Assert(false, "Unable to load resources for MessageBoxEx", ex.ToString());

            //Load default resources
            _standardButtonsText[MessageBoxExButtons.Ok.ToString()] = "Ok";
            _standardButtonsText[MessageBoxExButtons.Cancel.ToString()] = "Cancel";
            _standardButtonsText[MessageBoxExButtons.Yes.ToString()] = "Yes";
            _standardButtonsText[MessageBoxExButtons.No.ToString()] = "No";
            _standardButtonsText[MessageBoxExButtons.Abort.ToString()] = "Abort";
            _standardButtonsText[MessageBoxExButtons.Retry.ToString()] = "Retry";
            _standardButtonsText[MessageBoxExButtons.Ignore.ToString()] = "Ignore";
            /*
            }
             */
        }
        #endregion

        #region Methods
        /// <summary>
        /// Creates a new message box with the specified name. If null is specified
        /// in the message name then the message box is not managed by the Manager and
        /// will be disposed automatically after a call to Show()
        /// </summary>
        /// <param name="name">The name of the message box</param>
        /// <returns>A new message box</returns>
        public static MessageBoxEx CreateMessageBox(string name)
        {
            if (name != null && _messageBoxes.ContainsKey(name))
            {
                string err = string.Format("A MessageBox with the name {0} already exists.", name);
                throw new ArgumentException(err, "name");
            }

            MessageBoxEx msgBox = new MessageBoxEx();
            msgBox.Name = name;
            if (msgBox.Name != null)
            {
                _messageBoxes[name] = msgBox;
            }

            return msgBox;
        }

        /// <summary>
        /// Gets the message box with the specified name
        /// </summary>
        /// <param name="name">The name of the message box to retrieve</param>
        /// <returns>The message box with the specified name or null if a message box
        /// with that name does not exist</returns>
        public static MessageBoxEx GetMessageBox(string name)
        {
            if (_messageBoxes.Contains(name))
            {
                return _messageBoxes[name] as MessageBoxEx;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Deletes the message box with the specified name
        /// </summary>
        /// <param name="name">The name of the message box to delete</param>
        public static void DeleteMessageBox(string name)
        {
            if (name == null)
                return;

            if (_messageBoxes.Contains(name))
            {
                MessageBoxEx msgBox = _messageBoxes[name] as MessageBoxEx;
                msgBox.Dispose();
                _messageBoxes.Remove(name);
            }
        }
        /*
        public static void WriteSavedResponses(Stream stream)
        {
            throw new NotImplementedException("This feature has not yet been implemented");
        }

        public static void ReadSavedResponses(Stream stream)
        {
            throw new NotImplementedException("This feature has not yet been implemented");
        }
        */

        /// <summary>
        /// Reset the saved response for the message box with the specified name.
        /// </summary>
        /// <param name="messageBoxName">The name of the message box whose response is to be reset.</param>
        public static void ResetSavedResponse(string messageBoxName)
        {
            if (messageBoxName == null)
                return;

            if (_savedResponses.ContainsKey(messageBoxName))
            {
                _savedResponses.Remove(messageBoxName);
            }
        }

        /// <summary>
        /// Resets the saved responses for all message boxes that are managed by the manager.
        /// </summary>
        public static void ResetAllSavedResponses()
        {
            _savedResponses.Clear();
        }
        #endregion

        #region Internal Methods
        /// <summary>
        /// Set the saved response for the specified message box
        /// </summary>
        /// <param name="msgBox">The message box whose response is to be set</param>
        /// <param name="response">The response to save for the message box</param>
        internal static void SetSavedResponse(MessageBoxEx msgBox, string response)
        {
            if (msgBox.Name == null)
                return;

            _savedResponses[msgBox.Name] = response;
        }

        /// <summary>
        /// Gets the saved response for the specified message box
        /// </summary>
        /// <param name="msgBox">The message box whose saved response is to be retrieved</param>
        /// <returns>The saved response if exists, null otherwise</returns>
        internal static string GetSavedResponse(MessageBoxEx msgBox)
        {
            string msgBoxName = msgBox.Name;
            if (msgBoxName == null)
            {
                return null;
            }

            if (_savedResponses.ContainsKey(msgBoxName))
            {
                return _savedResponses[msgBox.Name].ToString();
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Returns the localized string for standard button texts like,
        /// "Ok", "Cancel" etc.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        internal static string GetLocalizedString(string key)
        {
            if (_standardButtonsText.ContainsKey(key))
            {
                return (string)_standardButtonsText[key];
            }
            else
            {
                return null;
            }
        }
        #endregion
    }


    /// <summary>
    /// Standard MessageBoxEx results
    /// </summary>
    public struct MessageBoxExResult
    {
        public const string Ok = "Ok";
        public const string Cancel = "Cancel";
        public const string Yes = "Yes";
        public const string No = "No";
        public const string Abort = "Abort";
        public const string Retry = "Retry";
        public const string Ignore = "Ignore";
        public const string Timeout = "Timeout";
    }

    /// <summary>
    /// Enumerates the kind of results that can be returned when a
    /// message box times out
    /// </summary>
    public enum TimeoutResult
    {
        /// <summary>
        /// On timeout the value associated with the default button is set as the result.
        /// This is the default action on timeout.
        /// </summary>
        Default,

        /// <summary>
        /// On timeout the value associated with the cancel button is set as the result. If
        /// the messagebox does not have a cancel button then the value associated with 
        /// the default button is set as the result.
        /// </summary>
        Cancel,

        /// <summary>
        /// On timeout MessageBoxExResult.Timeout is set as the result.
        /// </summary>
        Timeout
    }



}
