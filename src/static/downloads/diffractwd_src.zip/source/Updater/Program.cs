﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

/*-------------------------------------------------------------------
This code is based on :
Downloading updates in Windows Form application
http://www.codeproject.com/KB/IP/ApplicationUpdate.aspx
and  http://mensagemweb.googlecode.com/svn/ (2005-2007 Felipe Almeida Lessa )
---------------------------------------------------------------------*/


using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Updater
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
          #if DEBUG
            Application.Run(new AutoUpdate("0", "http://diffractwd.com/update.php"));
          #else    
            
            if (args.Length > 0)
            {
                Application.Run(new AutoUpdate(args[0], args[1]));
            }
            else
            {
                MessageBox.Show("Can't run program directly");
            }
         #endif
        }
    }
}
