﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
This code is based on :
Downloading updates in Windows Form application
http://www.codeproject.com/KB/IP/ApplicationUpdate.aspx
and  http://mensagemweb.googlecode.com/svn/ (2005-2007 Felipe Almeida Lessa )
-----------------------------------------------------------------------------*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Xml;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Diagnostics;
using Ionic.Zip;

/* using Ionic.Zip; */

namespace Updater
{

    public partial class AutoUpdate : Form
    {
        private string applicationProcessID;
        private Uri remoteUri;

        // update information
        private string updateVersion;
        private string updateComments;
        private long updateFileSize = 0;
        private Uri updateLocation;


        private long totalBytesReceived;

        private string targetApplicationFullpath;

        private int GetProcessID()
        {
            int value = 0;
            try
            {
                value = Convert.ToInt32(applicationProcessID);
            }
            catch (Exception)
            {
            }
            return value;
        }


        public AutoUpdate(string applicationProcessID, string remoteUrl)
        {
            InitializeComponent();

            try
            {
                this.applicationProcessID = applicationProcessID;
                this.remoteUri = new Uri(remoteUrl);

                //				using(System.IO.StreamWriter writer = new StreamWriter(@"c:\\version.txt",true))
                //				{
                //					writer.Write(applicationProcessID);
                //					writer.Write(remoteObjectUri);
                //				}
            }
            catch (Exception)
            { }
        }

        private void AutoUpdate_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            timer.Enabled = true;
            this.Focus();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            this.Focus();
            timer.Enabled = false;
            System.Threading.Thread th = new System.Threading.Thread(new System.Threading.ThreadStart(RunUpdateProcess));
            th.Start();
        }

        private bool ConnectRemoteServer()
        {
            //_updateList = new UpdateInfoList();
            XmlDocument doc = new XmlDocument();
            try
            {
                Stream strm = GetXMLStream(remoteUri);
                using (strm)
                {
                    doc.Load(strm);
                }
            }
            catch { throw; }

            XmlNodeList XupdateVersion = doc.SelectNodes("//UpdateInfo/Version");
            if (XupdateVersion.Count == 0) throw new Exception("Incorect server responce");
            updateVersion = XupdateVersion[0].InnerText;

            XmlNodeList XupdateComments = doc.SelectNodes("//UpdateInfo/Comments");
            if (XupdateComments.Count == 0) throw new Exception("Incorect server responce");
            updateComments = XupdateComments[0].InnerText;

            XmlNodeList XupdateFileSize = doc.SelectNodes("//UpdateInfo/FileSize");
            if (XupdateFileSize.Count == 0) throw new Exception("Incorect server responce");
            updateFileSize = Convert.ToInt64(XupdateFileSize[0].InnerText);

            XmlNodeList XupdateLocation = doc.SelectNodes("//UpdateInfo/Location");
            if (XupdateLocation.Count == 0) throw new Exception("Incorect server responce");
            updateLocation = new Uri(XupdateLocation[0].InnerText);

            //UpdateInfo Info = new UpdateInfo(updateFileSize, updateLocation, updateComments, updateVersion);

            return true;
        }

        private void UpdateFiles()
        {
            string targetDir = targetApplicationFullpath.Substring(0, targetApplicationFullpath.LastIndexOf("\\"));
            string tempFile = Path.Combine(targetDir, "update.zip");
            if (File.Exists(tempFile)) { File.Delete(tempFile); }
            DownloadFile(this.updateLocation, tempFile);

            // Unzip here
            int j = 0;
            string zipToUnpack = tempFile;
            string unpackDirectory = targetDir;
            using (ZipFile zip1 = ZipFile.Read(zipToUnpack))
            {
                // here, we extract every entry, but we could extract conditionally
                // based on entry name, size, date, checkbox status, etc.  

                foreach (Ionic.Zip.ZipEntry e in zip1)
                {
                    e.Extract(unpackDirectory, ExtractExistingFileAction.OverwriteSilently);
                    j++;
                    double val = (((j * 1.0) / zip1.Count) * 15.0) + 85.0;
                    if (val > 100) { val = 100; }
                    SetControlPropertyValue(this.progressBar1, "value", (int)val);
                }
            }

            if (File.Exists(tempFile)) { File.Delete(tempFile); }
        }
        /*
        private void UpdateProgres()
        {
            if (updateFileSize == 0) return;            
            this.progressBar1.Value = (int)((totalBytesReceived / updateFileSize) * 100);
        }
         */

        private void DownloadFile(Uri Location, string filename)
        {
            HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(Location);
            req.UserAgent = string.Format(".NET", this.GetType().Assembly.GetName().Version.ToString());
            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();

            string dispHeader = resp.GetResponseHeader("Content-Disposition");

            string fileName;
            if (!string.IsNullOrEmpty(dispHeader))
            {
                string[] ts = dispHeader.Split(new char[] { '=' }, 2);
                if (ts.Length == 2 && !string.IsNullOrEmpty(ts[1])) fileName = ts[1];
            }

            if (resp.ContentLength > 0)

                updateFileSize = resp.ContentLength;
            FileInfo tempFile = new FileInfo(filename);

            Stream strm = resp.GetResponseStream();
            byte[] buffer = new byte[1024];
            int i = 0;


            FileStream fs = new FileStream(tempFile.FullName, FileMode.CreateNew, FileAccess.Write);
            using (fs)
            {
                using (strm)
                {
                    while ((i = strm.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        totalBytesReceived += i;
                        SetControlPropertyValue(this.progressBar1, "value", (int)((totalBytesReceived / updateFileSize) * 70) + 15);
                        fs.Write(buffer, 0, i);
                    }
                }
            }
        }

        delegate void SetControlValueCallback(Control oControl, string propName, object propValue);
        private void SetControlPropertyValue(Control oControl, string propName, object propValue)
        {
            if (oControl.InvokeRequired)
            {
                SetControlValueCallback d = new SetControlValueCallback(SetControlPropertyValue);
                oControl.Invoke(d, new object[] { oControl, propName, propValue });
            }
            else
            {
                Type t = oControl.GetType();
                PropertyInfo[] props = t.GetProperties();
                foreach (PropertyInfo p in props)
                {
                    if (p.Name.ToUpper() == propName.ToUpper())
                    {
                        p.SetValue(oControl, propValue, null);
                    }
                }
            }
        }


        /// <summary>
        /// Gets the XML stream.
        /// </summary>
        private Stream GetXMLStream(Uri uri)
        {
            HttpWebRequest req = HttpWebRequest.Create(uri) as HttpWebRequest;
            //req.Proxy = CCNetConfig.Core.Util.UserSettings.UpdateSettings.ProxySettings.CreateProxy();
            req.UserAgent = string.Format(".NET", this.GetType().Assembly.GetName().Version.ToString());
            HttpWebResponse resp = req.GetResponse() as HttpWebResponse;
            return resp.GetResponseStream();
        }

        private void RunUpdateProcess()
        {
#if DEBUG
            targetApplicationFullpath = @"D:\hobby\c_sharp\powder_patern\diffractWD\bin\diffractWD.exe";
            if (!ConnectRemoteServer()) return;
            UpdateFiles();

            Process launch = new Process();
            launch.StartInfo = new ProcessStartInfo(targetApplicationFullpath);
            launch.Start();

            //System.Diagnostics.Process.Start(targetApplicationFullpath);

            Application.Exit();
#else

            Process applicationProcess = Process.GetProcessById(GetProcessID());
            if (applicationProcess == null) return;
            targetApplicationFullpath = applicationProcess.MainModule.FileName;

            applicationProcess.Kill();
            applicationProcess.WaitForExit();

            if (!ConnectRemoteServer()) return;
            UpdateFiles();

            Process launch = new Process();
            launch.StartInfo = new ProcessStartInfo(targetApplicationFullpath);
            launch.Start();


            //System.Diagnostics.Process.Start(targetApplicationFullpath);

            Application.Exit();
#endif
        }
    }
}
