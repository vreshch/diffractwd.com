﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Windows.Forms;
/*
Code from:  http://en.csharp-online.net/HTTP_Post 
*/
namespace UtilsWD
{
    public class Utils
    {
        static public string Version
        {
            get
            {
                string ver = Application.ProductVersion;
                string[] v = ver.Split('.');
                return v[0] + "." + v[1];
            }
        }
        static public string ProductFullName
        {
            get
            {
                return Application.ProductName + " " + Version;
            }
        }
        public static string HttpPost(string uri, string parameters)
        {
            // parameters: name1=value1&name2=value2	
            WebRequest webRequest = WebRequest.Create(uri);
            ((HttpWebRequest)webRequest).UserAgent = ".NET Framework";
            webRequest.ContentType = "application/x-www-form-urlencoded";

            webRequest.Method = "POST";
            byte[] bytes = Encoding.ASCII.GetBytes(parameters);


            Stream os = null;
            try
            { // send the Post
                webRequest.ContentLength = bytes.Length;   //Count bytes to send
                os = webRequest.GetRequestStream();
                os.Write(bytes, 0, bytes.Length);         //Send it
            }
            //catch (WebException ex)
            //{
            //    MessageBox.Show(ex.Message, "HttpPost: Request error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            finally
            {
                if (os != null)
                {
                    os.Close();
                }
            }

            //try
            //{ // get the response
            WebResponse webResponse = webRequest.GetResponse();
            if (webResponse == null)
            { return null; }
            StreamReader sr = new StreamReader(webResponse.GetResponseStream());
            return sr.ReadToEnd().Trim();
            //}
            //catch (WebException ex)
            //{
            // MessageBox.Show(ex.Message, "HttpPost: Response error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            // return null;
        } // end HttpPost
    }
}
