﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/


/*-------------------------------------------------------------------
This code is based on :
Downloading updates in Windows Form application
http://www.codeproject.com/KB/IP/ApplicationUpdate.aspx
and  http://mensagemweb.googlecode.com/svn/ (2005-2007 Felipe Almeida Lessa )
---------------------------------------------------------------------*/


using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Xml;
using System.IO;

using System.Diagnostics;
using System.Net;

namespace Updater
{
    /// <summary>
    ///		Utility that provides update functionalities
    /// </summary>
    public class UpdateUtil
    {
        // update information
        private string updateVersion;
        public string updateVersion_udapted;
        private string updateComments;
        private long updateFileSize = 0;
        private Uri updateLocation;
        private bool update_available = false;

        /// <summary>
        /// 
        /// </summary>
        private string remoteObjectUri = string.Empty;

        private string applicationName;

        public UpdateUtil(string remoteObjectUri)
        {
            this.remoteObjectUri = remoteObjectUri;
        }

        public bool ConnectRemoteServer()
        {
            //_updateList = new UpdateInfoList();
            XmlDocument doc = new XmlDocument();
            try
            {
                Stream strm = GetXMLStream(new Uri(remoteObjectUri));
                using (strm)
                {
                    doc.Load(strm);
                }
            }
            catch (Exception) 
            {
                return false; 
            }

            XmlNodeList XupdateVersion = doc.SelectNodes("//UpdateInfo/Version");
            if (XupdateVersion.Count == 0) throw new Exception("Incorect server responce");
            updateVersion = XupdateVersion[0].InnerText;
            string[] str = updateVersion.Split('.');
            updateVersion_udapted = str[0] + '.' + str[1];


            XmlNodeList XupdateComments = doc.SelectNodes("//UpdateInfo/Comments");
            if (XupdateComments.Count == 0) throw new Exception("Incorect server responce");
            updateComments = XupdateComments[0].InnerText;

            XmlNodeList XupdateFileSize = doc.SelectNodes("//UpdateInfo/FileSize");
            if (XupdateFileSize.Count == 0) throw new Exception("Incorect server responce");
            updateFileSize = Convert.ToInt64(XupdateFileSize[0].InnerText);

            XmlNodeList XupdateLocation = doc.SelectNodes("//UpdateInfo/Location");
            if (XupdateLocation.Count == 0) throw new Exception("Incorect server responce");
            updateLocation = new Uri(XupdateLocation[0].InnerText);

            //UpdateInfo Info = new UpdateInfo(updateFileSize, updateLocation, updateComments, updateVersion);

            return true;
        }

        /// <summary>
        /// Gets the XML stream.
        /// </summary>
        /// 
        private Stream GetXMLStream(Uri uri)
        {
            HttpWebRequest req = HttpWebRequest.Create(uri) as HttpWebRequest;
            // Set Time Out - 150 ms; 
            req.Timeout = 750; // SET - 750ms; ::: 150 ms is not enought ( in case of slow internet)            
            req.UserAgent = string.Format(".NET", this.GetType().Assembly.GetName().Version.ToString());
            HttpWebResponse resp = req.GetResponse() as HttpWebResponse;
            return resp.GetResponseStream();
        }

        public bool UpdateAvailable()
        {
            if (update_available == true) return true;
            if (!ConnectRemoteServer()) return false;
            try
            {
                string assemblylocation = Assembly.GetExecutingAssembly().CodeBase;
                assemblylocation = assemblylocation.Substring(assemblylocation.LastIndexOf("/") + 1);
                applicationName = assemblylocation;

                AssemblyName assemblyName = Assembly.GetEntryAssembly().GetName();
                string localVersion = assemblyName.Version.ToString();

                update_available = IsUpdateNecessary(localVersion, updateVersion);
                return update_available;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message);
                update_available = false;
                return false;
            }
            //update_available = false;
            //return false;
        }

        /// <summary>
        ///		Is update needed?
        /// </summary>
        /// <param name="localVersion"></param>
        /// <param name="remoteVersion"></param>
        /// <returns></returns>
        private bool IsUpdateNecessary(string localVersion, string remoteVersion)
        {
            try
            {
                string[] loc = localVersion.Split('.');
                string[] rem = remoteVersion.Split('.');
                long rmVersion = Convert.ToInt64(rem[0]) * 10000000000 + Convert.ToInt64(rem[1]) * 100000000 + Convert.ToInt64(rem[2]) * 10000 + Convert.ToInt64(rem[3]);
                long lcVersion = Convert.ToInt64(loc[0]) * 10000000000 + Convert.ToInt64(loc[1]) * 100000000 + Convert.ToInt64(loc[2]) * 10000 + Convert.ToInt64(rem[3]);

                return lcVersion < rmVersion;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message);
            }
            return false;
        }

        /// <summary>
        ///		Update the application executable
        /// </summary>
        public void Update()
        {

            if (UpdateAvailable())
            {							// lets checkout if any update version available or not
                string updateAppPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Updater.exe");

                //	#region DEBUIG
                //	updateAppPath = Path.Combine(@"D:\Programs\AppUpdateServer\AppUpdate\bin\Debug","AppUpdate.exe");
                //	#endregion					

                Process updateProcess = new Process();
                string PocesId = Process.GetCurrentProcess().Id.ToString();
                updateProcess.StartInfo = new ProcessStartInfo(updateAppPath, PocesId + " " + remoteObjectUri);
                updateProcess.Start();

            }
        }
    }



    
     
}
