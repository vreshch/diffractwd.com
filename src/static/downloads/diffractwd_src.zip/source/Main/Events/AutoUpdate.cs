﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using UtilsWD;
using System.Windows.Forms;
using Updater;
using System.Reflection;

namespace Main
{
    class AutoUpdateEvent : AbstractCommand
    {
        public override void Run()
        {                     
            UpdateHelper.Check4Update(false, false);
        }
    }


    
    public static class UpdateHelper
    {
        public static void Check4Update(bool ForceCheck, bool ForceShowMessage)
        {
            #region --- Check for Updates ---
            string updateServerUrl = System.Configuration.ConfigurationSettings.AppSettings["updateServerUrl"];

            //Check for Updates
            bool Update_check_online = PropertyService.Get("Update_Check_Online", true);
            DateTime Update_last_check = PropertyService.Get("Update_last_check", DateTime.MinValue);

            // 
            bool NeadCheck = ForceCheck; // ForceCheck == true - check AnyWay

      
            if (NeadCheck == false)
            {
                if (Update_check_online == true)
                {
                    // Do not check again if we were checking this weak
                    if (DateTime.Now.Subtract(Update_last_check).TotalHours > 24 * 7)
                    {
                        NeadCheck = true;
                    }
                }
            }


            if (NeadCheck)
            {
                UpdateUtil UUtil = new UpdateUtil(updateServerUrl);

                if (ForceShowMessage)
                {
                    if (!UUtil.ConnectRemoteServer())
                    {
                        MessageBox.Show("Can't connect to server, try leter");
                        PropertyService.Set("Update_last_check", DateTime.Now);
                        return;
                    }
                }

 

                if (UUtil.UpdateAvailable())
                {
                    MessageBoxEx msgBox = MessageBoxExManager.CreateMessageBox(null);
                    msgBox.Caption = "Update is available";
                    msgBox.Text = "An update is available. \nWould you like update to version " + UUtil.updateVersion_udapted + " now?";
                    msgBox.AddButtons(MessageBoxButtons.YesNo);
                    msgBox.SaveResponseText = "Always preform check when starting program";
                    msgBox.AllowSaveResponse = true;
                    msgBox.ResponseCheckBox = Update_check_online;

                    msgBox.Icon = MessageBoxExIcon.Information;
                    string result = "";
                    if (Application.OpenForms.Count > 0) { result = msgBox.Show(Application.OpenForms[0]); } else { result = msgBox.Show(Application.OpenForms[0]); }

                    if (result == MessageBoxExResult.Yes)
                    { 
                        UUtil.Update();
                    }

                    if ((result == MessageBoxExResult.No) | (result == MessageBoxExResult.Yes))
                    {
                        PropertyService.Set("Update_Check_Online", msgBox.ResponseCheckBox);
                    }
                }
                else
                {
                    if (ForceShowMessage)
                    {
                        MessageBox.Show("Upadetes Checked, You have the last version");
                    }
                }
                PropertyService.Set("Update_last_check", DateTime.Now);
            }
            #endregion
        }
    }
   
}
