﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using Microsoft.Win32;
using System.Reflection;
using System.IO;
using System.Windows.Forms;
using UtilsWD;
using System.Collections;

namespace Main
{
    class FileAsociationEvent : AbstractCommand
    {
        public override void Run()
        {
            // Check only native formats
            List<string> ext = new List<string>();
            foreach (string filter in AddInTree.BuildItems("/Workspace/FileFilter", null, true))
            {
                string extention = filter.Substring(filter.IndexOf('|') + 1);
                if (!FiletypesRegistrator.IsRegisteredToWD(extention))
                {
                    ext.Add(extention);
                }                
            }
                                   
            // Run Registrator ???
            if (ext.Count != 0)
            {
                if (PropertyService.Get("Check_File_Asociation", true))
                {
                    MessageBoxEx msgBox = MessageBoxExManager.CreateMessageBox(null);
                    msgBox.Caption = "File association";

                    string[] sl = new string[ext.Count]; ext.CopyTo(sl); string extl = string.Join(",", sl);
                    
                    msgBox.Text = Utils.ProductFullName + " is not deffalut editor for its own files " + extl + ". Would you like to update file association now ?";

                    msgBox.AddButtons(MessageBoxButtons.YesNo);
                    msgBox.SaveResponseText = "Always preform check when starting program";
                    msgBox.AllowSaveResponse = true;
                    msgBox.ResponseCheckBox = PropertyService.Get("Check_File_Asociation", true);
                    msgBox.Icon = MessageBoxExIcon.Question;
                    string result = "";

                    result = msgBox.Show();

                    if (result == MessageBoxExResult.Yes)
                    {
                        
                        // Lets register them
                        foreach (string filter in AddInTree.BuildItems("/Workspace/FileFilter", null, true))
                        {
                            string extention = filter.Substring(filter.IndexOf('|') + 1);
                            string description = filter.Substring(0, (filter.IndexOf('|')));
                            description = description.Replace("(" + extention + ")", "");

                            if (!FiletypesRegistrator.IsRegisteredToWD(extention))
                            {
                                FiletypesRegistrator.RegisterToWD(extention, description);
                            }
                        }
                        



                    }




                    PropertyService.Set("Check_File_Asociation", msgBox.ResponseCheckBox);
                }
            }

        }
    }



    public static class FiletypesRegistrator
    {
        public static void RegisterToWD(string extension, string Description)
        {
            string mainExe = Assembly.GetEntryAssembly().Location;
            extension = extension.Replace(".", "").Replace("*", "");

            RegisterFiletype(extension, Description, '"' + Path.GetFullPath(mainExe) + '"' + " \"%1\"");

        }

        public static bool IsRegisteredToWD(string extension)
        {
            extension = extension.Replace(".", "").Replace("*", "");

            string openCommand = GetOpenCommand(extension);

            if (string.IsNullOrEmpty(openCommand))
                return false;

            string mainExe = Assembly.GetEntryAssembly().Location;
            return openCommand.StartsWith(mainExe) || openCommand.StartsWith('"' + mainExe);
        }

        const string explorerFileExts = @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts";

        public static bool IsRegisteredFileType(string extension)
        {
            try
            {
                using (RegistryKey key = Registry.ClassesRoot.OpenSubKey("." + extension))
                {
                    if (key != null)
                        return true;
                }
            }
            catch (System.Security.SecurityException)
            {
                // registry access might be denied
            }
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(explorerFileExts + "\\." + extension))
                {
                    if (key != null)
                        return true;
                }
            }
            catch (System.Security.SecurityException)
            {
                // registry access might be denied
            }
            return false;
        }

        public static string GetOpenProgramName(string extension)
        {
            try
            {
                string clsKeyName = null;
                using (RegistryKey extKey = Registry.LocalMachine.OpenSubKey(explorerFileExts + "\\." + extension))
                {
                    if (extKey != null)
                        clsKeyName = (string)extKey.GetValue("Progid", "");
                }
                if (clsKeyName == null)
                {
                    using (RegistryKey extKey = Registry.ClassesRoot.OpenSubKey("." + extension))
                    {
                        if (extKey != null)
                            clsKeyName = (string)extKey.GetValue("", "");
                        else return null;
                    }
                }
                return clsKeyName;
            }
            catch (System.Security.SecurityException)
            {
                // registry access might be denied
                return null;
            }
        }

        static string GetOpenCommand(string extension)
        {
            try
            {
                string clsKeyName = null;
                using (RegistryKey extKey = Registry.LocalMachine.OpenSubKey(explorerFileExts + "\\." + extension))
                {
                    if (extKey != null)
                        clsKeyName = (string)extKey.GetValue("Progid", "");
                }
                if (clsKeyName == null)
                {
                    using (RegistryKey extKey = Registry.ClassesRoot.OpenSubKey("." + extension))
                    {
                        if (extKey != null)
                            clsKeyName = (string)extKey.GetValue("", "");
                        else
                            return null;
                    }
                }
                using (RegistryKey cmdKey = Registry.ClassesRoot.OpenSubKey(clsKeyName + "\\shell\\open\\command"))
                {
                    if (cmdKey != null)
                        return (string)cmdKey.GetValue("", "");
                    else
                        return null;
                }
            }
            catch (System.Security.SecurityException)
            {
                // registry access might be denied
                return null;
            }
        }

        public static void RegisterFiletype(string extension, string description, string command)
        {
            try
            {
                RegisterFiletype(Registry.ClassesRoot, extension, description, command);
            }
            catch (UnauthorizedAccessException)
            {
                try
                {
                    RegisterFiletype(Registry.LocalMachine.CreateSubKey("Software\\Classes"), extension, description, command);
                }
                catch { }
            }
            NotifyShellAfterChanges();
        }

        static void RegisterFiletype(RegistryKey rootKey, string extension, string description, string command)
        {
            RegistryKey extKey, clsKey, openKey;
            extKey = rootKey.CreateSubKey("." + extension);
            // save previous association
            string prev = (string)extKey.GetValue("", "");
            if (prev != "" && prev != (Application.ProductName + "." + extension + "file"))
            {
                extKey.SetValue("Pre" + Application.ProductName, extKey.GetValue(""));
            }
            extKey.SetValue("", Application.ProductName + "." + extension + "file");
            extKey.Close();

            try
            {
                extKey = Registry.CurrentUser.OpenSubKey(explorerFileExts + "\\." + extension, true);
                if (extKey != null)
                {
                    extKey.DeleteValue("Progid");
                    extKey.Close();
                }
            }
            catch { }

            clsKey = rootKey.CreateSubKey(Application.ProductName + "." + extension + "file");

            clsKey.SetValue("", description);
            // this lie were changed
            clsKey.CreateSubKey("DefaultIcon").SetValue("", "\"" + Application.ExecutablePath + "\",0");
            openKey = clsKey.CreateSubKey("shell\\open\\command");
            openKey.SetValue("", command);
            openKey.Close();
            clsKey.Close();
        }

        public static void UnRegisterFiletype(string extension)
        {
            UnRegisterFiletype(extension, Registry.ClassesRoot);
            try
            {
                UnRegisterFiletype(extension, Registry.LocalMachine.CreateSubKey("Software\\Classes"));
            }
            catch { } // catch CreateSubKey(Software\Classes)-exceptions
            NotifyShellAfterChanges();
        }

        static void UnRegisterFiletype(string extension, RegistryKey root)
        {
            try
            {
                root.DeleteSubKeyTree(Application.ProductName + "." + extension + "file");
            }
            catch { }
            try
            {
                RegistryKey extKey;
                extKey = root.OpenSubKey("." + extension, true);

                // if no association return
                if (extKey == null) return;
                // if other association return too
                if ((string)extKey.GetValue("", "") != (Application.ProductName + "." + extension + "file")) return;

                // restore previous association
                string prev = (string)extKey.GetValue("Pre" + Application.ProductName, "");
                if (prev != "")
                {
                    extKey.SetValue("", prev);
                }
                extKey.Close();
                if (prev == null)
                {
                    root.DeleteSubKeyTree("." + extension);
                }
            }
            catch { }
        }

        [System.Runtime.InteropServices.DllImport("shell32.dll")]
        static extern void SHChangeNotify(int wEventId, int uFlags, IntPtr dwItem1, IntPtr dwItem2);

        /// <summary>
        /// Notify Windows explorer that shortcut icons have changed.
        /// </summary>
        static void NotifyShellAfterChanges()
        {
            const int SHCNE_ASSOCCHANGED = 0x08000000;
            const int SHCNF_IDLIST = 0x0;

            SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, IntPtr.Zero, IntPtr.Zero);
        }
    }

}
