﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using Base;

namespace Main.Commands
{
    class PrintPageSetup : AbstractMenuCommand
    {
        public override void Run()
        {
            Workbench.Instance.ActiveViewContent.PrintPageSetup();
        }
    }
}
