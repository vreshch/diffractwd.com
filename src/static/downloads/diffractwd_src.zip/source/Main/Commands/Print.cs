﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using Base;

namespace Main.Commands
{
    class Print : AbstractMenuCommand
    {
        public override void Run()
        {
            Workbench.Instance.ActiveViewContent.Print();
        }
    }
}
