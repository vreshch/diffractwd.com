﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using Base;
using System.Windows.Forms;
using System.IO;

namespace Main.Commands
{
    class ExportImage : AbstractMenuCommand
    {
        public override void Run()
        {
            Workbench.Instance.ActiveViewContent.ExportImage();

            /*
            using (SaveFileDialog dlg = new SaveFileDialog())                
            {
                dlg.Filter = "Emf Format (*.emf)|*.emf";
                dlg.DefaultExt = "*.emf";
                dlg.InitialDirectory = PropertyService.Get("ExportImageDir", "C:\\");
                
                if (dlg.ShowDialog() == DialogResult.OK)
                {     
                    Workbench.Instance.ActiveViewContent.ExportImage(dlg.FileName);
                    
                    string DirName = Path.GetDirectoryName(dlg.FileName);
                    PropertyService.Set("ExportImageDir", DirName);                    
                }
            }
             */          
        }
    }
}
