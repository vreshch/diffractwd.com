﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using System.IO;
using System.Diagnostics;
using Microsoft.Win32;

namespace Main.Commands
{
    class MailToCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            string ur = System.Configuration.ConfigurationSettings.AppSettings["mainServerUrl"];
            //string s = GetDefaultMailClientCommand();
            MailToCommand.MailTo("mailto:support@diffractwd.com?subject=DiffractWD%20User");
        }

        private static bool MailTo(string Email)
        {
            /*Todo: check for insecure URI.*/
            if (Email == null)
            {
                throw new ArgumentNullException("Email");
            }
            /*Fallback to the next method.*/
            string cmd = GetDefaultMailClientCommand();
            /*The command string looks something like:
             "C:\program files\Internet Explorer\iexplore.exe" -args -url "%1"
             * or
             * C:\PROGRA~1\MOZILL~1\FIREFOX.EXE -requestPending -osint -url "%1"
             *
             * where %1 is the URL to open.
             */
            if (!string.IsNullOrEmpty(cmd))
            {
                string exePath = null;
                string args = null;
                if (cmd[0] == '"')
                {
                    int i = cmd.IndexOf('"', 1);
                    if (i >= 1)
                    {
                        exePath = cmd.Substring(1, i - 1);
                        args = cmd.Substring(i + 1).Trim();
                    }
                }
                else
                {
                    int i = cmd.IndexOf(' ');
                    if (i >= 0)
                    {
                        exePath = cmd.Substring(0, i);
                        args = cmd.Substring(i + 1).Trim();
                    }
                    else
                    {
                        exePath = cmd;
                        args = "%1";
                    }
                }
                if (!string.IsNullOrEmpty(exePath))
                {
                    if (!File.Exists(exePath))
                    {
                        return false;
                    }
                    args = args.Replace("%1", Email);
                    try
                    {
                        Process.Start(exePath, args);
                        return true;
                    }
                    catch
                    {
                        // do nothing.
                    }
                }
            }
            return false;
        }

        static private string GetDefaultMailClientCommand()
        {
            RegistryKey key = null;
            try
            {
                /*Note that we may not have permission to open the key.*/
                key = Registry.ClassesRoot.OpenSubKey(@"mailto\shell\open\command", false);
                /*Gets default value of the key*/
                return key.GetValue(null).ToString();
            }
            catch
            {
                return null;
            }
            finally
            {
                if (key != null)
                {
                    key.Close();
                }
            }
        }
    }
}
