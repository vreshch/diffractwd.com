﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;

namespace Main.Commands
{
    class CheckUpdateCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            UpdateHelper.Check4Update(true,true);            
        }
    }
}
