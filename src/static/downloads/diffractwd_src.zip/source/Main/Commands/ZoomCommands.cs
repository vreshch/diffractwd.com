﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using Base;

namespace Main.Commands
{
        
    class ZoomDefalutCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            if (Workbench.Instance == null) return;
            if (Workbench.Instance.ActiveViewContent == null) return;
            Workbench.Instance.ActiveViewContent.SetScaleToDefalut();
        }
    }


    class ZoomInCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            if (Workbench.Instance == null) return;
            if (Workbench.Instance.ActiveViewContent == null) return;
            Workbench.Instance.ActiveViewContent.ZoomIn();
        }
    }

    
    class ZoomOutCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            if (Workbench.Instance == null) return;
            if (Workbench.Instance.ActiveViewContent == null) return;
            Workbench.Instance.ActiveViewContent.ZoomOut();
        }
    }


    class ZoomUndoCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            if (Workbench.Instance == null) return;
            if (Workbench.Instance.ActiveViewContent == null) return;
            Workbench.Instance.ActiveViewContent.ZoomUndo();
        }
    }


}
