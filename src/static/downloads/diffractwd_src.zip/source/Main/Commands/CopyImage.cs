﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing.Imaging;
using ICSharpCode.Core;
using Base;
using System.Runtime.InteropServices;
using System.Drawing;

namespace Main.Commands
{
    class CopyImage : AbstractMenuCommand
    {
        public override void Run()
        {
            Workbench.Instance.ActiveViewContent.CopyImage();
        }
    }   
}
