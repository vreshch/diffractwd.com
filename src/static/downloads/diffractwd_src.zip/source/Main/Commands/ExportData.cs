﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using Base;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Main.Commands
{
    class ExportData : AbstractMenuCommand
    {
        public override void Run()
        {
            if (Workbench.Instance.ActiveViewContent == null) return;
            if (Workbench.Instance.ActiveViewContent.Sln == null) return;

            Solution sln = Workbench.Instance.ActiveViewContent.Sln;            
            if (sln.ItemsCount == 0)
            {
                MessageService.ShowMessage("The project is Empty ");
                return;
            }

            IProjectItem current_ipi = null; // Item 2 Export

            if (sln.ItemsCount == 1)
            {
                current_ipi = sln.Items[0];
            }else 
            {
                ISelectable c = sln.SelectedItem;
                if (c==null)
                {
                    MessageService.ShowMessage("Item to Export Nead to be selelcted");
                    return;
                }else
                {
                    if (!(c is IProjectItem))
                    {
                        MessageService.ShowMessage("Select Powder pattern first");
                        return;
                    }
                    current_ipi = (c as IProjectItem);
                }                
            }

            if (current_ipi is IPowderItem)
            {
                using (SaveFileDialog dlg = new SaveFileDialog())
                {
                    dlg.Filter = "Text Data Format (*.txt)|*.txt";
                    dlg.DefaultExt = "*.txt";
                    dlg.InitialDirectory = PropertyService.Get("ExportDataDir", "C:\\");

                    if (dlg.ShowDialog() == DialogResult.OK)
                    {
                        // Wtiting Data 2 File
                        IPowderItem ipi = (IPowderItem)current_ipi;
                        double[] x = ipi.x;
                        double[] y = ipi.y;

                        using (TextWriter tw = new StreamWriter(dlg.FileName))
                        {

                            for (int i = 0; i < x.Length; i++)
                            {
                                tw.WriteLine(x[i].ToString() + "\t" + y[i].ToString());
                            }
                            tw.Close();
                        }

                        string DirName = Path.GetDirectoryName(dlg.FileName);
                        PropertyService.Set("ExportImageDir", DirName);
                    }
                }

                               
                

            }
            else if (current_ipi is IMolItem)
            {
                MessageService.ShowMessage("MolItem 2 Export");



            }
        }
    }
}
