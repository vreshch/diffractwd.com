﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using Microsoft.Win32;
using System.Diagnostics;
using System.IO;

namespace Main.Commands
{
    public class VisitWebPageCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            string ur = System.Configuration.ConfigurationSettings.AppSettings["mainServerUrl"];
            VisitWebPageCommand.Browse(new Uri(ur));
        }

        private static bool Browse(Uri uri)
        {
            /*Todo: check for insecure URI.*/
            if (uri == null)
            {
                throw new ArgumentNullException("uri");
            }
            if (!uri.IsAbsoluteUri)
            {
                throw new ArgumentException("Must be absolute.", "uri");
            }
            /*The preferred method is this.*/
            try
            {
                Process.Start(uri.OriginalString);
                return true;
            }
            catch
            {
                /*do nothing.*/
            }
            /*Fallback to the next method.*/
            string cmd = GetDefaultBrowserCommand();
            /*The command string looks something like:
             "C:\program files\Internet Explorer\iexplore.exe" -args -url "%1"
             * or
             * C:\PROGRA~1\MOZILL~1\FIREFOX.EXE -requestPending -osint -url "%1"
             *
             * where %1 is the URL to open.
             */
            if (!string.IsNullOrEmpty(cmd))
            {
                string exePath = null;
                string args = null;
                if (cmd[0] == '"')
                {
                    int i = cmd.IndexOf('"', 1);
                    if (i >= 1)
                    {
                        exePath = cmd.Substring(1, i - 1);
                        args = cmd.Substring(i + 1).Trim();
                    }
                }
                else
                {
                    int i = cmd.IndexOf(' ');
                    if (i >= 0)
                    {
                        exePath = cmd.Substring(0, i);
                        args = cmd.Substring(i + 1).Trim();
                    }
                    else
                    {
                        exePath = cmd;
                        args = "%1";
                    }
                }
                if (!string.IsNullOrEmpty(exePath))
                {
                    if (!File.Exists(exePath))
                    {
                        return false;
                    }
                    args = args.Replace("%1", uri.OriginalString);
                    try
                    {
                        Process.Start(exePath, args);
                        return true;
                    }
                    catch
                    {
                        // do nothing.
                    }
                }
            }
            /*Another method*/
            //You can only call executables (.exe) if you set UseShellExecute to
            //false. To run a dll when UseShellExecute is false, you can use
            //"rundll32" to do this as in:
            //Process myProcess = new Process();
            //ProcessStartInfo myProcessStartInfo =
            //new ProcessStartInfo("rundll32.exe" );
            //myProcessStartInfo.UseShellExecute = false;
            //myProcessStartInfo.RedirectStandardOutput = true;
            //myProcessStartInfo.Arguments= "url.dll ,FileProtocolHandler
            //www.microsoft.com";
            //myProcess.StartInfo = myProcessStartInfo;
            //myProcess.Start();
            //Warning: If you try to start the process "http://www.microsoft.com" from
            //a [MTAThreaded] application with UseShellExecute set to true, your
            //[MTAThreaded] application will throw an exception.
            //Regards,
            //Jeff
            return false;
        }

        static private string GetDefaultBrowserCommand()
        {
            RegistryKey key = null;
            try
            {
                /*Note that we may not have permission to open the key.*/
                key = Registry.ClassesRoot.OpenSubKey(@"HTTP\shell\open\command", false);
                /*Gets default value of the key*/
                return key.GetValue(null).ToString();
            }
            catch
            {
                return null;
            }
            finally
            {
                if (key != null)
                {
                    key.Close();
                }
            }
        }        
    }
}
