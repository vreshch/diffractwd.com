﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using Base;

namespace Main.Conditions
{
    class IsSolutionActive : IConditionEvaluator
    {
        #region IConditionEvaluator Members

        public bool IsValid(object caller, Condition condition)
        {
            if (Workbench.Instance == null) return false;
            if (Workbench.Instance.ActiveViewContent == null) return false;
            if (Workbench.Instance.ActiveViewContent.Sln == null) return false;
            return true;
        }

        #endregion
    }
}
