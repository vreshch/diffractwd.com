﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using Base;

namespace Main.Conditions
{
    /// <summary>
    /// Tests if the Active Solution View Window Have Defalut Scale
    /// </summary>
    public class IsDefalutZoomConditionEvaluator : IConditionEvaluator
    {
        public bool IsValid(object caller, Condition condition)
        {
            if (Workbench.Instance == null) return false;
            if (Workbench.Instance.ActiveViewContent == null) return false;
            return (Workbench.Instance.ActiveViewContent.IsDefalutZoom);            
        }        
    }


    public class IsZoomInConditionEvaluator : IConditionEvaluator
    {
        public bool IsValid(object caller, Condition condition)
        {
            if (Workbench.Instance == null) return false;
            if (Workbench.Instance.ActiveViewContent == null) return false;
            return (Workbench.Instance.ActiveViewContent.IsZoomInAllowed);
        }
    }

    public class IsZoomOutConditionEvaluator : IConditionEvaluator
    {
        public bool IsValid(object caller, Condition condition)
        {
            if (Workbench.Instance == null) return false;
            if (Workbench.Instance.ActiveViewContent == null) return false;
            return (Workbench.Instance.ActiveViewContent.IsZoomOutAllowed);
        }
    }


    public class IsZoomUndoConditionEvaluator : IConditionEvaluator
    {
        public bool IsValid(object caller, Condition condition)
        {
            if (Workbench.Instance == null) return false;
            if (Workbench.Instance.ActiveViewContent == null) return false;
            return (Workbench.Instance.ActiveViewContent.IsZoomUndoAllowed);
        }
    }
}
