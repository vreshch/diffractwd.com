﻿using System;
using System.Collections.Generic;
using System.Text;
using Base;
using System.Windows.Forms;

namespace Main
{
    class BackGroundSubstract_1 : AFilter
    {

        public override string Group
        {
            get
            {
                return "BackGround Substract";
            }
        }

        public override string Name
        {
            get
            {
                return "BackGround";
            }
        }                
        

        // From 0 to 30 ; 15 - resonable
        private int _SubstrValue = 90;
        public int SubstrValue
        {
            get 
            {
                return _SubstrValue;
            }
            set 
            {
                
                if (_SubstrValue != value)
                {
                    _SubstrValue = value;
                    if (AutoUpdate)
                    {
                        DoModifed(false, true);
                    }
                }                
            }
        }

        public override PowderData ApplayFilter(PowderData data)
        {            
            int each10 = 10; // substract each 10 points
            int cycles_count =  Math.Abs(100-this.SubstrValue);
            if (data == null) return null;
            PowderData outdata = PowderData.Clone(data);


            int points_num = (int)Math.Truncate((double)(data.y.Length) / each10);
            double[] fx = new double[points_num];
            double[] fy = new double[points_num];
            for (int k = 0; k < points_num; k++)
            {
                fx[k] = data.x[(k * each10)];
                fy[k] = data.y[(k * each10)];
            }


            // calculate background substraction
            for (int i = 0; i < cycles_count; i++)
            {
                for (int j = 1; j < (points_num - 1); j++)
                {
                    double current = fy[j];
                    double calc = (fy[j - 1] + fy[j + 1]) / 2;
                    if (calc < current) fy[j] = calc;
                }
            }

            // substracted
            double[] fgx = new double[data.y.Length];
            double[] fgy = new double[data.y.Length];


            //Linear extrapolation
            for (int k = 0; k < data.y.Length; k++)
            {
                int Leftpoint = Math.Min((int)Math.Truncate((double)(k / each10)), fy.Length - 1);
                int Rightpoint = Math.Min((Leftpoint + 1), fy.Length - 1);

                double extrapolation = fy[Leftpoint] + ((k - Leftpoint * each10) / each10) * (fy[Rightpoint] - fy[Leftpoint]);

                fgx[k] = data.x[k];
                double prpoposed = data.y[k] - extrapolation;
                if (prpoposed < 0) prpoposed = 0;
                outdata.y[k] = prpoposed;

            }
            // Normalize out data; Auto scale; some can become Litle negative;
            double miny = outdata.y[0];
            double maxy = outdata.y[0];
            for (int k = 0; k < data.y.Length; k++)
            {
                if (outdata.y[k] < miny) miny = outdata.y[k];
                if (outdata.y[k] > maxy) maxy = outdata.y[k];
            }
            // set minimal point to zero; and auto scale to 100;
            for (int k = 0; k < data.y.Length; k++)
            {
                outdata.y[k] = (outdata.y[k] - miny)* 100 / (maxy - miny);                
            }

            return outdata;
        }


        public Control _PropertiesControl = null;
        public override Control PropertiesControl
        {
            get 
            {
                if (_PropertiesControl == null)
                {
                    _PropertiesControl =  new BackGroundPanel(this); 
                }
                return _PropertiesControl;                
            }
        }       
    }
}
