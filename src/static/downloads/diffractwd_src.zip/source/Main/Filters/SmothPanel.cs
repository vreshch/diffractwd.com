﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Main
{
    class SmothPanel : Panel
    {
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Label label1;

        private Smoth_Savtizky_Golay Item = null;

        public SmothPanel(Smoth_Savtizky_Golay attached_item)
        {
            this.Item = attached_item;
            InitComponents();
            this.checkBox1.CheckedChanged += new EventHandler(checkBox1_CheckedChanged);
            this.trackBar1.ValueChanged += new EventHandler(trackBar1_ValueChanged);
        }

        void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            Item.SmothLevel = trackBar1.Value;
        }

        void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            Item.AutoUpdate = checkBox1.Checked;            
        }

        public void InitComponents()
        {
            // -----===== Design by Form Desingner  =====----- //
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            
            this.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();            
            // 
            // panel1
            // 
            Controls.Add(this.tableLayoutPanel1);
            Controls.Add(this.checkBox1);
            Dock = System.Windows.Forms.DockStyle.Fill;
            Location = new System.Drawing.Point(0, 0);
            Name = "panel1";
            Size = new System.Drawing.Size(292, 273);
            TabIndex = 0;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox1.Location = new System.Drawing.Point(0, 243);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Padding = new System.Windows.Forms.Padding(5);
            this.checkBox1.Size = new System.Drawing.Size(292, 30);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Auto Update Graph";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.Checked = Item.AutoUpdate;

            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.trackBar1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);            


            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(292, 243);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // trackBar1
            // 
            this.trackBar1.Dock = System.Windows.Forms.DockStyle.Top;
            this.trackBar1.Location = new System.Drawing.Point(59, 3);
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(230, 42);
            this.trackBar1.TabIndex = 0;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
            
            this.trackBar1.Maximum = 7;
            this.trackBar1.Minimum = 0;
            this.trackBar1.Value = Item.SmothLevel;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Smoth Level :";
            // 
            // Form1
            // 
            ResumeLayout(false);
            PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();             
        }
    }
}
