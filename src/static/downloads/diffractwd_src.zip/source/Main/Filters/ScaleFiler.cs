﻿using System;
using System.Collections.Generic;
using System.Text;
using Base;
using System.Windows.Forms;

namespace Main
{
    class ScaleFiler : AFilter
    {

        #region IPowFilter Members

        public override string Group
        {
            get
            {
                return "Scale";
            }
        }

        public override string Name
        {
            get
            {
                //Savitzky Golay
                return "Scale";
            }
        }

        private double _MinValue = 0;
        public double MinValue
        {
            get
            {
                return _MinValue;
            }
            set
            {
                if (_MinValue != value)
                {
                    _MinValue = value;
                    if (AutoUpdate)
                    {
                        DoModifed(false, true);
                    }
                }
            }
        }

        private double _Height = 100;
        public double Height
        {
            get
            {
                return _Height;
            }
            set
            {
                if (_Height != value)
                {
                    _Height = value;
                    if (AutoUpdate)
                    {
                        DoModifed(false, true);
                    }
                }
            }
        }


        public override PowderData ApplayFilter(PowderData data)
        {
            double miny = data.y[0];
            double maxy = data.y[0];
            for (int k = 0; k < data.y.Length; k++)
            {
                if (data.y[k] < miny) miny = data.y[k];
                if (data.y[k] > maxy) maxy = data.y[k];
            }

            double ScaleFactor = (Height / (maxy - miny));
            double DiffFactor = (miny - MinValue);


            // set minimal point to zero; and auto scale to 100;
            for (int k = 0; k < data.y.Length; k++)
            {
                data.y[k] = (data.y[k] - DiffFactor) * ScaleFactor;                    
            }

            return data;
        }

        #endregion


        public Control _PropertiesControl = null;
        public override Control PropertiesControl
        {
            get
            {
                if (_PropertiesControl == null)
                {
                    _PropertiesControl = new ScalePanel(this);
                }
                return _PropertiesControl;
            }
        }
    }
}

