﻿using System;
using System.Collections.Generic;
using System.Text;
using Base;
using System.Windows.Forms;

namespace Main
{
    abstract class AFilter : IPowFilter
    {        
        #region : Abstract Members
        abstract public string Group
        {
            get;
        }
        abstract public string Name
        {
            get;
        }
        abstract public PowderData ApplayFilter(PowderData data);
        
        #endregion
        
        private IProjectItem _Parent;
        public IProjectItem Parent
        {
            get
            {
                return _Parent;
            }
            set
            {
                _Parent = value;
            }
        }

        public void Deserialize(System.Xml.XmlElement node)
        {
            throw new NotImplementedException();
        }
        public void Serialize(System.Xml.XmlElement node)
        {
            throw new NotImplementedException();
        }

        private bool _autoupdate = true;
        public bool AutoUpdate 
        {
            get 
            {
                return _autoupdate; 
            }
            set 
            {                
                _autoupdate = value;
                if (value == true)
                {
                    this.DoModifed(false, true);
                }
            }
        }

        public event EventHandler<ItemEventArgs> SelectionChanged;
        public event EventHandler<ItemEventArgs> VisibleChanged;
        public event EventHandler<ObjModifeedEventArgs> Modified;


        #region ISelectable, IVisible Members

        private void OnSelectionChanged(ItemEventArgs e)
        {
            if (SelectionChanged != null) SelectionChanged(this, e);
        }
        private bool _Selected = false;
        public bool Selected
        {
            get
            {
                return _Selected;
            }
            set
            {
                _Selected = value;
                if (value == true)
                {
                    OnSelectionChanged(new ItemEventArgs(this));
                }
            }
        }              
             
        private void OnVisibleChanged(ItemEventArgs e)
        {
            if (VisibleChanged != null) VisibleChanged(this, e);
        }

        private bool _IsVisible = false;
        public virtual bool Visible
        {
            get
            {                
                return _IsVisible;
            }
            set
            {             
                if (_IsVisible != value)
                {
                    _IsVisible = value;
                    OnVisibleChanged(new ItemEventArgs(this));                    
                }
            }
        }

        protected void DoModifed(bool Invadiate, bool Redraw)
        {
            OnModified(new ObjModifeedEventArgs(this, Invadiate, Redraw));
        }

        protected void OnModified(ObjModifeedEventArgs args)
        {
            if (Modified != null) Modified(this, args);
        }

        #endregion


        #region IPropertiesEditable Members

        public virtual object ObjProperties
        {
            get
            {
                return null;
            }
        }

        public virtual Control PropertiesControl
        {
            get { return null; }
        }

        #endregion

    
    
    }
}
