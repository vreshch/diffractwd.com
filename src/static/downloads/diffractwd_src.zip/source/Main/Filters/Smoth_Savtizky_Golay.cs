﻿using System;
using System.Collections.Generic;
using System.Text;
using Base;
using System.Windows.Forms;

namespace Main
{
    class Smoth_Savtizky_Golay : AFilter
    {

        #region IPowFilter Members

        public override string Group
        {
            get
            {
                return "Smoth";
            }
        }

        public override string Name
        {
            get
            {
                //Savitzky Golay
                return "Smoth";
            }
        }

        private int _SmothLevel = 1;
        public int SmothLevel
        {
            get
            {
                return _SmothLevel;
            }
            set
            {
                if (_SmothLevel != value)
                {
                    _SmothLevel = value;
                    if (AutoUpdate)
                    {
                        DoModifed(false, true);
                    }
                }                
            }
        }


        public override PowderData ApplayFilter(PowderData data)        
        {
            if (SmothLevel == 0) return data;

            // cubic polynomial smothing for 5, 7, 9,... 17 point 
            double[] a1 = new double[] {5,  35,     17, 12, - 3};
            double[] a2 = new double[] {7,  21,     7,   6,   3,  -2 };
            double[] a3 = new double[] {9,  231,   59,   54,  39, 14, -21};
            double[] a4 = new double[] {11, 429,   89,   84,  69, 44,   9,  -36};
            double[] a5 = new double[] {13, 143,   25,   24,  21, 16,   9,  0,  -11};
            double[] a6 = new double[] {15, 1105,  167, 162, 147, 122, 87,  42, -13, -78};
            double[] a7 = new double[] {17, 323,   43,   42,  39, 34,  27,  18,  7,   -6, -21 };

            // choice proper smoth array
            double[] smoth_array = a7;
            switch (SmothLevel)
            {
                case 1: smoth_array = a1;  break;
                case 2: smoth_array = a2;  break;
                case 3: smoth_array = a3;  break;
                case 4: smoth_array = a4;  break;
                case 5: smoth_array = a5;  break;
                case 6: smoth_array = a6;  break;
                case 7: smoth_array = a7;  break;                
            }
            
            // calculate
            int leftpoints = (int)((smoth_array[0] - 1) / 2);

            for (int k = leftpoints; k < data.y.Length - leftpoints; k++)
            {
                double val = 0;


                //double ax = (1 / 35.0f) * (-3.0 * data.y[k - 2] + 12.0 * data.y[k - 1] + 17.0 * data.y[k] + 12.0 * data.y[k + 1] - 3.0 * data.y[k + 2]);

                for (int j = 0; j < leftpoints; j++)
                {
                    val = val + (smoth_array[leftpoints + 2 - j] * data.y[k + j - leftpoints]);
                }

                val = val + (smoth_array[2] * data.y[k]);

                for (int j = 0; j < leftpoints; j++)
                {
                    val = val + (smoth_array[j + 3] * data.y [k + j + 1]);
                }                


                double a  = val/smoth_array[1];
                data.y[k] = a; 
            }


            // Auto Scale correction ; from 0 to 100
            
            /*
            double miny = data.y[0];
            double maxy = data.y[0];
            for (int k = 0; k < data.y.Length; k++)
            {
                if (data.y[k] < miny) miny = data.y[k];
                if (data.y[k] > maxy) maxy = data.y[k];
            }
            // set minimal point to zero; and auto scale to 100;
            for (int k = 0; k < data.y.Length; k++)
            {
                data.y[k] = (data.y[k] - miny) * 100 / (maxy - miny);
            }
            */

            return data;
                       
        }

        #endregion   
 

        public Control _PropertiesControl = null;
        public override Control PropertiesControl
        {
            get
            {
                if (_PropertiesControl == null)
                {
                    _PropertiesControl = new SmothPanel(this);
                }
                return _PropertiesControl;
            }
        }      
    }
}

