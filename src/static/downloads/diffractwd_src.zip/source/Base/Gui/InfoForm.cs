﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using ICSharpCode.Core;

namespace Base
{
	public class InfoForm : System.Windows.Forms.Form
	{
		public InfoForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			FormLocationHelper.Apply(this, "InfoForm", false);
			
			versionLabel.Text = typeof(AddInTree).Assembly.GetName().Version.ToString();
			demoVersionLabel.Text = Assembly.GetEntryAssembly().GetName().Version.ToString();
			listBox.UseCustomTabOffsets = true;
			listBox.CustomTabOffsets.Add(100);
			foreach (Assembly asm in AppDomain.CurrentDomain.GetAssemblies()) {
				AssemblyName name = asm.GetName();
				listBox.Items.Add(name.Name + "\t" + name.Version.ToString());
			}
		}
		
		#region Windows Forms Designer generated code
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.LinkLabel linkLabel1;
            System.Windows.Forms.LinkLabel linkLabel2;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Button okButton;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.LinkLabel linkLabel3;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InfoForm));
            this.listBox = new System.Windows.Forms.ListBox();
            this.versionLabel = new System.Windows.Forms.Label();
            this.demoVersionLabel = new System.Windows.Forms.Label();
            linkLabel1 = new System.Windows.Forms.LinkLabel();
            linkLabel2 = new System.Windows.Forms.LinkLabel();
            label1 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            okButton = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // linkLabel1
            // 
            linkLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            linkLabel1.LinkArea = new System.Windows.Forms.LinkArea(0, 10);
            linkLabel1.Location = new System.Drawing.Point(67, 35);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new System.Drawing.Size(90, 23);
            linkLabel1.TabIndex = 1;
            linkLabel1.TabStop = true;
            linkLabel1.Tag = "http://diffractwd.com/";
            linkLabel1.Text = "DiffractWD :";
            linkLabel1.UseCompatibleTextRendering = true;
            linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabelLinkClicked);
            // 
            // linkLabel2
            // 
            linkLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            linkLabel2.LinkArea = new System.Windows.Forms.LinkArea(0, 17);
            linkLabel2.Location = new System.Drawing.Point(10, 112);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new System.Drawing.Size(284, 29);
            linkLabel2.TabIndex = 2;
            linkLabel2.TabStop = true;
            linkLabel2.Tag = "mailto:suport@diffractwd.com";
            linkLabel2.Text = "Volodymyr Vreshch, Albany 2010";
            linkLabel2.UseCompatibleTextRendering = true;
            linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabelLinkClicked);
            // 
            // label1
            // 
            label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label1.Location = new System.Drawing.Point(10, 153);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(305, 23);
            label1.TabIndex = 6;
            label1.Tag = "";
            label1.Text = "List of loaded assemblies:";
            label1.UseCompatibleTextRendering = true;
            label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label3
            // 
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label3.Location = new System.Drawing.Point(13, 60);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(144, 23);
            label3.TabIndex = 4;
            label3.Text = "Core version:";
            label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            label3.UseCompatibleTextRendering = true;
            // 
            // okButton
            // 
            okButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            okButton.Location = new System.Drawing.Point(240, 254);
            okButton.Name = "okButton";
            okButton.Size = new System.Drawing.Size(75, 23);
            okButton.TabIndex = 0;
            okButton.Text = "OK";
            okButton.UseCompatibleTextRendering = true;
            okButton.UseVisualStyleBackColor = true;
            okButton.Click += new System.EventHandler(this.OkButtonClick);
            // 
            // label2
            // 
            label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            label2.Location = new System.Drawing.Point(10, 9);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(305, 23);
            label2.TabIndex = 11;
            label2.Tag = "";
            label2.Text = "Application for basic powder pattern manipulations";
            label2.UseCompatibleTextRendering = true;
            // 
            // linkLabel3
            // 
            linkLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            linkLabel3.LinkArea = new System.Windows.Forms.LinkArea(0, 35);
            linkLabel3.Location = new System.Drawing.Point(12, 83);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new System.Drawing.Size(284, 29);
            linkLabel3.TabIndex = 12;
            linkLabel3.TabStop = true;
            linkLabel3.Tag = "http://scripts.iucr.org/cgi-bin/paper?wf5075";
            linkLabel3.Text = "J. Appl. Cryst. (2011). 44, 219-220";
            linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // listBox
            // 
            this.listBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(10, 179);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(302, 69);
            this.listBox.TabIndex = 7;
            // 
            // versionLabel
            // 
            this.versionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.versionLabel.Location = new System.Drawing.Point(163, 60);
            this.versionLabel.Name = "versionLabel";
            this.versionLabel.Size = new System.Drawing.Size(112, 23);
            this.versionLabel.TabIndex = 5;
            this.versionLabel.Text = "#.#.#.#";
            this.versionLabel.UseCompatibleTextRendering = true;
            // 
            // demoVersionLabel
            // 
            this.demoVersionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.demoVersionLabel.Location = new System.Drawing.Point(163, 35);
            this.demoVersionLabel.Name = "demoVersionLabel";
            this.demoVersionLabel.Size = new System.Drawing.Size(112, 23);
            this.demoVersionLabel.TabIndex = 9;
            this.demoVersionLabel.Text = "#.#.#.#";
            this.demoVersionLabel.UseCompatibleTextRendering = true;
            // 
            // InfoForm
            // 
            this.AcceptButton = okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 289);
            this.Controls.Add(linkLabel3);
            this.Controls.Add(this.demoVersionLabel);
            this.Controls.Add(linkLabel1);
            this.Controls.Add(label2);
            this.Controls.Add(okButton);
            this.Controls.Add(this.versionLabel);
            this.Controls.Add(label3);
            this.Controls.Add(this.listBox);
            this.Controls.Add(label1);
            this.Controls.Add(linkLabel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "InfoForm";
            this.Text = "About diffractWD";
            this.ResumeLayout(false);

		}
		private System.Windows.Forms.Label demoVersionLabel;
        private System.Windows.Forms.ListBox listBox;
		private System.Windows.Forms.Label versionLabel;
		#endregion
		
		void LinkLabelLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			string url = (sender as Control).Tag.ToString();
			try {
				System.Diagnostics.Process.Start(url);
			} catch (Exception) 
            {
				MessageService.ShowMessage(url);
			}
		}
		
		void OkButtonClick(object sender, EventArgs e)
		{
			Close();
		}

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string url = (sender as Control).Tag.ToString();
            try
            {
                System.Diagnostics.Process.Start(url);
            }
            catch (Exception)
            {
                MessageService.ShowMessage(url);
            }
        }
	}
		
}
