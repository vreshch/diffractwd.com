﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace Base
{   
    
    /// <summary>
    /// Interface for content displayed in the application.
    /// </summary>
    public interface ISolutionView
    {                
        
        /// <summary>
        /// Gets the control used to display this view content.
        /// </summary>
        Control Control
        {
            get;
        }

        Solution Sln
        {
            get;
        }

        
        // Nead to be updated later
        string Title
        {
            get;
        }

        string FileName
        {
            get;
        }

        bool IsUntitled
        {
            get;
        }

        bool IsDirty
        {
            get;
        }



        /// <summary>
        /// Is Zoom Set As Defalut
        /// </summary>        
        bool IsDefalutZoom
        {
            get;
        }
        /// <summary>
        /// Set Active Window Scale to Deffalut        
        /// </summary>
        void SetScaleToDefalut();


        /// <summary>
        /// Is Zoom In Allowed
        /// </summary>   
        bool IsZoomInAllowed
        {
            get;
        }
        /// <summary>
        /// Do Zoom In
        /// </summary>
        void ZoomIn();

        /// <summary>
        /// Is Zoom In Allowed
        /// </summary>   
        bool IsZoomOutAllowed
        {
            get;
        }
        /// <summary>
        /// Do Zoom In
        /// </summary>
        void ZoomOut();

        /// <summary>
        /// Have Any Zoom Out Actions in Stack
        /// </summary>   
        bool IsZoomUndoAllowed
        {
            get;
        }

        /// <summary>
        /// Preform Undo Zoom
        /// </summary>
        void ZoomUndo();
        
        /// <summary>
        /// Preform Page Print
        /// </summary>
        void Print();

        /// <summary>
        /// Preform Page Preview
        /// </summary>
        void PrintPreview();

        /// <summary>
        /// Preform Page Print Setup
        /// </summary>
        void PrintPageSetup();



        /// <summary>
        /// Closes the view content. Returns true when the content was closed successfully,
        /// false when closing the content was aborted (e.g. by the user)
        /// </summary>
        bool Close();

        /// <summary>
        /// The workbench window in which this view is displayed.
        /// </summary>
        Form DockContent
        {
            get;
            set;
        }

        /// <summary>
        /// Saves the content, e.g. to a file. Returns true when the content has been saved successfully.
        /// </summary>
        bool Save();
        /// <summary>
        /// Asks the user to specify the file location/name and saves the content using the new name.
        /// Returns true when the content has been saved successfully.
        /// </summary>
        bool SaveAs();

        void CopyImage();

        void ExportImage();

        void RedrawContent();

        void Add(IProjectItem ipi);

    }
}
