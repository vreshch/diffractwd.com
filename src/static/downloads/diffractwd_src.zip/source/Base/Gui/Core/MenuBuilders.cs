﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using ICSharpCode.Core;

namespace Base
{
    /*
    public interface ISubmenuBuilder
    {
        ToolStripItem[] BuildSubmenu(Codon codon, object owner);
    }
    */

    public abstract class ViewMenuBuilder : ISubmenuBuilder
    {
        class MyMenuItem : MenuCommand
        {
            PadDescriptor padDescriptor;

            public MyMenuItem(PadDescriptor padDescriptor): base(null, null)
            {
                this.padDescriptor = padDescriptor;
                Text = StringParser.Parse(padDescriptor.Title);

                if (!string.IsNullOrEmpty(padDescriptor.Icon))
                {
                    base.Image = ResourceService.GetBitmap(padDescriptor.Icon);                                        
                }

                if (padDescriptor.Shortcut != null)
                {
                    ShortcutKeys = MenuCommand.ParseShortcut(padDescriptor.Shortcut);
                }
            }

            protected override void OnClick(EventArgs e)
            {
                base.OnClick(e);
                padDescriptor.BringPadToFront();
            }

        }
        protected abstract string Category
        {
            get;
        }

        public ToolStripItem[] BuildSubmenu(Codon codon, object owner)
        {
            List<ToolStripItem> items = new List<ToolStripItem>();
            foreach (PadDescriptor padContent in Workbench.Instance.PadContentCollection)
            {
                if (padContent.Category == Category)
                {
                    items.Add(new MyMenuItem(padContent));
                }
            }
            return items.ToArray();
        }
    }

    public class MainViewMenuBuilder : ViewMenuBuilder
    {
        public MainViewMenuBuilder()
        {
            float f = 0;
        }
        protected override string Category
        {
            get
            {
                return "Main";
            }
        }
        
    }
}
