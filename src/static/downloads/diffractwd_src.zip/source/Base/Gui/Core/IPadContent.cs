﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Windows.Forms;

namespace Base
{
    /// <summary>
    /// The IPadContent interface is the basic interface to all "tool" windows
    /// in SharpDevelop.
    /// </summary>
    public interface IPadContent : IDisposable
    {
        /// <summary>
        /// Returns the Windows.Control for this pad.
        /// </summary>
        Control Control
        {
            get;
        }

        /// <summary>
        /// Re-initializes all components of the pad. Don't call unless
        /// you know what you do.
        /// </summary>
        void RedrawContent();
    }
}
