﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ICSharpCode.Core;

namespace Base
{
    /// <summary>
    /// This is the basic interface to the workspace.
    /// </summary>
    public interface IWorkbench : IMementoCapable
    {
        /// <summary>
        /// Gets the Instance for the work bench.
        /// </summary>
        //static IWorkbench Instance
        //{
        //get;
        //}

        /// <summary>
        /// The title shown in the title bar.
        /// </summary>
        string Title
        {
            get;
            set;
        }

        /// <summary>
        /// A collection of all opened view contents
        /// </summary>
        IList<ISolutionView> ViewContents
        {
            get;
        }
              
        /// <summary>
        /// A collection in which all active workspace windows are saved.
        /// </summary>
        IList<PadDescriptor> PadContentCollection
        {
            get;
        }
       

        /// <summary>
        /// The active view content inside the active workbench window.
        /// </summary>
        ISolutionView ActiveViewContent
        {
            get;
        }

        /// <summary>
        /// Is called, when the active view content has changed.
        /// </summary>
        event EventHandler ActiveViewContentChanged;


        /// <summary>
        /// The active content, depending on where the focus currently is.
        /// If a document is currently active, this will be equal to ActiveViewContent,
        /// if a pad has the focus, this property will return the IPadContent instance.
        /// </summary>
        object ActivePan
        {
            get;
        }


        /// <summary>
        /// Is called, when the active content has changed.
        /// </summary>
        event EventHandler ActiveContentChanged;

      

        /// <summary>
        /// Gets whether SharpDevelop is the active application in Windows.
        /// </summary>
        bool IsActiveWindow
        {
            get;
        }
       

        /// <summary>
        /// Inserts a new <see cref="IViewContent"/> object in the workspace and switches to the new view.
        /// </summary>
        void ShowView(ISolutionView content);
        
        /// <summary>
        /// Inserts a new <see cref="IViewContent"/> object in the workspace.
        /// </summary>
        void ShowView(ISolutionView content, bool switchToOpenedView);



        /// <summary>
        /// Inserts a new <see cref="IPadContent"/> object in the workspace.
        /// </summary>
        void ShowPad(PadDescriptor content);

        /// <summary>
        /// Closes and disposes a <see cref="IPadContent"/>.
        /// </summary>
        void UnloadPad(PadDescriptor content);

        /// <summary>
        /// Returns a pad from a specific type.
        /// </summary>
        PadDescriptor GetPad(Type type);

        /// <summary>
        /// Closes the IViewContent content when content is open.
        /// </summary>
        void CloseContent(ISolutionView content);

        /// <summary>
        /// Closes all views inside the workbench.
        /// </summary>
        void CloseAllViews();

        /// <summary>
        /// Re-initializes all components of the workbench, should be called
        /// when a special property is changed that affects layout stuff.
        /// (like language change)
        /// </summary>
        void RedrawAllComponents();

        /// <summary>
        /// Updates the toolstrip renderer.
        /// </summary>
        void UpdateRenderer();

        /// <summary>
        /// Is called, when a workbench view was opened
        /// </summary>
        /// <example>
        /// WorkbenchSingleton.WorkbenchCreated += delegate {
        /// 	WorkbenchSingleton.Workbench.ViewOpened += ...;
        /// };
        /// </example>
        event ViewContentEventHandler ViewOpened;

        /// <summary>
        /// Is called, when a workbench view was closed
        /// </summary>
        event ViewContentEventHandler ViewClosed;

        /// <summary>
        /// Is called when a key is pressed. Can be used to intercept command keys.
        /// </summary>
        event System.Windows.Forms.KeyEventHandler ProcessCommandKey;
    }
}
