﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using ICSharpCode.Core;

namespace Base
{
    public interface IPropertiesEditable
    {
        object ObjProperties
        {
            get;
        }
        
        Control PropertiesControl
        {
            get;
        }
    }

    public interface ISelectable
    {
        bool Selected
        {
            get;
            set;
        }
    }

    public interface IVisible
    {
        bool Visible
        {
            get;
            set;
        }
    }

}