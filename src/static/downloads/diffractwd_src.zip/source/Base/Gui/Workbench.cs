﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using ICSharpCode.Core;
using System.Collections.Generic;
using WeifenLuo.WinFormsUI.Docking;
using WeifenLuo.WinFormsUI;
using System.Diagnostics;
using System.Collections;
using System.IO;
using System.Text;

namespace Base
{
    /// <summary>
    /// The main form of the application.
    /// </summary>
    public sealed class Workbench : Form, IWorkbench
    {
        List<PadDescriptor> padViewContentCollection = new List<PadDescriptor>();
        List<ISolutionView> ViewContentCollection = new List<ISolutionView>();

        private static Workbench _instance;
    
        public static Workbench Instance        
        { 
            get
            {
                if(_instance == null) 
                {
                    _instance = new Workbench();
                }
                return _instance;
            }            
        }
     
        public string Title
        {
            get
            {
               return Text;
            }
            set
            {
                Text = value;
            }
        }
        
        public IList<ISolutionView> ViewContents
        {
            get 
            {
                Debug.Assert(ViewContentCollection != null);
                return ViewContentCollection; 
            }
        }

        public IList<PadDescriptor> PadContentCollection
        {
            get
            {
                Debug.Assert(padViewContentCollection != null);
                return padViewContentCollection;
            }
        }
        
        public ISolutionView ActiveViewContent
        {
            get
            {
                ViewContentWrapper idc = (ViewContentWrapper)dockPanel.ActiveDocument;
                if (idc == null) return null;
                return (idc.SolutionView);
            }
        }

        public Solution ActiveSolution        
        {
            get
            {
                ViewContentWrapper idc = (ViewContentWrapper)dockPanel.ActiveDocument;
                if (idc == null) return null;
                return idc.SolutionView.Sln;
            }
        }

        public object ActivePan
        {
            get
            {
                return dockPanel.ActivePane;
            }            
        }


        public List<string> OpenFileList
        {
            get 
            {
                List<string> list = new List<string>();
                foreach (ISolutionView isv in ViewContents)
                {
                    if (isv.FileName != null) list.Add(isv.FileName);
                }
                return list;
            }
        }

        /// <summary>
        /// Gets whether SharpDevelop is the active application in Windows.
        /// </summary>
        public bool IsActiveWindow
        {
            get { return this.IsActiveWindow; }
        }

                       
        public void ShowView(ISolutionView content)
        {
            this.ShowView(content, true);
        }

        public void ShowView(ISolutionView content, bool switchToOpenedView)
        {
            if (content == null) throw new ArgumentNullException("content");
            if (content.DockContent != null) throw new ArgumentNullException("Cannot show view content that is already visible in another workbench window");
            if (dockPanel == null) throw new InvalidOperationException("No dockPanel is attached.");

            ViewContents.Add(content);
            
            ViewContentWrapper vcw = new ViewContentWrapper(content);
            vcw.Show(dockPanel);
            ViewContentHash.Add(content, vcw);


            content.Sln.TitleChanged += DoTitleChange;
            content.Sln.Modified += new EventHandler<ObjModifeedEventArgs>(Sln_Modified);
            content.Sln.ItemAdded += new EventHandler<ProjectItemEventArgs>(OnSolutionItemAdded);
            content.Sln.ItemRemoved += new EventHandler<ProjectItemEventArgs>(OnSolutionItemRemoved);
            content.Sln.SelectionChanged += new EventHandler<ItemEventArgs>(OnSelectionChanged);
            



            DoTitleChange(content, EventArgs.Empty);
            
            if (switchToOpenedView)
            {
                content.Control.Focus();
            }

            OnViewOpened(new ViewContentEventArgs(content));
        }

        void Sln_Modified(object sender, ObjModifeedEventArgs e)
        {            
            OnSolutionModified(this, new EventArgs());
        }

        
        Dictionary<string, PadContentWrapper> PadContentHash = new Dictionary<string, PadContentWrapper>();
        Dictionary<ISolutionView, ViewContentWrapper> ViewContentHash = new Dictionary<ISolutionView, ViewContentWrapper>();

        

        PadContentWrapper CreatePadContent(PadDescriptor content)
        {
            if (PadContentHash.ContainsKey(content.Class))
            {
                return PadContentHash[content.Class];
            }

            PadContentWrapper newContent = new PadContentWrapper(content);
            // TODO Icon Service
            //if (!string.IsNullOrEmpty(content.Icon))
            //{
                //newContent.Icon = IconService.GetIcon(content.Icon);
            //}

            newContent.Text = StringParser.Parse(content.Title);
            PadContentHash[content.Class] = newContent;
            return newContent;
        }

        public void ShowPad(PadDescriptor content)
        {
            if (content == null)  throw new ArgumentNullException("content");
            if (dockPanel == null) throw new InvalidOperationException("No dockPanel is attached.");

            PadContentCollection.Add(content);

            PadContentWrapper ph = CreatePadContent(content);
            
            ph.Show(dockPanel);                                
        }

        public void UnloadPad(PadDescriptor content)
        {
            if (content == null) throw new ArgumentNullException("content");
            if (dockPanel == null) throw new InvalidOperationException("No dockPanel is attached.");

            PadContentCollection.Remove(content);

            if (content != null && PadContentHash.ContainsKey(content.Class))                
            {
                PadContentHash[content.Class].Close();
                PadContentHash[content.Class].Dispose();
                PadContentHash.Remove(content.Class);
            }

            content.Dispose();            
        }

        public PadDescriptor GetPad(Type type)
        {
            foreach (PadDescriptor pad in PadContentCollection)
            {
                if (pad.Class == type.FullName)
                {
                    return pad;
                }
            }
            return null;
        }

        public void BringPadToFront(PadDescriptor content)
        {
            if (content == null) throw new ArgumentNullException("content");
            if (dockPanel == null) throw new InvalidOperationException("No dockPanel is attached.");
            if (!PadContentHash.ContainsKey(content.Class)) throw new ArgumentNullException("Content Class Initialixation");

            PadContentWrapper pw = PadContentHash[content.Class];
            
            pw.Visible = true;
            pw.Activate();            
        }

        public void BringViewToFront(ISolutionView content)
        {
            if (content == null) throw new ArgumentNullException("content");
            if (dockPanel == null) throw new InvalidOperationException("No dockPanel is attached.");
            if (!ViewContentHash.ContainsKey(content)) throw new ArgumentNullException("Solution View Class Initialixation");

            ViewContentWrapper vcw = ViewContentHash[content];
            vcw.Visible = true;
            vcw.Activate();

        }

         
        public void CloseContent(ISolutionView content)
        {            
            if (ViewContents.Contains(content))
            {
                ViewContents.Remove(content);
            }

            ViewContentHash.Remove(content);

            content.Sln.TitleChanged -= DoTitleChange;
            DoTitleChange(content, EventArgs.Empty);

            OnViewClosed(new ViewContentEventArgs(content));
            content.Control.Dispose();
            content = null;   
        }
        
        public void CloseAllViews()
        {                                 
            foreach (ISolutionView isv in ViewContentCollection)
            {               
                CloseContent(isv);
            }            
        }

        public void RedrawAllComponents()
        {
            throw new NotImplementedException();
        }
        
        public void UpdateRenderer()
        {
            throw new NotImplementedException();
        }

        
        private MenuStrip TopMenu = null;
        private ToolStrip[] ToolBars = null;
        public DockPanel dockPanel = null;        


        void UpdateMenu(object sender, EventArgs e)
        {
            UpdateMenus();
            UpdateToolbars();
        }
        
        void UpdateMenus()
        {
            // update menu
            foreach (object o in TopMenu.Items)
            {
                if (o is IStatusUpdate)
                {
                    ((IStatusUpdate)o).UpdateStatus();
                }
            }
        }
        
        void UpdateToolbars()
        {
            if (ToolBars != null)
            {
                foreach (ToolStrip toolStrip in ToolBars)
                {
                    ToolbarService.UpdateToolbar(toolStrip);
                }
            }
        }
              


        private Workbench()
        {
            InitializeComponent();
            // restore form location from last session
            FormLocationHelper.Apply(this, "StartupFormPosition", true);


            //Main Dock Panel 
            dockPanel = new WeifenLuo.WinFormsUI.Docking.DockPanel();
            dockPanel.ActiveAutoHideContent = null;
            dockPanel.DocumentStyle = WeifenLuo.WinFormsUI.Docking.DocumentStyle.DockingSdi;
            dockPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            dockPanel.Name = "dockPanel";
            dockPanel.ActiveDocumentChanged += new EventHandler(dockPanel_ActiveDocumentChanged);
            dockPanel.ActivePaneChanged += new EventHandler(dockPanel_ActivePaneChanged);

            this.Controls.Add(dockPanel);
            AllowDrop = true;
        }

        public void Initialize()
        {

            //Creating pads Now
            ArrayList padcontents = new ArrayList();
            string viewContentPath = "/Workspace/Pads";
            try
            {
                AddInTreeNode adt = AddInTree.GetTreeNode(viewContentPath);
                padcontents = adt.BuildChildItems(Instance);

                foreach (PadDescriptor content in padcontents)
                {
                    if (content != null)
                    {
                        CreatePadContent(content);
                    }
                }
            }
            catch (TreePathNotFoundException) { }

            // Load docking now
            if (File.Exists(configdocking)) Instance.dockPanel.LoadFromXml(configdocking, deserializeDockContent);

            foreach (PadDescriptor content in padcontents) ShowPad(content);

            // Tool Bar 
            if (ToolBars == null)
            {
                ToolBars = ToolbarService.CreateToolbars(this, "/Workbench/Toolbar");
            }
            //Add ToolBars to the window
            foreach (ToolStrip t in ToolBars) this.Controls.Add(t);

            // Menu Bar
            TopMenu = new MenuStrip();
            MenuService.AddItemsToMenu(TopMenu.Items, this, "/Workbench/MainMenu");
            this.Controls.Add(TopMenu);
            UpdateMenus();
            //Add Main menu to the window                       

            DoTitleChange(null, EventArgs.Empty);

            Application.Idle += OnApplicationIdle; 




            // Load dicking                                   

            // Menu Update timer
            toolbarUpdateTimer = new System.Windows.Forms.Timer();
            toolbarUpdateTimer.Tick += new EventHandler(UpdateMenu);

            toolbarUpdateTimer.Interval = 500;
            toolbarUpdateTimer.Start();
        }



        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Workbench));
            this.SuspendLayout();
            // 
            // Workbench
            // 
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Workbench";
            this.ResumeLayout(false);

        }       
    
        // Interface IMementoCapable
        public Properties CreateMemento()
        {
            throw new NotImplementedException();
        }               
        
        public void SetMemento(Properties memento)
        {
            throw new NotImplementedException();
        }

        protected override void OnDragEnter(DragEventArgs e)
        {
            try
            {
                base.OnDragEnter(e);
                if (e.Data != null && e.Data.GetDataPresent(DataFormats.FileDrop))
                {
                    string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                    foreach (string file in files)
                    {
                        if (File.Exists(file))
                        {
                            if (ProjectService.IsSupportedFileType(Path.GetExtension(file)))
                            {
                                e.Effect = DragDropEffects.Copy;
                                return;
                            }
                        }
                    }
                }
                e.Effect = DragDropEffects.None;
            }
            catch (Exception ex)
            {
                MessageService.ShowError(ex);
            }
        }

        protected override void OnDragDrop(DragEventArgs e)
        {            
            try
            {               
                base.OnDragDrop(e);
                if (e.Data != null && e.Data.GetDataPresent(DataFormats.FileDrop))
                {
                    string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                    foreach (string file in files)
                    {
                        if (File.Exists(file))
                        {
                            if (ProjectService.IsSupportedFileType(Path.GetExtension(file)))
                            {
                                ProjectService.LoadFile(this, file);
                            }
                        }
                    }        
                }
            }
            catch (Exception ex)
            {
                MessageService.ShowError(ex);
            }
        }




        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                Application.Idle -= OnApplicationIdle;
            }
            base.Dispose(disposing);
        }

        void OnApplicationIdle(object sender, EventArgs e)
        {
            // Use the Idle event to update the status of menu and toolbar.
            // Depending on your application and the number of menu items with complex conditions,
            // you might want to update the status less frequently.
            UpdateMenuItemStatus();
        }
      
        void UpdateMenuItemStatus()
        {
            foreach (ToolStripItem item in TopMenu.Items)
            {
                if (item is IStatusUpdate) (item as IStatusUpdate).UpdateStatus();
            }
        }        

        void SetStandardStatusBar(object sender, EventArgs e)
        {
            //StatusBarService.SetMessage("${res:MainWindow.StatusBar.ReadyMessage}");
        }

        private System.Windows.Forms.Timer toolbarUpdateTimer;
               
      


        #region Docking 

        private static string configdocking = Path.Combine(PropertyService.ConfigDirectory, "layout.xml");

        private static IDockContent GetContentFromPersistString(string persistString)
        {
            if (Instance.PadContentHash.ContainsKey(persistString))
            {
                return Instance.PadContentHash[persistString];
            }
            return null;          
        }

        private static DeserializeDockContent _deserializeDockContent = null;
        private static DeserializeDockContent deserializeDockContent 
        {
            get 
            {
                if (_deserializeDockContent==null)
                {
                    _deserializeDockContent = new DeserializeDockContent(GetContentFromPersistString);
                }
                return _deserializeDockContent;
            }
        }            
     

        private static  void Save_Docking()
        {
            Instance.dockPanel.SaveAsXml(configdocking);            
        }

        /*
        private static Save_Config(Object sender, MolEventArgs args)
        {
            // Dock Panel Config
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "data\\dockpanel.config");
            dockPanel1.SaveAsXml(configFile);
            //~ Lets Close All tool Windows
            foreach (DictionaryEntry vtwin in Tool_win_list)
            {
                Form twin = (Form)vtwin.Value;
                twin.Close();
            }
        }
        */

  
        #endregion 

        #region Events
        // O.K.
        public event ViewContentEventHandler ViewOpened;
        // O.K.
        public event ViewContentEventHandler ViewClosed;

        //O.K
        public event EventHandler ActiveViewContentChanged;
        public event EventHandler ActiveContentChanged;

        //O.K.
        public event EventHandler<SolutionEventArgs> ActiveSolutionChanged;
        public event EventHandler<SolutionEventArgs> SolutionModified;        


        //O.K.
        public  event EventHandler<ProjectItemEventArgs> ProjectItemAdded;
        public  event EventHandler<ProjectItemEventArgs> ProjectItemRemoved;
        
        // O.K.        
        public event EventHandler<ItemEventArgs> ItemSelectionChanged;

        //???
        public event System.Windows.Forms.KeyEventHandler ProcessCommandKey;


       protected override void OnClosing(CancelEventArgs e)
       {
           base.OnClosing(e);
           if (!e.Cancel)
           {
               // :: HACK
               //e.Cancel = !CloseAllViews();

               if (!e.Cancel)
               {
                   // Save Docking of the panels
                   Save_Docking();
               }
           }           
       }              
       
       void DoTitleChange(object sender, EventArgs e)
       {
           if (ActiveViewContent != null)
           {
               Title = ActiveViewContent.Title + " - DiffractWD";
           }
           else
           {
               Title = "DiffractWD";
           }
       }
       
       void OnViewOpened(ViewContentEventArgs e)
       {
           if (ViewOpened != null)
           {
               ViewOpened(this, e);
           }
       }

       void OnViewClosed(ViewContentEventArgs e)
       {
           if (ViewClosed != null)
           {
               ViewClosed(this, e);
           }
       }

       private ISolutionView prevview = null;
       void OnActiveViewContentChanged(ViewContentEventArgs e)
       {
           if (prevview == e.Content) return;
           prevview = e.Content;
           if (ActiveViewContentChanged != null)
           {
               ActiveViewContentChanged(this, e);
           }
       }
    
       
       private object prevpan = null;
       void OnActiveContentChanged(PanContentEventArgs e)
       {
           if (prevpan == e.Content) return;
           prevpan = e.Content;

           if (ActiveContentChanged != null)
           {
               ActiveContentChanged(this, e);
           }
       }

       void dockPanel_ActivePaneChanged(object sender, EventArgs e)
       {
           OnActiveContentChanged(new PanContentEventArgs(this.ActivePan));
       }


       private Solution prevsol = null;
       void OnActiveSolutionChanged(SolutionEventArgs e)
       {
           if (prevsol == e.Solution) return;
           prevpan = e.Solution;

           if (ActiveSolutionChanged != null)
           {
               ActiveSolutionChanged(this, e);
           }
       }

       void OnSolutionItemRemoved(object sender, ProjectItemEventArgs e)
       {
           if (ProjectItemRemoved != null)
           {
               ProjectItemRemoved(this, e);
           }           
       }

       void OnSolutionItemAdded(object sender, ProjectItemEventArgs e)
       {
           if (ProjectItemAdded != null)           
           {
               ProjectItemAdded(this, e);
           }           
       }

       void OnSolutionModified(object sender, EventArgs e)
       {
           if (SolutionModified != null)
           {
               SolutionModified(this, new SolutionEventArgs(sender as Solution) );
           }           
       }

       void OnItemSelectionChanged(object sender, ItemEventArgs e)
       {           
       }

       void OnSelectionChanged(object sender, ItemEventArgs e)
       {
           if (ItemSelectionChanged != null)
           {
               ItemSelectionChanged(this,e);
           }
       }

       void dockPanel_ActiveDocumentChanged(object sender, EventArgs e)
       {
           DoTitleChange(sender, e);
           OnActiveViewContentChanged(new ViewContentEventArgs(this.ActiveViewContent));
           OnActiveSolutionChanged(new SolutionEventArgs(this.ActiveSolution));
       }


       //TODO - still not          
       #endregion
       
    }


    #region PadContentWrapper and ViewContentWrapper

    public class PadContentWrapper : DockContent
    {
        PadDescriptor padDescriptor;
        bool isInitialized = false;
        public IPadContent PadContent
        {
            get
            {
                return padDescriptor.PadContent;
            }
        }

        public PadContentWrapper(PadDescriptor padDescriptor)
        {
            this.padDescriptor = padDescriptor;             
            this.Icon = ResourceService.GetIcon(padDescriptor.Icon);
            this.DockAreas = DockAreas.Float | DockAreas.DockLeft | DockAreas.DockRight | DockAreas.DockTop | DockAreas.DockBottom;
            HideOnClose = true;
        
            /*
            this.ipd = ipd;
            this.Text = ipd.Title;
            Control ctl = ipd.PadContent.Control;
            ctl.Tag = this;
            ctl.Dock = DockStyle.Fill;
            this.Controls.Add(ctl);
            */
        }


        public void DetachContent()
        {
            Controls.Clear();
            padDescriptor = null;
        }


        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);
            if (Visible && Width > 0) ActivateContent();
        }
        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            if (Visible && Width > 0) ActivateContent();
        }
        /*
        public void AllowInitialize()
        {
            allowInitialize = true;
            if (Visible && Width > 0)
                ActivateContent();
        }
        */
        void ActivateContent()
        {
            //if (!allowInitialize) return;
            if (!isInitialized)
            {
                isInitialized = true;
                IPadContent content = padDescriptor.PadContent;
                if (content == null)
                    return;
                try
                {
                    Control control = content.Control;
                    control.Dock = DockStyle.Fill;
                    Controls.Add(control);
                }
                catch (Exception ex)
                {
                    MessageService.ShowError(ex, "Error in IPadContent.Control");
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing)
            {
                if (padDescriptor != null)
                {
                    padDescriptor.Dispose();
                    padDescriptor = null;
                }
            }
        }

        public override string ToString()
        {
            return "[PadContentWrapper " + padDescriptor.Class + "]";
        }

        protected override string GetPersistString()
        {
            return padDescriptor.Class;
        }
    }


    public class ViewContentWrapper : DockContent
    {
        ISolutionView content;
        public ISolutionView SolutionView
        {
            get { return content; }
        }

        public ISolutionView Solution
        {
            get
            {
                return content;
            }
        }

        /// <summary>
        /// Required designer variable.
        /// </summary>
        //private System.ComponentModel.IContainer components = null;

        public ViewContentWrapper(ISolutionView content)
        {           
            this.SuspendLayout();


            this.content = content;
            this.Text = content.Title;
            content.DockContent = this;

            content.Sln.TitleChanged += new EventHandler(content_TitleChanged);

            content.Control.Dock = System.Windows.Forms.DockStyle.Fill;
            content.Control.Location = new System.Drawing.Point(0, 4);
            content.Control.Size = new System.Drawing.Size(448, 389);


            this.ClientSize = new System.Drawing.Size(448, 393);
            this.Controls.Add(content.Control);
            this.Padding = new System.Windows.Forms.Padding(0, 1, 0, 0);           

            this.ResumeLayout(false);
            this.PerformLayout();                             
        }

        protected override void OnDockChanged(EventArgs e)
        {
            base.OnDockChanged(e);
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            if (this.Controls.Count != 1) return;
            this.Controls[0].Dock = DockStyle.None;
            this.Invalidate();
            this.Controls[0].Dock = DockStyle.Fill;
            base.OnSizeChanged(e);
        }

        void content_TitleChanged(object sender, EventArgs e)
        {
            this.Text = SolutionView.Title;
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing)
            {
                if (content != null)
                {
                    //content.Dispose();
                    content = null;
                }
            }
        }
    }
    
    #endregion 
}
