﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;

namespace Base
{
    public delegate void ViewContentEventHandler(object sender, ViewContentEventArgs e);

    public class ViewContentEventArgs : System.EventArgs
    {
        ISolutionView content;

        public ISolutionView Content
        {
            get
            {
                return content;
            }
            set
            {
                content = value;
            }
        }

        public ViewContentEventArgs(ISolutionView content)
        {
            this.content = content;
        }
    }

    public class PanContentEventArgs : System.EventArgs
    {
        object content;

        public object Content
        {
            get
            {
                return content;
            }
            set
            {
                content = value;
            }
        }

        public PanContentEventArgs(object content)
        {
            this.content = content;
        }
    }

    public class SolutionEventArgs : EventArgs
    {
        Solution solution;

        public Solution Solution
        {
            get
            {
                return solution;
            }
        }

        public SolutionEventArgs(Solution solution)
        {
            this.solution = solution;
        }
    }

    public class ProjectItemEventArgs : EventArgs
    {
        IProjectItem projectItem;

        public ProjectItemEventArgs(IProjectItem projectItem)
        {
            this.projectItem = projectItem;
        }

        public IProjectItem ProjectItem
        {
            get { return projectItem; }
        }
    }


    public class ItemEventArgs : EventArgs
    {
        object _Item;

        public ItemEventArgs(Object Item)
        {
            this._Item = Item;
        }

        public object Item
        {
            get { return _Item; }
        }
    }

}
