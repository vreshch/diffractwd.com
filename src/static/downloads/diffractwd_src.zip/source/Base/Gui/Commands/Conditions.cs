﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;

namespace Base
{
    public enum WindowState
    {
        None = 0,
        Untitled = 1,
        Dirty = 2        
    }


    /// <summary>
    /// Tests the window state of the active workbench window.
    /// </summary>
    public class ActiveWindowStateConditionEvaluator : IConditionEvaluator
    {
        public bool IsValid(object caller, Condition condition)
        {
            if (Workbench.Instance == null) return false;
            if (Workbench.Instance.ActiveViewContent == null) return false;
                       

            WindowState windowState = condition.Properties.Get("windowstate", WindowState.None);
            WindowState nowindowState = condition.Properties.Get("nowindowstate", WindowState.None);


            bool isWindowStateOk = false;
            if (windowState != WindowState.None)
            {
                if ((windowState & WindowState.Dirty) > 0)
                {
                    /*
                    bool is_dirty = false;
                    foreach (ISolutionView isv in Workbench.Instance.ViewContents)
                    {
                        if (isv.IsDirty == true) is_dirty = true;
                    }
                    */
                    // Is Dirty only for main window
                    isWindowStateOk |= Workbench.Instance.ActiveViewContent.IsDirty;
                }
                if ((windowState & WindowState.Untitled) > 0)
                {
                    isWindowStateOk |= IsUntitled(Workbench.Instance.ActiveViewContent);
                }                
            }
            else
            {
                isWindowStateOk = true;
            }

            if (nowindowState != WindowState.None)
            {
                if ((nowindowState & WindowState.Dirty) > 0)
                {
                    bool is_dirty = false;
                    foreach (ISolutionView isv in Workbench.Instance.ViewContents)
                    {
                        if (isv.IsDirty == true) is_dirty = true;
                    }
                    isWindowStateOk &= !is_dirty;
                }

                if ((nowindowState & WindowState.Untitled) > 0)
                {
                    isWindowStateOk &= !IsUntitled(Workbench.Instance.ActiveViewContent);
                }               
            }
            return isWindowStateOk;
        }



        static bool IsUntitled(ISolutionView viewContent)
        {
            string file = viewContent.FileName;
            if (file == null) return false;
            else return viewContent.IsUntitled;
        }
    }
}
