﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Windows.Forms;
using ICSharpCode.Core;

namespace Base
{          
    
    public class NewFileCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            ProjectService.OpenNewFile((Workbench)this.Owner);            
        }
    }

    public class OpenFileCommand : AbstractMenuCommand
    {
        public override void Run()
        {            
            Workbench workbench = (Workbench)this.Owner;
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.CheckFileExists = true;
                dlg.DefaultExt = ".pcw";
                dlg.Filter = ProjectService.GetOpenFileFilter();
                dlg.InitialDirectory = ProjectService.GetInitialDirectory;
                
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    ProjectService.LoadFile(workbench, dlg.FileName);                                        
                }
            }
        }
    }
    
    // Blocked in main addin
    public class SaveFileCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            Workbench workbench = (Workbench)this.Owner;
            if (workbench.ActiveViewContent != null)
            {
                workbench.ActiveViewContent.Save();
            }
        }
    }

    // Blocked in main addin
    public class SaveFileAsCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            Workbench workbench = (Workbench)this.Owner;
            if (workbench.ActiveViewContent != null)
            {
                workbench.ActiveViewContent.SaveAs();
            }
        }
    }
    
    public class ExitCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            Workbench workbench = (Workbench)this.Owner;
            workbench.Close();           
        }
    }


}
