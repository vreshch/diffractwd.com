﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;


namespace Base
{
    class PropertiesBrowser : AbstractPadContent
    {

        PropertiesBrowserControl pbc = new PropertiesBrowserControl();
        public override Control Control
        {
            get
            {
                return pbc;
            }
        }
    }


    class PropertiesBrowserControl : Panel
    {

        PropertyGrid PropertyGrids = new PropertyGrid();

        public PropertiesBrowserControl()
        {
            PropertyGrids.Dock = DockStyle.Fill;
            this.Controls.Add(PropertyGrids);            
            
            if (Workbench.Instance.ActiveSolution != null)
            {
                Workbench.Instance.ActiveSolution.Selected = true;
                Redraw((object)Workbench.Instance.ActiveSolution);
            }
            this.PropertyGrids.PropertyValueChanged += new PropertyValueChangedEventHandler(PropertiesBrowserControl_PropertyValueChanged);
            Workbench.Instance.ActiveSolutionChanged += new EventHandler<SolutionEventArgs>(Instance_ActiveSolutionChanged);           
            Workbench.Instance.ItemSelectionChanged += new EventHandler<ItemEventArgs>(ItemSelectionChanged);
        }



        void PropertiesBrowserControl_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            this.Refresh();
        }

        void ItemSelectionChanged(object sender, ItemEventArgs e)
        {
            Redraw(e.Item);
        }
        
        void Redraw(object SelectedItem)
        {
            if (SelectedItem is IPropertiesEditable)
            {                                
                IPropertiesEditable ipe = (SelectedItem as IPropertiesEditable);
                
                if (ipe.PropertiesControl == null)
                {
                    // Remove all other controls; left only prop editor;
                    this.Controls.Clear();
                    this.Controls.Add(PropertyGrids);

                    PropertyGrids.Visible = true;
                    if (ipe.PropertiesControl != null) throw new NotImplementedException("Controls not implemented yet");
                    this.PropertyGrids.SelectedObject = ipe.ObjProperties;                    
                }
                else
                {
                    // Selected object have his own Editor Control
                    PropertyGrids.Visible = false;
                    this.PropertyGrids.SelectedObject = null;

                    this.Controls.Clear();                    
                    this.Controls.Add(ipe.PropertiesControl);
                    ipe.PropertiesControl.Dock = DockStyle.Fill;
                    this.Invalidate();            
                }
            }
            else
            {
                this.PropertyGrids.SelectedObject = null;
            }
        }

        void Instance_ActiveSolutionChanged(object sender, SolutionEventArgs e)
        {             
        }
    }



}