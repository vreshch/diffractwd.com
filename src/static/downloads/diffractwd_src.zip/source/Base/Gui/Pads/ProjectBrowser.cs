﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using ICSharpCode.Core;
using System.Drawing;


namespace Base
{
    class ProjectBrowserPad : AbstractPadContent
    {
        ProjectBrowserControl pbc = new ProjectBrowserControl();
        public override Control Control
        {
            get 
            {
                return pbc;                
            }
        }
    }

    class ProjectBrowserControl : TreeView
    {
        Solution DisplaedSolution;

        public ProjectBrowserControl()
        {
            this.CheckBoxes = true;
            this.Location = new System.Drawing.Point(0, 0);
            this.ImageList = CreateImageList();
            this.HideSelection = false;
            this.Name = "ProjectBrowser";
            this.LabelEdit = true;

            if (Workbench.Instance.ActiveSolution != null) RedrawTree(Workbench.Instance.ActiveSolution);
            
            Workbench.Instance.ActiveSolutionChanged += new EventHandler<SolutionEventArgs>(Workbench_ActiveSolutionChanged);
            Workbench.Instance.ProjectItemAdded += new EventHandler<ProjectItemEventArgs>(Workbench_ProjectItemAdded);
            Workbench.Instance.ProjectItemRemoved += new EventHandler<ProjectItemEventArgs>(Workbench_ProjectItemRemoved);
            Workbench.Instance.ItemSelectionChanged += new EventHandler<ItemEventArgs>(Instance_ItemSelectionChanged);            

        }
        private bool ownselect = false;
        private void Instance_ItemSelectionChanged(object sender, ItemEventArgs e)
        {                        
            
            if (!(e.Item is ISelectable)) return;            
           
            if (this.SelectedNode!=null)
            {
                if (this.SelectedNode.Tag == e.Item) return;
            }
            
            ownselect = true;
            TreeNode tn = get_recurent_selection(this.Nodes,e.Item);
            this.SelectedNode = tn;
            ownselect = false;
            this.Invalidate();
        }

        private TreeNode get_recurent_selection(TreeNodeCollection tnc, object item)
        {                        
            foreach (TreeNode tn in tnc)
            {
                if (tn.Tag == item)
                {                    
                    return tn;
                }
                TreeNode te = get_recurent_selection(tn.Nodes, item);
                if (te != null) return te;
            }
            return null;    
        }

        private ImageList CreateImageList()
        {
            ImageList im = new ImageList();
            im.ImageSize = new Size(16, 16);
            im.Images.Add(ResourceService.GetBitmap("ProjectBrowser.Main"));
            im.Images.Add(ResourceService.GetBitmap("ProjectBrowser.Powder"));
            im.Images.Add(ResourceService.GetBitmap("ProjectBrowser.Molecule"));
            im.Images.Add(ResourceService.GetBitmap("ProjectBrowser.Filter2"));            
            return im;
        }

       
        void Solution_TitleChanged(object sender, EventArgs e)
        {
            if (this.Nodes.Count!=1) return;
            this.Nodes[0].Text = (this.Nodes[0].Tag as Solution).Title;
            this.Invalidate();
        }

      
        public void Workbench_ActiveSolutionChanged(object sender, SolutionEventArgs e)
        {
            if (e.Solution == DisplaedSolution) return;
            DisplaedSolution = e.Solution;
            RedrawTree(e.Solution);
        }
        
               
        private TreeNode CreateNode(IProjectItem ipi)
        {
            TreeNode tn = new TreeNode(ipi.Title);
            tn.Checked = ipi.Visible;
            if (ipi is IPowderItem)
            {
                tn.ImageIndex = 1;
                tn.SelectedImageIndex = 1;
            }
            else
            {
                tn.ImageIndex = 2;
                tn.SelectedImageIndex = 2;
            }
            tn.Tag =ipi;


            // Create Subitem List
            foreach (IProjectSubitem ips in ipi.SubItems)
            {
                TreeNode tn2 = CreateSubNode(ips);
                tn.Nodes.Add(tn2);
            }            

            return tn;
        }

        private TreeNode CreateSubNode(IProjectSubitem ipi)
        {
            TreeNode tn = new TreeNode(ipi.Name);
            tn.Checked = ipi.Visible;           
            
            // Filter Image for subitem
            tn.ImageIndex = 3;
            tn.SelectedImageIndex = 3;
            
            tn.Tag = ipi;
            return tn;
        }

        private Solution _oldsolution = null;
        
        private void RedrawTree(Solution solution)
        {
            if (this._oldsolution != null)
            {
                _oldsolution.TitleChanged -= new EventHandler(Solution_TitleChanged);
            }
            solution.TitleChanged += new EventHandler(Solution_TitleChanged);
            
            
            this.SuspendLayout();            
            this.Nodes.Clear();
           

            TreeNode root =  this.Nodes.Add(solution.Title);
            root.ImageIndex = 0;
            root.SelectedImageIndex = 0;
            root.Tag = solution;            
            
            foreach (PowderItem pi in solution.PowderItems)
            {
                TreeNode  tn  = CreateNode(pi); // Together with subnode                
                root.Nodes.Add(tn);
            }

            foreach (MolItem pi in solution.MolItems)
            {
                TreeNode tn = CreateNode(pi);
                root.Nodes.Add(tn);
            }
            
            root.ExpandAll();
            this.ResumeLayout(true);
        }        
        
        public void Workbench_ProjectItemRemoved(object sender, ProjectItemEventArgs e)
        {
            if (e.ProjectItem.Parent != DisplaedSolution) return;
            if (this.Nodes.Count > 1) { throw new Exception("Unexpected Node count"); }
            TreeNode root = this.Nodes[0];

            foreach (TreeNode tn in root.Nodes) 
            {
                if (tn.Tag == e.ProjectItem)
                {
                    tn.Nodes.Clear();
                    root.Nodes.Remove(tn);
                    return;
                }
            }
            throw new Exception("Node not found");
        }

        public void Workbench_ProjectItemAdded(object sender, ProjectItemEventArgs e)
        {
            if (e.ProjectItem.Parent != DisplaedSolution) return;
            if (this.Nodes.Count > 1) { throw new Exception("Unexpected Node count"); }
            TreeNode root = this.Nodes[0];

            TreeNode tn = CreateNode(e.ProjectItem);            

            if (e.ProjectItem is IMolItem)
            {
                root.Nodes.Add(tn);
                root.ExpandAll();
                return;
            }
            
            // Powder Item
            int i = 0; bool f = false;
            foreach (TreeNode trn in root.Nodes)
            {
                if (f) { continue; }
                i++;
                if (trn.Tag is IMolItem) { f = true; i = i - 1; }
            }

            root.Nodes.Insert(i, tn);
            root.ExpandAll();
        }
        
        protected override void OnBeforeSelect(TreeViewCancelEventArgs e)
        {
            base.OnBeforeSelect(e);
            if (ownselect) return;
            // Deselect Node
            if (this.SelectedNode == null) return;
            if (this.SelectedNode.Tag == null) return;
            object t = this.SelectedNode.Tag;
            if (t is ISelectable)
            {
                (t as ISelectable).Selected = false;
            }
        }

        protected override void OnAfterSelect(TreeViewEventArgs e)
        {            
            base.OnAfterSelect(e);

            if (ownselect) return;

            // Select Node
            if (e.Node == null) return;
            if (e.Node.Tag == null) return;
            object t = e.Node.Tag;
            if (t is ISelectable)
            {
                (t as ISelectable).Selected = true;
            }            
        }

        protected override void OnAfterCheck(TreeViewEventArgs e)
        {
            TreeNode tn = e.Node;
            if (tn.Tag is IVisible)
            {
                IVisible ipi = (IVisible)tn.Tag;
                ipi.Visible = tn.Checked;
            }
            base.OnAfterCheck(e);
        }

        protected override void OnBeforeLabelEdit(NodeLabelEditEventArgs e)
        {
            // Allow to Edit name only of Solution and Project
            base.OnBeforeLabelEdit(e); 
                       
            if (e.Node.Tag is Solution) return;
            if (e.Node.Tag is IProjectItem) return;            
            e.CancelEdit = true;
            return;
        }

        protected override void OnAfterLabelEdit(NodeLabelEditEventArgs e)
        {
            if (e.Label != null)
            {
                if (e.Label.Length > 0)
                {
                    e.Node.EndEdit(false);
                    if (e.Node.Level == 0)
                    {//root node
                        Solution solution = (e.Node.Tag as Solution);
                        solution.Title = e.Label;
                    }
                    else
                    {// IPowderItem or IMolItem eg IProjectItem

                        IProjectItem ipi = (e.Node.Tag as IProjectItem);
                        ipi.Title = e.Label;
                    }
                }
                else
                {
                    e.CancelEdit = true;
                    MessageBox.Show("Can not set Empty value for project name", "Node Label Edit");
                    e.Node.BeginEdit();
                }
            }
            base.OnAfterLabelEdit(e);
        }



    }


  


}
