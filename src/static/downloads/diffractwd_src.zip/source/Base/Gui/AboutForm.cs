﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/


using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using ICSharpCode.Core;

namespace Base
{

    public class InfoCommand : AbstractMenuCommand
    {
        public override void Run()
        {
            using (InfoForm frm = new InfoForm())
            {
                frm.ShowDialog(this.Owner as IWin32Window);
            }
        }
    }


}