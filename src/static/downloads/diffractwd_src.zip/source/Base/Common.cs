﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Xml;


namespace Base
{
    public static class Common
    {

        public static double GetMin(double[] DoubleCollection)
        {
            double min = double.MaxValue;
            foreach (double i in DoubleCollection)
            {
                if (i < min)
                {
                    min = i;
                }
            }
            return min;
        }

        public static double GetMax(double[] DoubleCollection)
        {
            double max = double.MinValue;
            foreach (double i in DoubleCollection)
            {
                if (i > max)
                {
                    max = i;
                }
            }
            return max;
        }

        public static decimal GetMax(decimal[] DecimalCollection)
        {
            decimal max = decimal.MinValue;
            foreach (decimal i in DecimalCollection)
            {
                if (i > max)
                {
                    max = i;
                }
            }
            return max;
        }


    }
}