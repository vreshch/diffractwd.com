﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Base
{
    //:: TODO Load from xml check color
    public static class ColorProvider
    {
        static int id = 0;
        public static Color NextColor
        {
            get
            {
                id++;
                if (id == 1) return Color.Black;
                if (id == 2) return Color.Red;                
                if (id == 3) return Color.Blue;
                if (id == 4) return Color.Green;
                if (id == 5) return Color.OrangeRed;
                if (id == 6) return Color.Brown;
                if (id == 7) return Color.Yellow;
                if (id == 8) return Color.YellowGreen;
                if (id == 9) return Color.Silver;
                if (id == 10) return Color.Pink;
                if (id == 11) return Color.PaleGreen;
                if (id == 12) return Color.Orange;
                return Color.Black;
            }
        }
    }
}
