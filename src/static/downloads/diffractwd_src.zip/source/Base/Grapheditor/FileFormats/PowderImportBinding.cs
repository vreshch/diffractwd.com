﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using PowDLL;
using System.Reflection;
using System.IO;
using System.Collections.Generic;

namespace Base
{

    class PowderImportBindings : IProjectImportBinding
    {
        #region IPowderImportBinding Members

        public IProjectItem ImportFile(string fileName)
        {            
            string [] inp = new string[]{".raw", ".rd", ".ard", ".cpi" ,".dat" ,".dbw" ,".gsas" ,".mdi" ,".rig" ,".udf" ,".uxd" ,".xda" ,".xdd" ,".xy"};
            string ext = Path.GetExtension(fileName);
            string fileTitle = Path.GetFileNameWithoutExtension(fileName);
            bool supp = false;
            foreach(string s  in inp)
            {
                if (s.ToUpper().Equals(ext.ToUpper())) supp = true;
            }
            if (supp==false) return null;


            PowderFileTypes fileraw = new PowderFileTypes();

            object q = new object();
            fileraw.LoadDataFromFile(fileName, ref q, PowderFileTypes.ShowErrors.ShowErr);
            Type t = q.GetType();

            decimal LStart = 0.0M;
            decimal LStop = 0.0M;
            decimal LStep = 0.0M;
            Decimal[] y = new decimal[0];
            Single Alpha1 = 0.0F;// PowderFileTypes.DefaultAlpha1;
            Single Alpha2 = PowderFileTypes.DefaultAlpha2;
            Single Ratio = PowderFileTypes.DefaultRatio;


            //FieldInfo[] fieldlist = t.GetFields();

            FieldInfo f1 = t.GetField("Alpha1");
            if (f1 != null) Alpha1 = (Single)f1.GetValue(q);

            FieldInfo f2 = t.GetField("Alpha2");
            if (f2 != null) Alpha2 = (Single)f2.GetValue(q);

            FieldInfo f3 = t.GetField("Ratio");
            if (f3 != null) Ratio = (Single)f3.GetValue(q);

            FieldInfo f4 = t.GetField("LStart");
            if (f4 != null) LStart = (decimal)f4.GetValue(q);

            FieldInfo f5 = t.GetField("LStop");
            if (f5 != null) LStop = (decimal)f5.GetValue(q);

            FieldInfo f6 = t.GetField("LStep");
            if (f6 != null) LStep = (decimal)f6.GetValue(q);

            FieldInfo f7 = t.GetField("y");
            if (f7 != null) y = (decimal[])f7.GetValue(q);
            




            //decimal LStart = 0.0M;
            //decimal LStop = 0.0M;
            //decimal LStep = 0.0M;

            PowderItem pd = new PowderItem();
            
            pd.LStart = (double)LStart;
            pd.LStop = (double)LStop;
            pd.LStep = (double)LStep;
            pd.y = new double[y.Length];

            decimal maxY = Common.GetMax(y);

            for (int i = 0; i < y.Length; i++)
            {
                pd.y[i] = (double)(y[i] / maxY) * 100;
            }


            //pd.y = y;
            pd.Alpha1 = Alpha1;
            pd.Alpha2 = Alpha2;
            pd.Ratio = Ratio;
            pd.Title = fileTitle;


            return pd;
        }

        #endregion
    }


}
