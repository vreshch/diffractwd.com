﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;

namespace Base
{
    /*
     * Shel X file reader
     * Read Unit Cell; Determinate Unit Cell
     * Collection of atoms together with coordinates, occupancies. 
    */
    class FormatShelX : IMoleculeFormat
    {

        #region IMoleculeFormat Members

        private double MyParsed(string s)
        {
            //return Double.Parse(s);
            return Double.Parse(s, CultureInfo.InvariantCulture);// System.Globalization.NumberStyles.AllowDecimalPoint);            
        }

        private int MyParsei(string s)
        {
            return int.Parse(s);
        }

        private List<Vec3> GenerateTranslationsByLatt(int latti)
        {
            List<Vec3> trlist = new List<Vec3>();
            trlist.Add(new Vec3(0, 0, 0));

            // LATT  -7
            if (latti < 0) { latti = latti * (-1); }

            switch (latti)
            {
                //P centring
                case 1: break;

                //I centring
                case 2:
                    //x+1/2,y+1/2,z+1/2
                    trlist.Add(new Vec3(1.0 / 2.0, 1.0 / 2.0, 1.0 / 2.0));
                    break;

                //H centring
                case 3:
                    //x+1/3,y+2/3,z+2/3
                    trlist.Add(new Vec3(1.0 / 3.0, 2.0 / 3.0, 2.0 / 3.0));
                    //x+2/3,y+1/3,z+1/3
                    trlist.Add(new Vec3(2.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0));
                    break;

                //F centring
                case 4:
                    //x, 1/2+y, 1/2+z
                    trlist.Add(new Vec3(0.0, 1.0 / 2.0, 1.0 / 2.0));
                    //x+1/2, y, 1/2+z
                    trlist.Add(new Vec3(1.0 / 2.0, 0.0, 1.0 / 2.0));
                    //1/2+x, 1/2+y, z
                    trlist.Add(new Vec3(1.0 / 2.0, 1.0 / 2.0, 0.0));
                    break;

                //A centring
                case 5:
                    //x, 1/2+y, 1/2+z    
                    trlist.Add(new Vec3(0.0, 1.0 / 2.0, 1.0 / 2.0));
                    break;

                //B centring
                case 6:
                    //x + 1/2, y, 1/2+z  
                    trlist.Add(new Vec3(1.0 / 2.0, 0.0, 1.0 / 2.0));
                    break;

                //C centring
                case 7:
                    //1/2+x, 1/2+y, z
                    trlist.Add(new Vec3(1.0 / 2.0, 1.0 / 2.0, 0.0));
                    break;

                default: throw new FileFormatExeption("Incorect LATT card");
            }

            return trlist;
        }


        private List<Symetry> GenerateSymmetryList(int latti, string[] symlistcards)
        {
            /*
                Thank you Patrick J.  
                LATT and SYMM instructions in SHELXL input files
                http://macxray.chem.upenn.edu/LATT.pdf
            */
            /*
                Based on LATT and SYMM cards the fuction 
                return in the same format as in International Tables of Crystalography             
             */

            // List finish
            List<Symetry> xretsym = new List<Symetry>();
            xretsym.Add(new Symetry("x,y,z"));
            foreach (string s in symlistcards)
            {
                xretsym.Add(new Symetry(s));
            }


            // Generate latice translations
            bool iscentrosymetric = false;
            // LATT  -7
            if (latti > 0) { iscentrosymetric = true; }


            // else { latti = latti * (-1); }
            // List<Vec3> trlist = GenerateTranslationsByLatt(latti);


            // Add center of Symetry operations if nececary
            List<Symetry> prefinsymlist = new List<Symetry>();
            prefinsymlist.AddRange(xretsym);

            // Add centrosymetric things
            if (iscentrosymetric)
            {
                foreach (Symetry s1 in xretsym)
                {
                    prefinsymlist.Add(new Symetry((-1.0) * s1.rootation, (-1.0) * s1.translation));
                }
            }

            /*
            List<Symetry> finsymlist = new List<Symetry>();
            finsymlist.AddRange(prefinsymlist);

            // List finish
            foreach (Vec3 s1 in trlist)
            {
                foreach (Symetry s2 in prefinsymlist)
                {
                    finsymlist.Add(s2 + s1); 
                }
            }
            */

            return prefinsymlist;
        }


        public void LoadMolecule(IMolecule molecule, StreamReader InputFile, MoleculeRecord[] structure_list, string data_block)
        {
            string cell = null;
            string sfac = null;
            string fvar = null; // defalut
            string latt = "LATT 1"; // defalut
            List<string> symm = new List<string>();
            List<string> atomcards = new List<string>();

            bool fileover = false;
            string input;
            Regex r = new Regex(@"\s+");

            //string myString = r.Replace(myString, \"\");
            //string[] instruc = ;
            List<string> instructions = new List<string>();
            instructions.AddRange(new string[] { "REM ", "MOVE", "SWAT", "WPDB", "BASF", "EXTI", "FVAR", "WGHT", "FRAG", "FEND", "REM ", "CELL", "ZERR", "LATT", "SYMM", "SFAC", "UNIT", "GRID", "MOLE", "FMAP", "PLAN", "AFIX", "TWIN", "SPEC", "OMIT", "MERG", "SUMP", "RESI", "SHEL", "MORE", "TIME", "L.S.", "CGLS", "ACTA", "DAMP", "LIST", "PART", "DISP", "HKLF", "SLIM", "TITL", "SIZE", "EQIV", "EXYZ", "EADP", "BOND", "FREE", "BIND", "DFIX", "SAME", "CONF", "RTAB", "MPLA", "FLAT", "CHIV", "BLOC", "DELU", "SIMU", "ISOR", "SADI", "ANIS", "CONN", "HFIX", "LAUE", "BUMP", "TEMP", "DEFS", "ABSC", "FACE", "EMPI", "LAMI", "HOPE", "DMAT", "SKIP" });


            while (((input = InputFile.ReadLine()) != null) & (!fileover))
            {
                input = input.Trim();
                if (input.StartsWith("REM", true, null)) continue;
                if (input.StartsWith("CELL", true, null)) cell = r.Replace(input, " ");
                if (input.StartsWith("SFAC", true, null)) sfac = r.Replace(input, " ");
                if (input.StartsWith("LATT", true, null)) latt = r.Replace(input, " ");
                if (input.StartsWith("SYMM", true, null)) symm.Add(r.Replace(input, " "));
                if (input.StartsWith("FVAR", true, null))
                {
                    if (fvar == null) { fvar = r.Replace(input, " "); }
                    else
                    {// Multiple FVAR 
                        fvar = fvar + r.Replace(input, " ").Replace("FVAR ", "");
                    }
                }
                fileover = (input.StartsWith("HKLF", true, null));
                fileover = ((input.StartsWith("END", true, null)) | (fileover));
                if (fileover) { continue; }


                input = r.Replace(input, " ");
                string[] atlist = input.Split(' ');

                // skip AFIX, PART ,....

                if (instructions.Contains(atlist[0])) continue;

                // Atom ?
                if (((atlist.Length != 5) & (atlist.Length != 6)) & ((atlist.Length != 7)&(atlist.Length != 9))) continue;
                if (((atlist.Length == 5) | (atlist.Length == 6))|(atlist.Length == 7))
                {// Atom in isotrop
                    atomcards.Add(input);
                }
                else
                {   // Anis
                    if (atlist[8] != "=") continue;

                    string input2 = InputFile.ReadLine();
                    if (input2 == null) continue;

                    input2 = r.Replace(input2.Trim(), " ");
                    string[] atlist2 = input2.Split(' ');
                    if ((atlist2.Length != 4)) continue;

                    string card = String.Concat(input.Replace("=", ""), input2);
                    atomcards.Add(card);
                }

            }

            if (cell == null) throw new FileFormatExeption("CELL instruction not found");
            if (sfac == null) throw new FileFormatExeption("SFAC instruction not found");
            if (fvar == null) fvar = "FVAR 0.0";

            string[] listfvar = fvar.Replace("FVAR ", "").Split(' ');
            double[] fvara = new double[listfvar.Length];
            for (int i = 0; i < listfvar.Length; i++)
            {
                fvara[i] = MyParsed(listfvar[i]);
            }

            //"CELL wave_length  a  b  c  alpha  beta  gamma"
            //"CELL a  b  c  alpha  beta  gamma"
            double a, b, c, alpha, beta, gamma;
            string[] cella = cell.Split(' ');
            if ((cella.Length != 8) & (cella.Length != 7)) throw new FileFormatExeption("Incorect CELL card");
            {
                int n = 1;
                if (cella.Length == 7) n = 0;
                a = MyParsed(cella[n + 1]);
                b = MyParsed(cella[n + 2]);
                c = MyParsed(cella[n + 3]);

                alpha = MyParsed(cella[n + 4]);
                beta = MyParsed(cella[n + 5]);
                gamma = MyParsed(cella[n + 6]);
            }


            //SFAC C  H  N  O 
            string[] sfaca = sfac.Replace("SFAC ", "").Split(' ');
            foreach (string s in sfaca)
            {
                bool l = PeriodicTable.IsCorrectElementName(s);
                if (l == false) throw new FileFormatExeption("Unknown Element" + s);
            }

            // UNIT CELL
            int latti = MyParsei(latt.Replace("LATT ", ""));
            string[] lsymm = new string[symm.Count];
            for (int i = 0; i < symm.Count; i++) { lsymm[i] = symm[i].Replace("SYMM ", ""); }

            List<Symetry> symlist = GenerateSymmetryList(latti, lsymm);
            List<Vec3> trlist = GenerateTranslationsByLatt(latti);

            //Function work wrong in some cases; in incorect space group setings.
            int sgid = Int_cryst_tables.get_space_group_id_by_symlist(trlist, symlist);

            if (sgid == 0)
            {
                // Unable to determinate Space group; Non standart cell setings. 
                // Generate Space Group based on Symetry Cards
                throw new FileFormatExeption("Can not determinate Space Group. Mabe due to non standart setings. Check LATT SYMM cards");
            }

            SpaceGroup sg = Int_cryst_tables.get_space_group_by_id(sgid);
            string rep = "";
            foreach (Symetry s in sg.operations)
            {
                rep = rep + s.code + "\r\n";
            }

            Unit_cell uc = new Unit_cell(a, b, c, alpha, beta, gamma, sg);

            //END :: UNIT CELL            
            molecule.Cell = uc;
            /*
               Sn1   3   -0.000800    0.135400   -0.080600
               C1    1    0.000000    0.000000    0.000000     0.0417                
               H3    2    0.814481    0.157774    0.208255    11.00000   -1.20000 
               C1    1    0.207342    0.044594    0.349042    11.00000    0.03565    0.02615  0.03534   -0.00208    0.00939   -0.00169
            */

            fileover = false;

            Atom PreviousAtom = null;
            Atom PAtom = null;

            foreach (string atomcard in atomcards)
            {
                PreviousAtom = PAtom;
                PAtom = new Atom();

                string[] atlist = atomcard.Split(' ');


                PAtom.Label = atlist[0];
                // atom type 
                int typ = MyParsei(atlist[1]) - 1;
                if (typ < 0) throw new FileFormatExeption("Incorect Type of atom :" + PAtom.Label);
                if (typ > (sfaca.Length - 1)) throw new FileFormatExeption("Incorect Type of atom :" + PAtom.Label);

                PAtom.Symbol = sfaca[typ];

                double x = MyParsed(atlist[2]);
                double y = MyParsed(atlist[3]);
                double z = MyParsed(atlist[4]);

                PAtom.Position = new Vec3(x, y, z);
                if (atlist.Length > 6)
                {
                    PAtom.Ocupancy = GetOccupancy(MyParsed(atlist[5]), fvara);
                }

                if (atlist.Length == 5)
                {
                    PAtom.Uiso = 0;
                    PAtom.Ocupancy = 1.0;
                }
                if (atlist.Length == 6)
                {
                    double uiso = MyParsed(atlist[5]);
                    if (uiso > 0)
                    {
                        PAtom.Uiso = uiso;
                    }
                    PAtom.Ocupancy = 1.0;
                }

                if (atlist.Length == 7)
                {// Isotropic
                    double uiso = MyParsed(atlist[6]);
                    if (uiso < 0)
                    {
                        if (PreviousAtom == null) throw new FileFormatExeption("Incorect Uiso for: " + PAtom.Label);
                        uiso = PreviousAtom.Uiso * uiso * (-1.0);
                    }
                    PAtom.Uiso = uiso;
                }
                if (atlist.Length == 12)
                {// Anisotropic
                    // Read UANIS
                    double U11, U22, U33, U23, U13, U12;

                    U11 = MyParsed(atlist[6]);
                    U22 = MyParsed(atlist[7]);

                    U33 = MyParsed(atlist[8]);
                    U23 = MyParsed(atlist[9]);
                    U13 = MyParsed(atlist[10]);
                    U12 = MyParsed(atlist[11]);

                    double[] d = new double[9] { U11, U12, U13, 0, U22, U23, 0, 0, U33 };
                    Matrix3x3 m = new Matrix3x3(d);

                    PAtom.U = m;
                    PAtom.Uiso = ((U11 + U22 + U33) / 3.0); // Set analog of Uiso                    
                }

                // Lets Add Atom to molecule
                molecule.Atoms.Add(PAtom);
            }



        }


        private double GetOccupancy(double p, double[] fvara)
        {
            //http://stackoverflow.com/questions/14/whats-the-difference-between-math-floor-and-math-truncate-in-net            
            int fvarindex = (int)Math.Truncate(p / 10.0);
            if (fvarindex == 1)
            {
                if (p < 0) throw new FileFormatExeption("Incorect Occupany:" + p);
                return (p - 10);
            }
            if (fvarindex > (fvara.Length - 1)) throw new FileFormatExeption("Incorect Occupany. Free varible" + fvarindex + " not set");

            double occf = fvara[fvarindex];
            if (p < 0)
            {
                occf = occf * (-1);
                p = p * (-1);
            }

            double roccf = (p - (occf * 10));
            return p + occf;
        }


        public void WriteMolecule(IMolecule molecule, FileStream OutputFile)
        {
            throw new NotImplementedException();
        }




        #endregion

        #region IMoleculeFile Members

        public MoleculeRecord[] All_mol_names(StreamReader InputFile)
        {
            // Incorect use of the class
            throw new NotImplementedException();
        }

        public bool Is_multi_structural
        {
            get { return false; }
        }

        public string[] Extension
        {
            get { return new string[] { "res", "ins" }; }
        }

        public string[] Description
        {
            get { return new string[] { "Shel-X File", "Shel-X File" }; }
        }

        #endregion

    }
}
