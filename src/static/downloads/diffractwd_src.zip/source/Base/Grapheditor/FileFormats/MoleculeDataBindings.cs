﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace Base
{
    class MoleculeDataBindings : IProjectImportBinding
    {
        #region IProjectImportBinding Members

        public IProjectItem ImportFile(string fileName)
        {            
            string[] inp = new string[] { ".ins", ".res", ".cif"};
            string fileTitle = Path.GetFileNameWithoutExtension(fileName);
            string ext = Path.GetExtension(fileName);
            bool supp = false;
            foreach (string s in inp)
            {
                if (s.ToUpper().Equals(ext.ToUpper())) supp = true;
            }
            if (supp == false) return null;

            StreamReader fs = new StreamReader(fileName);

            MolItem mi = new MolItem();
            Molecule mol = new Molecule();
            mi.Molecule = mol;
            mi.Title = fileTitle;

            try
            {

                switch (ext)
                {
                    case ".ins":
                    case ".res":
                        {
                            FormatShelX f = new FormatShelX();
                            f.LoadMolecule(mol, fs, null, null);

                        }; break;
                    case ".cif":
                        {
                            FormatCIF f = new FormatCIF();
                            MoleculeRecord[] Data_Blocks = f.All_mol_names(fs);
                            if (Data_Blocks.Length == 0) { throw new Exception("Can't allocate Data Block"); }
                            fs.BaseStream.Seek(0, SeekOrigin.Begin);
                            f.LoadMolecule(mol, fs, Data_Blocks, Data_Blocks[0].ToString());
                        }; break;
                }
                return mi;
            }
            catch (FileFormatExeption e)
            {
                MessageBox.Show(e.Message);
            }
            catch (FileLoadException e)
            {
                MessageBox.Show(e.Message);
            }
            catch (FileNotFoundException e)
            {
                MessageBox.Show(e.Message);
            }
            catch (FieldAccessException e)
            {
                MessageBox.Show(e.Message);
            }
            return null;


           
        }

        #endregion
    }
}
