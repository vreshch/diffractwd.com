﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Xml;

namespace Base
{

    class FormatCIF : IMoleculeFormat
    {

        #region IMoleculeFormat Members

        public string[] allocate_data_blok(StreamReader cifile, MoleculeRecord[] structure_list, string data_block)
        {
            //string f_data = "DATA_";            
            // if (data_block != "") { f_data = f_data + data_block.ToUpper(); }
            // in_file.BaseStream.Seek

            MoleculeRecord res = null;
            if (data_block != "")
            {
                foreach (MoleculeRecord mr in structure_list)
                {
                    if (mr.ToString().Replace("CSD_CIF_", "").ToUpper() == data_block.ToUpper())
                    {
                        res = mr;
                        break;
                    }
                }
            }
            else
            {
                res = structure_list[0];
            }
            if (res == null) throw new FileFormatExeption("Can't allocate data block:" + data_block);

            cifile.BaseStream.Seek(res.SeekPos, SeekOrigin.Begin);
            /*
            while ((input = cifile.ReadLine()) != null)
            {
                if (input.Length > 5)
                {
                    if (String.Compare(input.Substring(0, 5).ToUpper(), "DATA_") == 0)
                    {
                        // replace data_ to get name
                        string Name = input.ToUpper().Replace("DATA_", "");
                        Name = Name.Replace("CSD_CIF_", "");
                        // First Data blok
                        if (data_block == "") 
                        {
                            Loaded_file_part = Name;
                            break;  
                        }
                        if (String.Compare((Name.ToUpper()), data_block) == 0)
                        {   // Data Section
                            Loaded_file_part = Name;
                            break; // Data Block Found ;
                        }                       
                    }
                }
            }
            */

            //if (input == null) throw new FileFormatExeption("Can't allocate data block:" + data_block);


            // Data of Single file
            List<string> data_list = new List<string>(100);
            string input = cifile.ReadLine();// data
            data_list.Add(input);
            while ((input = cifile.ReadLine()) != null)
            {
                if (input.StartsWith("DATA_", true, null))
                {
                    break; // found next data block, skip the loop
                }
                data_list.Add(input);
            }

            return data_list.ToArray();
        }

        private string clear_quotes(string line)
        {
            if (line == "") { return line; }
            if ((line[0] == '"') & (line[line.Length - 1] == '"'))
            {
                return line.Substring(1, line.Length - 2);
            }
            if ((line[0] == '\'') & (line[line.Length - 1] == '\''))
            {
                return line.Substring(1, line.Length - 2);
            }
            return line;
        }

        private void Parse_comment(string[] data_to_parse, ref int offset, XmlDocument doc, XmlElement data)
        {
            /* Multiline Comment Off
            string line;
            string _comment = "\n";
            while (offset < (data_to_parse.Length - 1))
            {
                offset++;
                line = data_to_parse[offset];
                if (line.Length == 0) { offset--; break; }
                if (line[0] != '#') { offset--; break; }
                _comment += line + "\n";
            }
            */
            string _comment = data_to_parse[offset];
            XmlElement c;
            c = doc.CreateElement("Comment");
            c.InnerText = _comment; // Left char "#"
            data.AppendChild(c);
        }

        private void Procces_item(string[] data_to_parse, ref int offset, XmlDocument doc, XmlElement data)
        {
            string line, param_name, param_value;
            line = data_to_parse[offset].Trim();
            int ind = line.IndexOf(' ');
            bool super_quote = false;
            param_value = "";

            if ((ind != -1))
            {
                param_name = line.Substring(1, ind - 1);
                param_value = line.Substring(ind);
                param_value = param_value.Trim();
                param_value = clear_quotes(param_value);
                if (param_value.Length == 0) { super_quote = true; }
            }
            else
            {
                param_name = line.Substring(1);
                param_name = param_name.Trim();
                super_quote = true;
            }
            if ((super_quote) & (offset < (data_to_parse.Length - 3)))
            {
                string next_str = data_to_parse[offset + 1]; // -----------------
                if (next_str.StartsWith(";"))
                {
                    // _param_name
                    //;
                    //param_value
                    //;                         
                    offset++; // ";"
                    param_value = "";
                    while (offset < (data_to_parse.Length - 1))
                    {
                        offset++;
                        line = data_to_parse[offset];
                        if (line.StartsWith(";")) break;
                        param_value += line;
                    }
                }
            }

            XmlElement item;
            param_name = param_name.Replace('/', '-');
            param_name = param_name.Replace('%', '-');
            param_name = param_name.Replace("\t", "");
            item = doc.CreateElement(param_name); // For Some CIF File allow code "/"
            item.InnerText = param_value; // Left char "#"
            data.AppendChild(item);
            // offset++;
            // throw new NotImplementedException();
        }

        private string get_loop_group(string[] goup_name, List<string> cat_name)
        {
            if (cat_name.Count == 0) return "";
            foreach (string s in goup_name)
            {
                if (cat_name[0].StartsWith(s))
                { // first element match
                    bool retno = true;
                    foreach (string l in cat_name)
                    {
                        if (!(l.StartsWith(s))) { retno = false; }
                    }
                    // All data starts with s
                    if (retno) return s;
                }
            }
            return "";
        }

        private string[] split_data_string(string line)
        {
            // Cлід врахувати коментарі ? - перевірка matches                

            string pattern = "[\\s](?=(?:[^\"']*[\"']{1}[^\"']*[\"']{1})*(?![^\"']*[\"']{1}))";
            string[] matches = Regex.Split(line, pattern);

            // Выведет 4 строки
            // AAA
            // BBB
            // "CCC;DDD"
            // EE

            // Remove empty strings from the list of Spliting                
            List<string> matches2 = new List<string>();
            for (int i = 0; i != matches.Length; ++i)
            {
                if (matches[i].Length != 0) matches2.Add(matches[i]);
            }

            return matches2.ToArray();
        }

        // retirn last readed string
        private void Procces_loop(string[] data_to_parse, ref int offset, XmlDocument doc, XmlElement data)
        {



            string line, upper_line, line2;
            int lineLength;
            List<string> Colom = new List<string>();


            // Parsing Headers ----------------------------------------------------------------
            while (offset < (data_to_parse.Length - 1))
            {
                offset++;
                line = data_to_parse[offset];
                line = line.Trim();
                lineLength = line.Length;
                upper_line = line.ToUpper();
                if (lineLength == 0) continue;
                if (line[0] == '#')
                {
                    //offset--;
                    Parse_comment(data_to_parse, ref offset, doc, data);
                    continue;
                }
                if (line[0] != '_') break;
                // up to firr space - name of colum

                // Allow comment in data_line blok -----
                int ind = line.IndexOf(' ');
                string colum_name = "";
                if ((ind != -1)) { colum_name = line.Substring(0, ind); }
                else { colum_name = line; }

                Colom.Add(colum_name); // Add Colum Name
            }
            // End Parsing Headers -------------------------------------------------------------

            // Loop Grouping -------------------------------------------------------------------
            // Контакти, центроїди

            string loop_name = "Loop";

            string[] gouping_name = new string[] { "_publ_author", "_symmetry_equiv_pos", "_atom_type", "_atom_site_aniso", "_atom_site", "_geom_torsion", "_geom_angle", "_geom_bond" };
            string cat_category = get_loop_group(gouping_name, Colom);

            if (cat_category != "")
            {   // Rename Loop
                List<string> tmp_colum = new List<string>();
                // remove first "_"
                loop_name = cat_category.Substring(1);
                foreach (string s in Colom)
                {
                    // s must starts with tmp_colum
                    string t_name = s.Substring(cat_category.Length);
                    if (t_name.Length == 0)
                    {
                        t_name = "value";
                    }
                    // remove first "_"
                    tmp_colum.Add(t_name.Substring(1));
                }
                Colom = tmp_colum;
            }

            XmlElement loop;
            loop = doc.CreateElement(loop_name);
            data.AppendChild(loop);


            // Слід добавити назву loop(по словнику) і змінити назву колонок (якщо пусті value)--------------------------


            // Begin parse Data Lines 
            offset--;
            while (offset < (data_to_parse.Length - 1))
            {
                offset++;
                line = data_to_parse[offset];
                line = line.Trim();


                if (offset < (data_to_parse.Length - 2))
                {
                    line2 = data_to_parse[offset + 1];
                    line2 = line2.Trim();
                }
                else { line2 = ""; }

                lineLength = line.Length;
                upper_line = line.ToUpper();
                if (lineLength == 0)
                {
                    offset--;
                    return;
                }
                if (line[0] == '#')
                {
                    //offset--;
                    Parse_comment(data_to_parse, ref offset, doc, data);
                    continue;
                }
                if (upper_line.StartsWith("LOOP_"))
                {   // loop іде один за іншим
                    offset--;
                    return;
                }
                if (upper_line.StartsWith("DATA_"))
                {
                    //наступий data_ блок теперішній цикл закінчено
                    offset--;
                    return;
                }
                if (upper_line.StartsWith("_"))
                {   // іде змінна, виходимо з циклу
                    offset--;
                    return;
                }

                // #------------------------------------------------------------------------------------------------------------------               

                string[] matches = split_data_string(line);





                if (matches.Length < Colom.Count)
                {
                    // Пробуємо зчитати наступні рядки якщо починаються з ";" 
                    // -------------------------------------------------------                    
                    // Не вистарчае :
                    int diff = Colom.Count - matches.Length;
                    // Check next line
                    string[] matches2 = split_data_string(line2);
                    if (matches2.Length == diff)
                    {
                        // Combine Arrar;
                        List<string> st = new List<string>();
                        st.AddRange(matches);
                        st.AddRange(matches2);
                        matches = st.ToArray();

                        offset++;
                    }
                    else
                    {
                        throw new SystemException("Error parsing data line of loop: " + line);
                    }
                    // -------------------------------------------------------------------------------------
                    // - -- Слід добавити Multi functional line тобто з ";"
                }

                // Data of line
                string[] data_line = new string[Colom.Count];

                for (int i = 0; i != matches.Length; ++i)
                {
                    if (i <= (data_line.Length - 1))
                    {
                        data_line[i] = clear_quotes(matches[i]);
                    }
                }

                // Now let's create element of line
                XmlElement row = doc.CreateElement("Item");

                // And Add Cell
                for (int i = 0; i != data_line.Length; ++i)
                {
                    XmlElement cell = doc.CreateElement(Colom[i]);
                    cell.InnerText = data_line[i];
                    row.AppendChild(cell);
                }
                // Add Row
                loop.AppendChild(row);

                /*
                string[] cool = inp.Split(' ');

                if (tokenizer.countTokens() < headerCount) {
                    logger.warn("Column count mismatch; assuming continued on next line");
                    logger.debug("Found #expected, #found: " + headerCount + ", " + tokenizer.countTokens());
                    tokenizer = new StringTokenizer(line + input.readLine());
                }
                */

            }
            return;
            // Parsing Loop Data            
        }

        //Procedure to transform cif file to XML form to get easy asses to data in Cif and Xsl transformation
        public XmlDocument Convert_to_xml(StreamReader cifile, MoleculeRecord[] structure_list, string data_block)
        {
            string line, upper_line;
            XmlElement c;
            int offset = 0;

            XmlDocument doc = new XmlDocument();
            XmlElement x = doc.CreateElement("CIF");
            doc.AppendChild(x);

            // Extract String list to parse
            string[] data_to_parse = allocate_data_blok(cifile, structure_list, data_block);

            // Add Structure Name to cif file
            XmlElement data = doc.CreateElement("Data");
            c = doc.CreateElement("Name");
            c.InnerText = data_to_parse[0].Substring(5); //.ToUpper().Replace("DATA_", "");
            data.AppendChild(c);
            doc.FirstChild.AppendChild(data);

            // MAIN LOOP 
            while (offset < (data_to_parse.Length - 1)) // EOF -- ?
            {
                offset++;
                line = data_to_parse[offset].Trim();
                int lineLength = line.Length;
                upper_line = line.ToUpper();
                // "" EMPTY STRING ?
                if (lineLength == 0) { continue; }

                // DATA_      | begining of the next data block - break reading proces
                if (lineLength > 4)
                {
                    // New Data Block
                    if (upper_line.StartsWith("DATA_")) break;
                }

                // # COMMENT  | this line is comment
                if (line[0] == '#')
                {
                    //offset--;
                    Parse_comment(data_to_parse, ref offset, doc, data);
                    continue;
                }

                // Loop
                if (upper_line.StartsWith("LOOP_"))
                {
                    //offset--;
                    Procces_loop(data_to_parse, ref offset, doc, data);
                    continue;
                }
                // Item
                if (line.StartsWith("_"))
                {
                    // offset--;// Current line is Item
                    Procces_item(data_to_parse, ref offset, doc, data);
                    //continue;
                }
            }
            return doc;
        }



        public void LoadMolecule(IMolecule molecule, StreamReader ciffile, MoleculeRecord[] structure_list, string data_block)
        {

            if (structure_list == null) throw new ArgumentException("Incorect arg ReadMolecule #2");
            XmlDocument input_xml = Convert_to_xml(ciffile, structure_list, data_block);

            molecule.info.data = input_xml;
            molecule.IsPeriodic = true;


            double a = molecule.info.get_double("cell_length_a", true);
            double b = molecule.info.get_double("cell_length_b", true);
            double c = molecule.info.get_double("cell_length_c", true);
            double alpha = molecule.info.get_double("cell_angle_alpha", true);
            double beta = molecule.info.get_double("cell_angle_beta", true);
            double gamma = molecule.info.get_double("cell_angle_gamma", true);

            int sgid = 0;

            string space_group_id = molecule.info.get_string("symmetry_Int_Tables_number", false);
            if (space_group_id != null)
            {
                if (space_group_id != "?")
                {
                    sgid = Int_cryst_tables.get_space_group_id_by_id(Int32.Parse(space_group_id));
                }
            }

            string space_group_h_m = molecule.info.get_string("symmetry_space_group_name_H-M", false);
            if ((sgid == 0) & (space_group_h_m != null))
            {
                if (space_group_h_m != "?")
                {
                    sgid = Int_cryst_tables.get_space_group_id_by_H_M(space_group_h_m);
                }
            }

            string space_group_hall = molecule.info.get_string("symmetry_space_group_name_Hall", false);
            if ((sgid == 0) & (space_group_hall != null))
            {
                if (space_group_hall != "?")
                {
                    sgid = Int_cryst_tables.get_space_group_id_by_hall_name(space_group_hall);
                }
            }

            if (sgid == 0)
            { // Try to determinate by Space group Opertions                                
                XmlNodeList symetry_list = input_xml.SelectNodes("/CIF/Data/symmetry_equiv_pos/Item");
                List<Symetry> smlist = new List<Symetry>();
                foreach (XmlNode sm in symetry_list)
                {
                    Symetry s = new Symetry(sm.InnerText);
                    smlist.Add(s);
                }
                sgid = Int_cryst_tables.get_space_group_id_by_symlist(smlist);
                // sgid ==0  - can't determinate

            }

            if (sgid == 0)
            { // Can't Determinte Space Group
                throw new FormatException("Can't determinate space group");
            }


            SpaceGroup sg = Int_cryst_tables.get_space_group_by_id(sgid);
            Unit_cell uc = new Unit_cell(a, b, c, alpha, beta, gamma, sg);
            molecule.Cell = uc;


            XmlNodeList atom_list = input_xml.SelectNodes("/CIF/Data/atom_site/Item"); //data.SelectSingleNode("/CIF/Data");

            Atom PAtom = null;
            foreach (XmlNode at_ms in atom_list)
            {
                PAtom = new Atom();
                PAtom.Symbol = molecule.info.get_string(at_ms, "type_symbol", true);
                PAtom.Label = molecule.info.get_string(at_ms, "label", true);
                PAtom.Position.X = molecule.info.get_double(at_ms, "fract_x", true);
                PAtom.Position.Y = molecule.info.get_double(at_ms, "fract_y", true);
                PAtom.Position.Z = molecule.info.get_double(at_ms, "fract_z", true);
                PAtom.Ocupancy = molecule.info.get_double(at_ms, "occupancy", 1, false);
                PAtom.Uiso = molecule.info.get_double(at_ms, "U_iso_or_equiv", 0, false);

                molecule.Atoms.Add(PAtom);
            }
        }





        public void WriteMolecule(IMolecule molecule, FileStream OutputFile)
        {
            throw new NotImplementedException();
        }



        // Generate name of all structures in file
        public MoleculeRecord[] All_mol_names(StreamReader InputFile)
        {
            List<MoleculeRecord> data_list = new List<MoleculeRecord>();

            string input;
            Int64 position = 0; //~ store position of previous line

            while ((input = InputFile.ReadLine()) != null)
            {
                if (input.StartsWith("DATA_", true, null))
                {
                    // replace data_ to get name
                    string Name = input.ToUpper().Replace("DATA_", "");
                    // also CSD_CIF_ if cif from CSD
                    Name = Name.Replace("CSD_CIF_", "");
                    // in_file.BaseStream.Position
                    // in_file.BaseStream.Seek                                                
                    data_list.Add(new MoleculeRecord(Name, position));
                }
                position += input.Length + Environment.NewLine.Length;
            }

            return data_list.ToArray();
        }



        #endregion

        #region IMoleculeFile Members

        public bool Is_multi_structural
        {
            get { return true; }
        }

        public string[] Extension
        {
            get { return new string[] { "cif" }; }
        }

        public string[] Description
        {
            get { return new string[] { "CIF File" }; }
        }

        #endregion
    }
}
