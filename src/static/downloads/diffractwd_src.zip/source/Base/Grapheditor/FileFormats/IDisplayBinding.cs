﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections;
using ICSharpCode.Core;

namespace Base
{
	/// <summary>
	/// Interface for classes that are able to open a file and create a <see cref="IViewContent"/> for it.
	/// </summary>
	public interface IDisplayBinding
	{
		/// <summary>
		/// Loads the file and opens a <see cref="IViewContent"/>.
		/// When this method returns <c>null</c>, the display binding cannot handle the file type.
		/// </summary>
		ISolutionView OpenFile(string fileName);
	}
	
	public static class DisplayBindingManager
	{
        static ArrayList DisplayBindings;
        static ArrayList ImportDataBindings;        
		
		public static ISolutionView CreateViewContent(string fileName)
		{
            if (DisplayBindings == null) 
            {
                DisplayBindings = AddInTree.BuildItems("/Workspace/DisplayBindings", null, true);
			}

            foreach (IDisplayBinding binding in DisplayBindings) 
            {
				ISolutionView content = binding.OpenFile(fileName);
				if (content != null) 
                {
					return content;
				}
			}
			return null;
		}

        public static IProjectItem CreateProjectItem(string fileName)
        {

            if (ImportDataBindings == null) 
            {
                ImportDataBindings = AddInTree.BuildItems("/Workspace/ImportDataBindings", null, true);
			}

            foreach (IProjectImportBinding binding in ImportDataBindings)
            {                
                IProjectItem projectitem = binding.ImportFile(fileName);
                if (projectitem != null)
                {
                    return projectitem;
                }
            }
            return null;
        }


	}
}
