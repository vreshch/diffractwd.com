﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Xml;
using System.ComponentModel;
using System.Drawing;
using System.Diagnostics;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Base
{
    public interface IMolItem : IProjectItem
    {
        PowderGeneratorOptions pgo
        {
            get;
            set;
        }
        Molecule Molecule
        {
            get;         
            set;
        }

        // Generatre powder before; 
        void GeneratePowder();

        // Set of tics; hold graph object
        ITicsSet TicsSet
        {
            get;
            set;
        }

        // Ticcs Design
        Color MainTicsColor
        {
            get;
        }
        Color AbsenceTicsColor
        {
            get;
        }

        bool ShowMainTics
        {
            get;
        }

        bool ShowAbsenceTics
        {
            get;
        }

    }

    [Serializable]
    public class MolItem : AProjectItem, IMolItem, IPowderGraph
    {        

        #region IMolItem Members

        private Molecule _Molecule ;
        [XmlElement(ElementName = "Molecule")]
        public Molecule Molecule
        {
            get
            {
                if (_Molecule == null) _Molecule = new Molecule();
                return _Molecule;
            }
            set
            {
                _Molecule = value;
            }
        }

        private PowderGeneratorOptions _pgo; // defalut
        
        [XmlElement(ElementName = "PowderGeneratorOptions")]
        public PowderGeneratorOptions pgo
        {
            get 
            {
                if (_pgo == null) _pgo = new PowderGeneratorOptions();
                return _pgo; 
            }
            set 
            {
                if (_y != null) throw new NullReferenceException("Can not change options - powder alredy generated");
                _pgo = value;  
            }
        }

        private PowderGenerator _pg; 
        private PowderGenerator pg
        {
            get
            {
                if (_pg == null)
                {
                    _pg = new PowderGenerator(this.Molecule, this.pgo);
                    _pg.DataChanged += new EventHandler(PowderGeneratorDataChanged);
                }
                return _pg;
            }
        }              


        private double[]  _x = null;
        [XmlIgnore]
        public double[] x
        {
            get  
            {
                if (_x == null) { SetPowderData(); }
                return _x;
            }
            set { _x = value;}
        }

        private double[] _y = null;
        public double[] y
        {
            get 
            {
                if (_y == null) { SetPowderData(); }
                return _y; 
            }
            set { _y = value; }
        }

        public double[] display_y
        {
            get 
            {
                return y;
            }
        }



        private PowderTics _tics = null;
        public PowderTics tics
        {
            get 
            {
                if (_tics == null) { SetPowderData(); }
                return _tics; 
            }
        }
                
        public void SetPowderData()
        {                                   
            IPowderGraph ipg = pg.GetGraph();                        
            this._x = ipg.x;
            this._y = ipg.display_y;
            this._tics = ipg.tics;
        }

        void PowderGeneratorDataChanged(object sender, EventArgs e)
        {
            SetPowderData();
            DoModifed(false, true);
        }

        public void GeneratePowder()
        {
            SetPowderData();
        }

        #endregion


        public override List<IProjectSubitem> SubItems
        {
            get { return new List<IProjectSubitem>(); }
        }

        #region aperiance 

        private ITicsSet _TicsSet = null;
        [XmlIgnore]
        public ITicsSet TicsSet
        {
            get { return _TicsSet; }
            set 
            {
                _TicsSet = value;
                _TicsSet.Color1 = _MainTicsColor;
                _TicsSet.Color2 = _AbsenceTicsColor;
                _TicsSet.IsVisible1 = (_ShowMainTics & this.Visible);
                _TicsSet.IsVisible2 = (_ShowAbsenceTics & this.Visible);
            }
        }
        
        private Color _MainTicsColor = Color.Blue;
        [XmlIgnore]
        public Color MainTicsColor
        {
            get {return _MainTicsColor;}
            set 
            {
                if (TicsSet != null)
                {
                    TicsSet.Color1 = value;
                }
                _MainTicsColor = value;
            }
        }
        [XmlElement(ElementName = "MainTicsColor")]
        public int MainTicsColorAsInt
        {
            get { return MainTicsColor.ToArgb(); }
            set { MainTicsColor = Color.FromArgb(value); }
        }

        private Color _AbsenceTicsColor = Color.Gray;
        [XmlIgnore]
        public Color AbsenceTicsColor
        {
            get {return _AbsenceTicsColor;}
            set 
            {
                if (TicsSet != null)
                {
                    TicsSet.Color2 = value;
                }
                _AbsenceTicsColor = value;
            } 
        }
        [XmlElement(ElementName = "AbsenceTicsColor")]
        public int AbsenceTicsColorAsInt
        {
            get { return AbsenceTicsColor.ToArgb(); }
            set { AbsenceTicsColor = Color.FromArgb(value); }
        }


        private bool _ShowMainTics = true;
        public bool ShowMainTics
        {
            get { return _ShowMainTics; }
            set 
            {
                if (TicsSet != null)
                {
                    TicsSet.IsVisible1 = value;
                }
                _ShowMainTics = value; 
            }

        }
        
        private bool _ShowAbsenceTics = true;
        public bool ShowAbsenceTics
        {
            get { return _ShowAbsenceTics; }
            set 
            {
                if (TicsSet != null)
                {
                    TicsSet.IsVisible2 = value;
                }
                _ShowAbsenceTics = value;                
            } 
        }

        public override bool Visible
        {
            get
            {
                return base.Visible;
            }
            set
            {
                if (TicsSet != null)
                {
                    if (value)
                    {
                        TicsSet.IsVisible1 = _ShowMainTics;
                        TicsSet.IsVisible2 = _ShowAbsenceTics;
                    }
                    else
                    {
                        TicsSet.IsVisible1 = false;
                        TicsSet.IsVisible2 = false; 
                    }                    
                }
                base.Visible = value;
            }
        }
        
        #endregion 


        [TypeConverter(typeof(PropertySorter))]
        private class MolItemProperties : FilterablePropertyBase
        {
            MolItem mi = null;
            ILineItem Curve
            {
                get
                {
                    return mi.LineTag;
                }
            }

            private void InvalidateControl()
            {
                mi.DoModifed(true, false);
            }

            public MolItemProperties(MolItem mi)
            { 
                this.mi = mi;
            }
           
            [PropertyOrder(10), DisplayName("IsVisible"), CategoryAttribute("Appearance"), DescriptionAttribute("Color or Curve")]
            public bool IsVisible
            {
                get
                {
                    return Curve.IsVisible;
                }
                set
                {
                    Curve.IsVisible = value;
                    InvalidateControl();
                }
            }            

            [PropertyOrder(20), DisplayName("Title"), CategoryAttribute("Appearance"), DescriptionAttribute("Title of Powder Item")]
            public string Title
            {
                get
                {
                    return mi.Title;
                }
                set
                {
                    mi.Title = value;
                    InvalidateControl();
                }
            }
            
            [PropertyOrder(30), DisplayName("Color"), CategoryAttribute("Appearance"), DescriptionAttribute("Color or Curve")]
            public Color Color
            {
                get
                {
                    return Curve.Color;
                }
                set
                {
                    Curve.Color = value;
                    InvalidateControl();
                }
            }


            [PropertyOrder(40), DisplayName("Tics Visible"), CategoryAttribute("Appearance"), DescriptionAttribute("Show main tics position")]
            public bool ShowMainTics
            {
                get
                {
                    return mi.ShowMainTics; 
                }
                set
                {
                    mi.ShowMainTics = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(50), DisplayName("Tics Color"), CategoryAttribute("Appearance"), DescriptionAttribute("Main tics Color")]
            [DynamicPropertyFilter("ShowMainTics", "True")]
            public Color MainTicsColor
            {
                get
                {
                    return mi.MainTicsColor;
                }
                set
                {
                    mi.MainTicsColor = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(60), DisplayName("Absence Tics Visible"), CategoryAttribute("Appearance"), DescriptionAttribute("Show Absence tics position")]
            public bool ShowAbsenceTics
            {
                get
                {
                    return mi.ShowAbsenceTics;
                }
                set
                {
                    mi.ShowAbsenceTics = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(70), DisplayName("Absence Tics Color"), CategoryAttribute("Appearance"), DescriptionAttribute("Absence tics Color")]
            [DynamicPropertyFilter("ShowAbsenceTics", "True")]
            public Color AbsenceTicColor
            {
                get
                {
                    return mi.AbsenceTicsColor;
                }
                set
                {
                    mi.AbsenceTicsColor  = value;
                    InvalidateControl();
                }
            }


            #region Ossolute StartX and EndX
            /*
            [PropertyOrder(80), DisplayName("Start"), CategoryAttribute("Powder Generator"), DescriptionAttribute("Start 2 Theta generation")]
            public double Start
            {
                get
                {
                    return mi.pgo.LStart;
                }
                set
                {
                    mi.pgo.LStart = value;
                }
            }

            [PropertyOrder(90), DisplayName("End"), CategoryAttribute("Powder Generator"), DescriptionAttribute("End 2 Theta generation")]
            public double End
            {
                get
                {
                    return mi.pgo.LStop;
                }
                set
                {
                    mi.pgo.LStop = value;
                }
            }
            */
            #endregion 

            [PropertyOrder(100), DisplayName("Step"), CategoryAttribute("Powder Generator"), DescriptionAttribute("Step point in generation")]
            public double Step
            {
                get
                {
                    return mi.pgo.LStep;
                }
                set
                {
                    mi.pgo.LStep = value;
                }
            }

            [PropertyOrder(110), DisplayName("Source Type"), CategoryAttribute("Powder Generator"), DescriptionAttribute("Source of generator")]
            public SourceType SourceType
            {
                get
                {
                    return mi.pgo.Source.Source;
                }
                set
                {
                    mi.pgo.Source.Source = value;
                }
            }

            [PropertyOrder(120), DisplayName("WaveType"), CategoryAttribute("Powder Generator"), DescriptionAttribute("Wave type")]
            public WaveType WaveType
            {
                get
                {
                    return mi.pgo.Source.Wave;
                }
                set
                {
                    mi.pgo.Source.Wave = value;
                }
            }

            [DynamicPropertyFilter("WaveType", "Another")]
            [PropertyOrder(130), DisplayName("Wavelength Ang"), CategoryAttribute("Powder Generator"), DescriptionAttribute("Wave Lenth in Angstrem")]
            public double WavelengthA
            {
                get
                {
                    return mi.pgo.Source.WavelengthA;
                }
                set
                {
                    mi.pgo.Source.WavelengthA = value;
                }
            }

            [PropertyOrder(140), DisplayName("FWHM"), CategoryAttribute("Profile"), DescriptionAttribute("Peak profile")]
            public double FWHM
            {
                get
                {
                    return mi.pgo.FWHM;
                }
                set
                {
                    mi.pgo.FWHM = value;
                }
            }
                        
            [PropertyOrder(150),DisplayName("Profile Function"), CategoryAttribute("Profile")]
            public ProfileType ProfileFunction
            {
                get
                {
                    return mi.pgo.Profile;
                }
                set
                {
                    if (mi.pgo.Profile == value) return;
                    mi.pgo.Profile = value;                    
                }
            }

        }

        #region IPropertiesEditable Members
        [BrowsableAttribute(false), DefaultValueAttribute(false)]
        public override object ObjProperties
        {
            get
            {
                return new MolItemProperties(this);
            }
        }

        [BrowsableAttribute(false), DefaultValueAttribute(false)]
        public override System.Windows.Forms.Control PropertiesControl
        {
            get { return null; }
        }

        #endregion
      

        public void DoModifed(bool Invadiate, bool Redraw)
        {
            OnModified(new ObjModifeedEventArgs(this, Invadiate, Redraw));
        }

        internal void DeserializationFinish()
        {
            //throw new NotImplementedException();
        }
    }


}