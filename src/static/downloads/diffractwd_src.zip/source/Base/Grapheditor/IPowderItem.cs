﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Xml;
using System.ComponentModel;
using ZedGraph;
using System.Drawing;
using System.Xml.Serialization;
using ICSharpCode.Core;
using System.Collections.Generic;

namespace Base
{
        
    public interface IPowderItem : IProjectItem
    {
        double LStart
        {
            get;
            set;
        }
        double LStop
        {
            get;
            set;
        }
        double LStep
        {
            get;
            set;
        }        
        double[] x
        {
            get;
            set;
        }
        double[] y
        {
            get;
            set;
        }        

        double[] display_y
        {
            get; 
        }

        Single Alpha1
        {
            get;
            set;
        }
        Single Alpha2
        {
            get;
            set;
        }
        Single Ratio
        {
            get;
            set;
        }
    }

    [Serializable]
    public class PowderItem : AProjectItem, IPowderItem, IPowderGraph
    {
        private double _LStart = 0.0;
        private double _LStop = 0.0;
        private double _LStep = 0.0;
        private double[] _y;
        private Single _Alpha1 = 0.0F;
        private Single _Alpha2 = 0.0F;
        private Single _Ratio = 0.0F;
        
        #region IPowderData Members

        public double LStart
        {
            get
            {
                return _LStart;
            }
            set
            {
                _LStart = value;
            }
        }
        public double LStop
        {
            get
            {
                return _LStop;
            }
            set
            {
                _LStop = value;
            }
        }
        public double LStep
        {
            get
            {
                return _LStep;
            }
            set
            {
                _LStep = value;
            }
        }    
        public float Alpha1
        {
            get
            {
                return _Alpha1;
            }
            set
            {
                _Alpha1 = value;
            }
        }
        public float Alpha2
        {
            get
            {
                return _Alpha2;
            }
            set
            {
                _Alpha2 = value;
            }
        }
        public float Ratio
        {
            get
            {
                return _Ratio;
            }
            set
            {
                _Ratio = value;
            }
        }
        public PowderTics tics
        {
            get { return null; }
        }



        // calculated field
        private double[] _x;
        [XmlIgnore]
        public double[] x
        {
            get
            {
                if (_x == null)
                {
                    _x = new double[_y.Length];
                    for (int i = 0; (i < _y.Length); i++)
                    {
                        _x[i] = (double)((i * LStep) + LStart);
                    }
                }
                return _x;
            }
            set
            {
                _x = value;
            }
        }                
        public double[] y
        {
            get
            {
                return _y;
            }
            set
            {
                _y = value;
            }
        }


        #endregion 
        
        #region Filter_Region

        protected override void subitem_VisibleChanged(object sender, ItemEventArgs e)
        {
           base.subitem_VisibleChanged(sender, e);
           // Filter selection changed;  - recalculation nececary
           if (e.Item is IPowFilter)
           {
               // recalculate display Y
               _display_y = null; 
               // Display New values
               this.DoModifed(false, true);
           }
        }

        protected override void subitem_Modified(object sender, ObjModifeedEventArgs e)
        {
            // make recalculation on change filter properties
            if (e.target is IPowFilter)
            {
                // recalculate display Y
                _display_y = null;
                // Display New values
                //this.DoModifed(false, true);
            }

            base.subitem_Modified(sender, e);
        }

        // Cashed Value;
        private double[] _display_y = null;
        // Applay Filters 
        public double[] display_y
        {
            get 
            {
                if (_display_y == null)
                {
                    // Applay Filters to all values;
                    _display_y = new double[_y.Length];
                    double[] ycopy = new double[y.Length];
                    y.CopyTo(ycopy,0);
                    PowderData pd = new PowderData(LStart, LStop, LStep, ycopy, Alpha1, Alpha2, Ratio);

                    foreach (IProjectSubitem ips in SubItems)
                    {
                        if (ips is IPowFilter)
                        {
                            IPowFilter ipf =  (ips as IPowFilter);
                            if (ipf.Visible)
                            {
                                pd = ipf.ApplayFilter(pd);
                            }
                        }
                    }
                    // take only Y data after filtering
                    _display_y = pd.y;
                }
                return _display_y;
            }
        }
                       
        #endregion


        #region IPropertiesEditable Members        
        [TypeConverter(typeof(PropertySorter))]
        private class PowderItemProperties : FilterablePropertyBase
        {
            PowderItem pi = null;
            /*ILineItem Curve
            {
                get 
                {
                    return pi.LineTag; 
                }
            } */
            
            private void InvalidateControl()
            {
                pi.DoModifed(true,false);
            }
            
            public PowderItemProperties(PowderItem pi)
            { 
                this.pi = pi;

            }

            [PropertyOrder(10), DisplayName("IsVisible"), CategoryAttribute("Appearance"), DescriptionAttribute("Color or Curve")]
            public bool IsVisible
            {
                get
                {
                    return pi.Visible;
                }
                set
                {
                    pi.Visible = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(20), DisplayName("Title"), CategoryAttribute("Appearance"), DescriptionAttribute("Title of Powder Item")]
            [DynamicPropertyFilter("IsVisible", "True")]
            public string Title
            {
                get
                {
                    return pi.Title;
                }
                set
                {
                    pi.Title = value;
                    InvalidateControl();
                }
            }  

            [PropertyOrder(30), DisplayName("Color"), CategoryAttribute("Appearance"), DescriptionAttribute("Color or Curve")]
            [DynamicPropertyFilter("IsVisible", "True")]
            public Color Color
            {
                get
                {
                    return pi.LineColor;
                }
                set
                {
                    pi.LineColor = value;
                    InvalidateControl();
                }
            }

            

             

            [PropertyOrder(40), ReadOnly(true), DisplayName("Start"), CategoryAttribute("Data"), DescriptionAttribute("Start of Graph")]
            public float PowderItemStart
            {
                get 
                {
                    return (float)pi.LStart;
                }
            }


            [PropertyOrder(50), ReadOnly(true), DisplayName("Stop"), CategoryAttribute("Data"), DescriptionAttribute("Start of Graph")]
            public float PowderItemEnd
            {
                get
                {
                    return (float)pi.LStop;
                }
            }

            [PropertyOrder(60), ReadOnly(true), DisplayName("Step"), CategoryAttribute("Data"), DescriptionAttribute("Start of Graph")]
            public float PowderItemStep
            {
                get
                {
                    return (float)pi.LStep;
                }
            }

            [PropertyOrder(70), ReadOnly(true), DisplayName("Alpha1"), CategoryAttribute("Data"), DescriptionAttribute("Start of Graph")]
            public float PowderAlpha1
            {
                get
                {
                    return (float)pi.Alpha1;
                }
            }

            [PropertyOrder(80), ReadOnly(true), DisplayName("Alpha2"), CategoryAttribute("Data"), DescriptionAttribute("Start of Graph")]
            public float PowderAlpha2
            {
                get
                {
                    return (float)pi.Alpha2;
                }
            }

            [PropertyOrder(90), ReadOnly(true), DisplayName("Ratio"), CategoryAttribute("Data"), DescriptionAttribute("Start of Graph")]
            public float PowderRatio
            {
                get
                {
                    return (float)pi.Ratio;
                }
            }
        }
        
        public override object ObjProperties        
        {
            get
            {
                PowderItemProperties pip = new PowderItemProperties(this);
                return pip;
            }
        }
       
        public override System.Windows.Forms.Control PropertiesControl
        {
            get { return null; }
        }

        #endregion


        
        private List<IProjectSubitem> _SubItems = null;
        [XmlIgnore]
        public override List<IProjectSubitem> SubItems
        {
            get 
            {
                if (_SubItems == null)
                {
                    _SubItems = new List<IProjectSubitem>();

                    foreach (IProjectSubitem subitem in AddInTree.BuildItems("/Workspace/PowderSubitems", null, false))
                    {
                        this.AddSubItem(subitem);                                       
                    }                    
                }
                return _SubItems;
            }
        }
        

        public void DoModifed(bool Invadiate, bool Redraw)
        {
            OnModified(new ObjModifeedEventArgs(this, Invadiate, Redraw));            
        }

        internal void DeserializationFinish()
        {
            //throw new NotImplementedException();
        }
    }


    public class ObjModifeedEventArgs : EventArgs
    {
        public readonly object target;
        public readonly bool InvadiateNeaded;
        public readonly bool RedrawNeaded;


        public ObjModifeedEventArgs(object target, bool InvadiateNeaded, bool RedrawNeaded)
        {
            this.target  = target;
            this.InvadiateNeaded =  InvadiateNeaded;
            this.RedrawNeaded = RedrawNeaded;
        }        
    }







}