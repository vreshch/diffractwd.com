﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Drawing;
using System.Xml.Serialization;

namespace Base
{

    [Serializable]
    public abstract class AProjectItem : IProjectItem, IPropertiesEditable, ISelectable
    {                
        #region IProjectItem

        public event EventHandler<ObjModifeedEventArgs> Modified;
        protected void OnModified(ObjModifeedEventArgs args)
        {
            if (Modified != null) Modified(this, args);
        }


        private ILineItem _GraphTag = null;
        [XmlIgnore]
        public ILineItem LineTag 
        {
            get { return _GraphTag; } 
            set 
            {               
                // Set correct properties to ILine item;
                _GraphTag = value;
                LineTag.Color = _LineColor;                
                LineTag.IsVisible = _IsVisible;
            }
        }

        private Color _LineColor = ColorProvider.NextColor;
        [XmlIgnore]
        public Color LineColor
        {
            get  { return _LineColor;  }
            set 
            {
                _LineColor = value;
                if (LineTag != null)
                {
                    LineTag.Color = value;
                }
            }
        }

        [XmlElement(ElementName = "LineColor")]
        public int LineColorAsInt
        {
            get { return LineColor.ToArgb(); }
            set { LineColor = Color.FromArgb(value); }
        }


        private string title = "Untitled";
        public string Title 
        {
            get { return title; }
            set { title = value; } 
        }

        private Solution _Parent = null;
        [XmlIgnore]
        public Solution Parent { get { return _Parent; } set { _Parent = value; } }


        public event EventHandler<ItemEventArgs> VisibleChanged;
        private void OnVisibleChanged(ItemEventArgs e)
        {
            if (VisibleChanged != null) VisibleChanged(this, e);
        }

        private bool _IsVisible = true;
        public virtual bool Visible
        {
            get 
            {
                if (LineTag!=null) LineTag.IsVisible = _IsVisible;
                return _IsVisible; 
            }
            set 
            {
                if (LineTag != null) LineTag.IsVisible = value;
                if (_IsVisible != value)
                {
                    OnVisibleChanged(new ItemEventArgs(this));
                    _IsVisible = value;
                }
            }
        }
        
        public void Close()
        {
        }
        #endregion

        #region Subitem's               
        
        [XmlIgnore]
        public abstract List<IProjectSubitem> SubItems
        {
            get;
        }
        public void AddSubItem(IProjectSubitem item)
        {            
            SubItems.Add(item);
            AttachItemEvents(item);
        }
        public void RemoveSubItem(IProjectSubitem item)
        {
            SubItems.Remove(item);
            DetachItemEvents(item);
        }

        private void AttachItemEvents(IProjectSubitem subitem)
        {
            subitem.Parent = this;
            subitem.Modified += new EventHandler<ObjModifeedEventArgs>(subitem_Modified); 
            subitem.SelectionChanged += new EventHandler<ItemEventArgs>(subitem_SelectionChanged);
            subitem.VisibleChanged += new EventHandler<ItemEventArgs>(subitem_VisibleChanged);            
        }
      
        private void DetachItemEvents(IProjectSubitem subitem)
        {
            subitem.Parent = null;
            subitem.Modified -= new EventHandler<ObjModifeedEventArgs>(subitem_Modified);
            subitem.SelectionChanged -= new EventHandler<ItemEventArgs>(subitem_SelectionChanged);
            subitem.VisibleChanged -= new EventHandler<ItemEventArgs>(subitem_VisibleChanged);
        }


        protected virtual void subitem_VisibleChanged(object sender, ItemEventArgs e)
        {
            OnVisibleChanged(new ItemEventArgs(e.Item));            
        }

        protected virtual void subitem_SelectionChanged(object sender, ItemEventArgs e)
        {
            OnSelectionChanged(new ItemEventArgs(e.Item));
        }

        protected virtual void subitem_Modified(object sender, ObjModifeedEventArgs e)
        {
            this.OnModified(new ObjModifeedEventArgs(e.target, e.InvadiateNeaded, e.RedrawNeaded));            
        }

        #endregion 


        #region ISelectable Members

        public event EventHandler<ItemEventArgs> SelectionChanged;
        
        private void OnSelectionChanged(ItemEventArgs e)
        {
            if (SelectionChanged != null) SelectionChanged(this, e);
        }

        private bool _Selected = false;
        public bool Selected
        {
            get
            {
                return _Selected;
            }
            set
            {                
                _Selected = value;             
                if (value == true)
                {
                    OnSelectionChanged(new ItemEventArgs(this));
                }
            }
        }
        #endregion


        #region IPropertiesEditable Members

        public abstract object ObjProperties
        {
            get;
        }
        public abstract System.Windows.Forms.Control PropertiesControl
        {
            get;
        }

        #endregion
    }

    
}
