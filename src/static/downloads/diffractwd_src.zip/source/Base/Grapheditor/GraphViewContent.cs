﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using ZedGraph;
using System.Text;
using ICSharpCode.Core;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Xml.Serialization;


namespace Base
{
    public class GraphDisplayBinding : IDisplayBinding
	{
		public ISolutionView OpenFile(string fileName)
		{
            string e = Path.GetExtension(fileName);
            if (e != ".pcw") { return null; }
            return new GraphViewContent(fileName);
		}
	}
    
    
    /// <summary>
	/// ViewContent showing a text file.
	/// </summary>
    public class GraphViewContent : IClipboardHandler, IUndoHandler, ISolutionView, IGraphContent
	{

        Solution _solution = null;
        public Solution Sln
        {
            get 
            {
                if (_solution == null)
                {
                    Solution sln  = new Solution(this);
                    AttachSolution(sln);
                }
                return _solution; 
            }
            set 
            {
                if ((value != _solution)&&(_solution != null))
                {                    
                   DetachSolution(_solution);
                }
                AttachSolution(value);                
            }
        }

        MyZedGraphControl zgc = new MyZedGraphControl();
        public MyZedGraphControl ZGC
        {
            get { return zgc; }
            set { zgc = value; }
        }

        public Control Control
        {
            get
            {
                return zgc;
            }
        }

        public GraphProperties Properties
        {
            get { return zgc.Properties; }
            set { zgc.Properties = value; }
        }
        
        private GraphPane graphPane 
        { 
            get { return zgc.GraphPane; } 
        }

		public GraphViewContent()
		{                        
            this.zgc.ContextMenuStrip = MenuService.CreateContextMenu(this, "/Workspace/SolutionViewer/ContextMenu");
            ApplayAxisX();
            zgc.Invalidate();
		}

        void zgc_ContextMenuBuilder(ZedGraphControl sender, ContextMenuStrip menuStrip, Point mousePt, ZedGraphControl.ContextMenuObjectState objState)
        {
            // Replace Menu Strip With New One
            //menuStrip.Items.Clear();
            //menuStrip.Items.AddRange(cm.Items);

            //ContextMenuStrip cm = MenuService.CreateContextMenu(this, "/Workspace/SolutionViewer/ContextMenu");
            //menuStrip = cm;
            //menuStrip.Opening += delegate { cm.Opening };

            /*
            menuStrip.Items.RemoveByKey("copy");            
            menuStrip.Items.RemoveByKey("save_as");
            menuStrip.Items.RemoveByKey("page_setup");
            menuStrip.Items.RemoveByKey("show_val");
            menuStrip.Items.RemoveByKey("undo_all");
            menuStrip.Items.RemoveByKey("set_default");
            // ony 2 left : print and unzoom
            */
            //ToolStripMenuItem printitem = null;
            //foreach (ToolStripMenuItem tsi in menuStrip.Items) if (tsi.Name=="print") { printitem = tsi; }

            
            

            /*
            // create a new menu item
            ToolStripMenuItem item = new ToolStripMenuItem();
            item.Name = "my_copy";
            item.Tag = "my_copy";            
            item.Text = "Copy";
            item.Click += new System.EventHandler(CopyClick);            
            menuStrip.Items.Insert(0,item);

            //here is Un Zoom

            ToolStripMenuItem item2 = new ToolStripMenuItem();
            item2.Name = "my_set_default";
            item2.Tag = "my_set_default";
            item2.Text = "Set Scale to Default";
            item2.Enabled = IsDefalutZoom;
            item2.Click += new System.EventHandler(DefalutZoomClick);
            menuStrip.Items.Insert(3, item2);

            // insert print at last position
            if (printitem != null)
            {
                menuStrip.Items.RemoveByKey("printitem");
                menuStrip.Items.Insert(menuStrip.Items.Count - 1, printitem);
            }
            */
        }

        public void CopyImage()
        {
            Graphics g = zgc.CreateGraphics();
            IntPtr hdc = g.GetHdc();
            Metafile metaFile = new Metafile(hdc, EmfType.EmfOnly);
            g.ReleaseHdc(hdc);
            g.Dispose();

            Graphics gMeta = Graphics.FromImage(metaFile);
            zgc.GraphPane.Draw(gMeta);
            gMeta.Dispose();

            ClipboardMetafileHelper.PutEnhMetafileOnClipboard(zgc.Handle, metaFile);
            MessageService.ShowMessage("Image Copied to ClipBoard");
        }

        public void Print()
        {
            this.ZGC.MyPrint();
        }
        public void PrintPreview()
        {
            this.ZGC.MyPrintPreview();
        }
        public void PrintPageSetup()
        {
            this.ZGC.MyPrintPageSetup();
        }
        public void ExportImage()
        {
            this.ZGC.MyExportImage();               
        }

        #region Zoom Commands
        public bool IsDefalutZoom
        {
            get
            {
                double DefMinx = Sln.GeDefalutMinX();
                double DefMaxx = Sln.GeDefalutMaxX();
                if (zgc.GraphPane.XAxis.Scale.Min != DefMinx) return true;
                if (zgc.GraphPane.XAxis.Scale.Max != DefMaxx) return true;
                return false;
            }
        }

        public void SetScaleToDefalut()
        {
            double DefMinx = Sln.GeDefalutMinX();
            double DefMaxx = Sln.GeDefalutMaxX();
            ScaleXAxisMin = DefMinx;
            ScaleXAxisMax = DefMaxx;
            zgc.GraphPane.ZoomStack.Clear();
            zgc.Invalidate(); 
        }

        public bool IsZoomInAllowed
        {
            get { return ZGC.IsZoomInAllowed; }
        }
        public bool IsZoomOutAllowed
        {
            get { return ZGC.IsZoomOutAllowed; }
        }
        public bool IsZoomUndoAllowed
        {
            get { return ZGC.IsZoomUndoAllowed; }
        }
        public void ZoomIn()
        {
            ZGC.MyZoomIn();
        }               
        public void ZoomOut()
        {
            ZGC.MyZoomOut();            
        }
        public void ZoomUndo()
        {
            ZGC.MyZoomUndo();
        }







        #endregion

        protected void DefalutZoomClick(object sender, System.EventArgs e)
        {
            double DefMinx = Sln.GeDefalutMinX();
            double DefMaxx = Sln.GeDefalutMaxX();
            ScaleXAxisMin = DefMinx;
            ScaleXAxisMax = DefMaxx;
            zgc.GraphPane.ZoomStack.Clear();
            zgc.Invalidate();            
        }
		
		public GraphViewContent(string fileName) : this()
		{
            ProjectService.LoadSolution(fileName, this);
            this.FileName = fileName;
            this.IsDirty = false;
		}
		

		protected bool Save(string fileName)
		{
            return ProjectService.Save(fileName, this );                       
        }

        private Form _DockContent;
        public Form DockContent
        {
            get
            {
                return _DockContent;
            }
            set
            {
                _DockContent = value;
                _DockContent.Text = this.Title;
            }
        }

        // Data :: Model

        

        #region Base ViewContent for files

        string fileName = null;
        public event EventHandler FileNameChanged;

        public string FileName
        {
            get
            {
                return fileName;
            }
            set
            {
                if (fileName != value)
                {
                    fileName = value;
                    ChangeTitleToFileName();
                    if (FileNameChanged != null)
                    {
                        FileNameChanged(this, EventArgs.Empty);
                    }
                }
            }
        }

        protected virtual void ChangeTitleToFileName()
        {
            this.Title = System.IO.Path.GetFileNameWithoutExtension(this.FileName);
        }        

        public string Title
        {
            get
            {
                return Sln.Title;
            }
            set
            {
                Sln.Title = value;
            }
        }
              

        public event EventHandler DirtyChanged;
        private bool _IsDirty = false;
        
        public bool IsDirty
        {
            get
            {
                return _IsDirty;
            }
            set
            {
                _IsDirty = value;
            }
        }

        private bool _IsUntitled = false;
        public bool IsUntitled 
        {
            get { return _IsUntitled; }
            set { _IsUntitled = value; }
        }


        public bool Save()
        {
            if (fileName == null)
            {
                return SaveAs();
            }
            else
            {
                if (Save(fileName))
                {
                    IsDirty = false;
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public virtual bool SaveAs()
        {
            return ShowSaveAsDialog(ProjectService.GetSaveFileFilter(), ".pwd", this.Sln.Title);
        }
        
        protected bool ShowSaveAsDialog(string filter, string defaultExtension, string defalutName)
        {
            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = filter;
                dlg.DefaultExt = defaultExtension;
                dlg.FileName = defalutName;
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    FileName = dlg.FileName;
                    if (Save(dlg.FileName))
                    {
                        IsDirty = false;
                        return true;
                    }
                }
            }
            return false;
        }

        public virtual bool Close()
        {
            if (this.IsDirty)
            {
                DialogResult res = MessageBox.Show("The file was modified. Do you want to save it?", "Modified file", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);
                if (res == DialogResult.Yes) return Save();
                else if (res == DialogResult.No)
                    return true; // close without saving
                else
                    return false;
            }
            else
            {
                return true;
            }
        }

        #endregion


        #region IClipboardHandler implementation
        bool IClipboardHandler.CanPaste 
        {
			get 
            {
                return false;
                //return !textBox.ReadOnly;
			}
		}
		
		bool IClipboardHandler.CanCut 
        {
			get 
            {
                return false;
                //return !textBox.ReadOnly && textBox.SelectionLength > 0;
			}
		}
		
		bool IClipboardHandler.CanCopy {
			get 
            {
                return false;
                //return textBox.SelectionLength > 0;
			}
		}
		
		bool IClipboardHandler.CanDelete {
			get 
            {
                return false;
                //return !textBox.ReadOnly && textBox.SelectionLength > 0;
			}
		}
		
		void IClipboardHandler.Paste()
		{
            throw new NotImplementedException();
            //textBox.Paste();
		}
		
		void IClipboardHandler.Cut()
		{
            throw new NotImplementedException();
			//textBox.Cut();
		}
		
		void IClipboardHandler.Copy()
		{
            throw new NotImplementedException();
            //textBox.Copy();
		}
		
		void IClipboardHandler.Delete()
		{
            throw new NotImplementedException();
            //textBox.SelectedText = "";
		}
		#endregion
		

		#region IUndoHandler implementation
		bool IUndoHandler.CanUndo {
			get {
                return false;
                //return textBox.CanUndo;
			}
		}
		
		bool IUndoHandler.CanRedo {
			get {
				return false;
			}
		}
		
		void IUndoHandler.Undo()
		{
            throw new NotImplementedException();
            //textBox.Undo();
		}
		
		void IUndoHandler.Redo()
		{
			throw new NotImplementedException();
		}
		#endregion


        #region IGraphContent Members

        public ITicsSet DrawTics(IPowderTics tics, Color Color1, Color Color2, bool ShowType1, bool ShowType2)
        {
            List<LineObj> TicsMain = new List<LineObj>();
            List<LineObj> TicsAbsence = new List<LineObj>();
            
            for (int i = 0; (i < tics.x.Length - 1); i++)
            {
                LineObj lineobj = new LineObj(tics.x[i], -2.5, tics.x[i], -0.5);               
                lineobj.IsClippedToChartRect = true;
                if (tics.type[i] == 0)
                {
                    TicsAbsence.Add(lineobj);
                }
                if (tics.type[i] == 1)
                {
                    TicsMain.Add(lineobj);
                }
            }

            // Change setings
            WITicsSet wts = new WITicsSet(TicsMain, TicsAbsence);
            wts.Color1 = Color1;
            wts.Color2 = Color2;
            wts.IsVisible1 = ShowType1;
            wts.IsVisible2 = ShowType2;

            graphPane.GraphObjList.AddRange(TicsMain.ToArray());
            graphPane.GraphObjList.AddRange(TicsAbsence.ToArray());            

            return wts;
        }

        int curvecout = 0;
        public ILineItem DrawCurve(IPowderGraph data,Color color)
        {
            //Color color = Color.Red;

            LineItem li = graphPane.AddCurve("Data" + curvecout.ToString(), data.x, data.display_y, color, SymbolType.None);
            li.IsSelectable = true;

            //graphPane.XAxis.Scale.Min = (int)Common.GetMin(data.x);
            //graphPane.XAxis.Scale.Max = (int)Common.GetMax(data.x);

            //graphPane.YAxis.Scale.Min = -3;
            //graphPane.YAxis.Scale.Max = 100;//(double)data.y.Max();

            //zgc.AxisChange();
            zgc.Invalidate();
            //curvecout++;

            ILineItem ili = (ILineItem)(new WLineItem(li));
            return ili;
        }

        public void DrawPics(IPowderPeak data)
        {
            throw new NotImplementedException();
        }
        
        public double ScaleXAxisMin
        {
            get { return ZGC.ScaleXAxisMin; }
            set  { ZGC.ScaleXAxisMin = value; }
        }
                
        // Display Axis 2 theta  options
        public double ScaleXAxisMax
        {
            get { return ZGC.ScaleXAxisMax; }
            set  { ZGC.ScaleXAxisMax = value; }
        }
      
        public void DoInvadiate()
        {
            zgc.Invalidate();
        }

        #endregion


        #region Add Project region
        
        public void AttachSolution(Solution sln)
        {
            this._solution = sln;
            sln.SetIGC(this);
            sln.SelectionChanged += new EventHandler<ItemEventArgs>(Sln_SelectionChanged);
            sln.TitleChanged += new EventHandler(sln_TitleChanged);
            sln.VisibleChanged += new EventHandler<ItemEventArgs>(sln_VisibleChanged);
            sln.Modified += new EventHandler<ObjModifeedEventArgs>(sln_Modified);
        }       
               
        public void DetachSolution(Solution sln)
        {
            sln.SelectionChanged -= new EventHandler<ItemEventArgs>(Sln_SelectionChanged);
            sln.TitleChanged -= new EventHandler(sln_TitleChanged);
            sln.VisibleChanged -= new EventHandler<ItemEventArgs>(sln_VisibleChanged);
            sln.Modified -= new EventHandler<ObjModifeedEventArgs>(sln_Modified);
            this._solution = null;
        }

        void Sln_SelectionChanged(object sender, ItemEventArgs e)
        {
            zgc.Invalidate();
        }

        void sln_VisibleChanged(object sender, ItemEventArgs e)
        {
            this.IsDirty = true;
            zgc.Invalidate();
        }

        void sln_Modified(object sender, ObjModifeedEventArgs e)
        {
            if (e.InvadiateNeaded) zgc.Invalidate();
            this.IsDirty = true;
            if (e.RedrawNeaded) RedrawContent();
        }

        void sln_TitleChanged(object sender, EventArgs e)
        {
            this.IsDirty = true;
        }

        public void Add(IProjectItem ipi)
        {
            this.Sln.Add(ipi);            
        }

        private void ApplayAxisX()
        {
            ZGC.ApplayAxisX();
        }

        public void RedrawContent()
        {
            this.graphPane.CurveList.Clear(); // Clear All Curves List
            graphPane.GraphObjList.Clear();   // Clear All Tics List
            Sln.Draw(this);  // Draw in this content
            ApplayAxisX(); // X Axis work incorently sometimes.            
        }

        #endregion
    }

    class WLineItem: ILineItem
    {
        LineItem li = null;
        public WLineItem(LineItem li)
        {
            if (li == null) throw new NullReferenceException();
            this.li = li;
        }

        #region ILineItem Members

        public Color Color
        {
            get
            {
                return li.Color;
            }
            set
            {
                li.Color = value;
            }
        }       

        public bool IsVisible
        {
            get
            {
                return li.IsVisible;
            }
            set
            {
                li.IsVisible = value;
            }
        }

        #endregion
    }

    class WITicsSet : ITicsSet
    {

        List<LineObj> Main = null;
        List<LineObj> Absence = null;
        public WITicsSet(List<LineObj> Main, List<LineObj> Absence)
        {
            if (Main == null) throw new NullReferenceException("Incoect use of WITicsSet");
            if (Absence == null) throw new NullReferenceException("Incoect use of WITicsSet");
            if (Main.Count == 0) throw new NullReferenceException("Incoect use of WITicsSet");
            // Could be zero for P-1
            //if (Absence.Count == 0) ... 
            this.Main = Main;
            this.Absence = Absence;
        }

        #region ITicsSet Members

        private Color _Color1 = Color.Red;
        public Color Color1
        {
            get
            {
                // Return color of first item;
                return _Color1;
            }
            set
            {
                _Color1 = value;
                foreach (LineObj lo in Main)
                {
                    lo.Line.Color = value;
                }
            }
        }
        
        private bool _IsVisible1 = true;
        public bool IsVisible1
        {
            get
            {
                return _IsVisible1;
            }
            set
            {
                _IsVisible1 = value;
                foreach (LineObj lo in Main)
                {
                    lo.IsVisible = value;
                }
            }
        }

        private Color _Color2;
        public Color Color2
        {
            get
            {
                return _Color2;                
            }
            set
            {
                _Color2 = value;
                foreach (LineObj lo in Absence)
                {
                    lo.Line.Color = value;
                }
            }
        }

        public bool IsVisible2
        {
            get
            {
                return Absence[0].IsVisible;
            }
            set
            {
                foreach (LineObj lo in Absence)
                {
                    lo.IsVisible = value;
                }
            }
        }

        public double Margin
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public double Size
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        #endregion
    }

    public class ClipboardMetafileHelper
    {
        [DllImport("user32.dll")]
        static extern bool OpenClipboard(IntPtr hWndNewOwner);
        [DllImport("user32.dll")]
        static extern bool EmptyClipboard();
        [DllImport("user32.dll")]
        static extern IntPtr SetClipboardData(uint uFormat, IntPtr hMem);
        [DllImport("user32.dll")]
        static extern bool CloseClipboard();
        [DllImport("gdi32.dll")]
        static extern IntPtr CopyEnhMetaFile(IntPtr hemfSrc, IntPtr hNULL);
        [DllImport("gdi32.dll")]
        static extern bool DeleteEnhMetaFile(IntPtr hemf);

        // Metafile mf is set to a state that is not valid inside this function.
        static public bool PutEnhMetafileOnClipboard(IntPtr hWnd, Metafile mf)
        {
            bool bResult = false;
            IntPtr hEMF, hEMF2;
            hEMF = mf.GetHenhmetafile(); // invalidates mf
            if (!hEMF.Equals(new IntPtr(0)))
            {
                hEMF2 = CopyEnhMetaFile(hEMF, new IntPtr(0));
                if (!hEMF2.Equals(new IntPtr(0)))
                {
                    if (OpenClipboard(hWnd))
                    {
                        if (EmptyClipboard())
                        {
                            IntPtr hRes = SetClipboardData(14 /*CF_ENHMETAFILE*/, hEMF2);
                            bResult = hRes.Equals(hEMF2);
                            CloseClipboard();
                        }
                    }
                }
                DeleteEnhMetaFile(hEMF);
            }
            return bResult;
        }
    }
}
