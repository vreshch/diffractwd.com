﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections;
using ICSharpCode.Core;
using System.Collections.Generic;
using System.Drawing;
using ZedGraph;

namespace Base
{

    public interface IGraphContent
    {
        // Draw unit cell tics
        ITicsSet DrawTics(IPowderTics data, Color Color1, Color Color2, bool ShowType1, bool ShowType2);        
        
        // Draw curve with some color 
        ILineItem DrawCurve(IPowderGraph data, Color color);

        // Draw peaks (found from peak search)
        void DrawPics(IPowderPeak data);

        // Display 2 theta options
        double ScaleXAxisMin
        {
            get;
            set;
        }
        // Display Axis 2 theta  options

        double ScaleXAxisMax
        {
            get;
            set;
        }
       

        void DoInvadiate();

        GraphProperties Properties
        {
            get;
            set;
        }
        
        MyZedGraphControl ZGC
        {
            get;
            set;
        }         
    }

    public interface ILineItem
    {
        Color Color { get; set; }       
        bool IsVisible { get; set; }
    }

    public interface ITicsSet
    {
        Color Color1 { get; set; }        
        bool IsVisible1 { get; set; }
        Color Color2 { get; set; }
        bool IsVisible2 { get; set; }
        double Margin { get; set; }
        double Size { get; set; }
    }


   
}
