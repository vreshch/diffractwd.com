﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.Globalization;

namespace Base
{
    [Serializable]
    sealed public class Matrix3x3 : ICloneable
    {
        #region Class Variables
        private double[,] _data = new double[3, 3];
        #endregion

        #region Constructors

        public Matrix3x3(double[] mat)
        {
            if (mat.Length != 9) { throw new ArgumentException("Valid Array Langth", "mat"); }
            _data[0, 0] = mat[0];
            _data[0, 1] = mat[1];
            _data[0, 2] = mat[2];
            _data[1, 0] = mat[3];
            _data[1, 1] = mat[4];
            _data[1, 2] = mat[5];
            _data[2, 0] = mat[6];
            _data[2, 1] = mat[7];
            _data[2, 2] = mat[8];
        }

        public Matrix3x3()
        {
            _data[0, 0] = 0;
            _data[0, 1] = 0;
            _data[0, 2] = 0;
            _data[1, 0] = 0;
            _data[1, 1] = 0;
            _data[1, 2] = 0;
            _data[2, 0] = 0;
            _data[2, 1] = 0;
            _data[2, 2] = 0;
        }
        #endregion

        #region Accessors & Mutators

        [XmlIgnore]
        public double this[int index1, int index2]
        {
            get
            {
                //if (index1 > 3 | index1 < 0) { throw new ArgumentException(" Out of range", "index1"); }
                //if (index2 > 3 | index2 < 0) { throw new ArgumentException(" Out of range", "index1"); }
                return _data[index1, index2];
            }
            set
            {
                //if (index1 > 3 | index1 < 0) { throw new ArgumentException(" Out of range", "index1"); }
                //if (index2 > 3 | index2 < 0) { throw new ArgumentException(" Out of range", "index1"); }
                _data[index1, index2] = value;
            }
        }

        [XmlIgnore]
        public double[,] Data
        {
            get
            {
                return _data;
            }
            set
            {
                if (value.Length != 9) { throw new ArgumentException("Incorect initialization", "Data"); }
                _data = value;
            }
        }

        [XmlArray("data")]
        [XmlArrayItem("item")]
        public double[] ldata
        {
            get { return new double[9] { _data[0, 0], _data[0, 1], _data[0, 2], _data[1, 0], _data[1, 1], _data[1, 2], _data[2, 0], _data[2, 1], _data[2, 2] }; }
            set
            {
                _data[0, 0] = value[0];
                _data[0, 1] = value[1];
                _data[0, 2] = value[2];
                _data[1, 0] = value[3];
                _data[1, 1] = value[4];
                _data[1, 2] = value[5];
                _data[2, 0] = value[6];
                _data[2, 1] = value[7];
                _data[2, 2] = value[8];
            }
        }

        #endregion

        #region Operators

        public static Matrix3x3 operator +(Matrix3x3 m1, Matrix3x3 m2)
        {
            return
                new Matrix3x3(
                new double[9]
                {
                m1[0,0]+m2[0,0],
                m1[0,1]+m2[0,1],
                m1[0,2]+m2[0,2],

                m1[1,0]+m2[1,0],
                m1[1,1]+m2[1,1],
                m1[1,2]+m2[1,2],

                m1[2,0]+m2[2,0],
                m1[2,1]+m2[2,1],
                m1[2,2]+m2[2,2],
                });
        }

        public static Matrix3x3 operator -(Matrix3x3 m1, Matrix3x3 m2)
        {
            return
            new Matrix3x3(
                 new double[9]
                {
                m1[0,0]-m2[0,0],
                m1[0,1]-m2[0,1],
                m1[0,2]-m2[0,2],

                m1[1,0]-m2[1,0],
                m1[1,1]-m2[1,1],
                m1[1,2]-m2[1,2],

                m1[2,0]-m2[2,0],
                m1[2,1]-m2[2,1],
                m1[2,2]-m2[2,2],
                });
        }

        public static Matrix3x3 operator *(Matrix3x3 m1, double f)
        {
            return new Matrix3x3(
                new double[9]
                {
                m1[0,0]*f,
                m1[0,1]*f,
                m1[0,2]*f,

                m1[1,0]*f,
                m1[1,1]*f,
                m1[1,2]*f,

                m1[2,0]*f,
                m1[2,1]*f,
                m1[2,2]*f,
                });
        }

        public static Matrix3x3 operator *(double f, Matrix3x3 m1)
        {
            return m1 * f;
        }


        public static Matrix3x3 operator *(Matrix3x3 m1, Matrix3x3 m2)
        {

            return new Matrix3x3(
                new double[9]
                {
                    (m1[0,0] * m2[0,0] + m1[1,0] * m2[0,1] + m1[2,0] * m2[0,2]),
                    (m1[0,1] * m2[0,0] + m1[1,1] * m2[0,1] + m1[2,1] * m2[0,2]),
                    (m1[0,2] * m2[0,0] + m1[1,2] * m2[0,1] + m1[2,2] * m2[0,2]),

                    (m1[0,0] * m2[1,0] + m1[1,0] * m2[1,1] + m1[2,0] * m2[1,2]),
                    (m1[0,1] * m2[1,0] + m1[1,1] * m2[1,1] + m1[2,1] * m2[1,2]),
                    (m1[0,2] * m2[1,0] + m1[1,2] * m2[1,1] + m1[2,2] * m2[1,2]),

                    (m1[0,0] * m2[2,0] + m1[1,0] * m2[2,1] + m1[2,0] * m2[2,2]),
                    (m1[0,1] * m2[2,0] + m1[1,1] * m2[2,1] + m1[2,1] * m2[2,2]),
                    (m1[0,2] * m2[2,0] + m1[1,2] * m2[2,1] + m1[2,2] * m2[2,2]),
                });
        }

        public static Vec3 operator *(Vec3 v1, Matrix3x3 m1)
        {
            return new Vec3
            (
                 new double[3]
                 {
                     v1.X*m1[0,0]+v1.Y*m1[0,1]+v1.Z*m1[0,2],
                     v1.X*m1[1,0]+v1.Y*m1[1,1]+v1.Z*m1[1,2],
                     v1.X*m1[2,0]+v1.Y*m1[2,1]+v1.Z*m1[2,2],
                 }
            );
        }

        public static Vec3 operator *(Matrix3x3 m1, Vec3 v1)
        {
            return new Vec3
            (
                 new double[3]
                 {
                     v1.X*m1[0,0]+v1.Y*m1[0,1]+v1.Z*m1[0,2],
                     v1.X*m1[1,0]+v1.Y*m1[1,1]+v1.Z*m1[1,2],
                     v1.X*m1[2,0]+v1.Y*m1[2,1]+v1.Z*m1[2,2],
                 }
            );
        }

        public static Matrix3x3 operator -(Matrix3x3 m1)
        {
            return new Matrix3x3(
                new double[9]
                {
                -m1[0,0],
                -m1[0,1],
                -m1[0,2],

                -m1[1,0],
                -m1[1,1],
                -m1[1,2],

                -m1[2,0],
                -m1[2,1],
                -m1[2,2],
                });
        }

        public static Matrix3x3 operator +(Matrix3x3 m1)
        {
            return new Matrix3x3(
                new double[9]
                {
                +m1[0,0],
                +m1[0,1],
                +m1[0,2],

                +m1[1,0],
                +m1[1,1],
                +m1[1,2],

                +m1[2,0],
                +m1[2,1],
                +m1[2,2],
                });
        }

        // Invert Matrix & mult on f     
        public static Matrix3x3 operator /(Matrix3x3 m1, double f)
        {
            return new Matrix3x3(
                new double[9]
                {
                m1[0,0]/f,
                m1[0,1]/f,
                m1[0,2]/f,

                m1[1,0]/f,
                m1[1,1]/f,
                m1[1,2]/f,

                m1[2,0]/f,
                m1[2,1]/f,
                m1[2,2]/f,
                });
        }

        // Invert Matrix & mult on f
        public static Matrix3x3 operator /(double f, Matrix3x3 m1)
        {
            return m1.Invert * f;
        }

        public double Determinant
        {
            get
            {
                double result = _data[0, 0] * (_data[1, 1] * _data[2, 2] - _data[2, 1] * _data[1, 2])
                        - _data[1, 0] * (_data[0, 1] * _data[2, 2] - _data[2, 1] * _data[0, 2])
                        + _data[2, 0] * (_data[0, 1] * _data[1, 2] - _data[1, 1] * _data[0, 2]);
                return result;
            }
        }

        public Matrix3x3 Invert
        {
            get
            {
                double d = this.Determinant;

                return
                new Matrix3x3(
                new double[9]
                {
                    (_data[1, 1] * _data[2, 2] - _data[1, 2] * _data[2, 1]) / d,
                    (-_data[0, 1] * _data[2, 2] + _data[0, 2] * _data[2, 1]) / d,
                    (_data[0, 1] * _data[1, 2] - _data[0, 2] * _data[1, 1]) / d,
                    (-_data[1, 0] * _data[2, 2] + _data[1, 2] * _data[2, 0]) / d,
                    (_data[0, 0] * _data[2, 2] - _data[0, 2] * _data[2, 0]) / d,
                    (-_data[0, 0] * _data[1, 2] + _data[0, 2] * _data[1, 0]) / d,
                    (_data[1, 0] * _data[2, 1] - _data[1, 1] * _data[2, 0]) / d,
                    (-_data[0, 0] * _data[2, 1] + _data[0, 1] * _data[2, 0]) / d,
                    (_data[0, 0] * _data[1, 1] - _data[0, 1] * _data[1, 0]) / d
                });
            }
        }

        #endregion

        #region Common Matix

        public static readonly Matrix3x3 Zero = new Matrix3x3(new double[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 });
        public static readonly Matrix3x3 Once = new Matrix3x3(new double[] { 1, 1, 1, 1, 1, 1, 1, 1, 1 });
        public static readonly Matrix3x3 Equiv = new Matrix3x3(new double[] { 1, 0, 0, 0, 1, 0, 0, 0, 1 });


        #endregion

        #region Additional. Special for Symetry

        /*
        private static double prse_sym2(ref string stp, string ch)
        {            
            double res = 0;
            if (stp.Contains(ch))
            {
                if (stp.Contains("-" + ch))
                {
                    res = -1;
                    stp = stp.Replace("-" + ch, "");
                }
                else
                {
                    stp = stp.Replace("+" + ch, "");
                    stp = stp.Replace(ch, "");
                    res = 1;
                }
            }
            else res = 0;
            return res;
             
        }
      */
        private static double prse_sym5(string stp, char ch)
        {
            double res = 0.0f;
            if (stp.Contains(ch.ToString()))
            {//1/2x,0.25*x
                if (stp.Contains("*"))
                {//0.25*x
                    string[] xpl = stp.Split('*');
                    res = prse_sym4(xpl[0]);
                    if (xpl[1] != ch.ToString()) throw new SystemException("Incorect formula");
                }
                else
                {//1/2x , x
                    if (ch.ToString() == stp) return 1;
                    res = prse_sym4(stp.Replace(ch.ToString(), ""));
                }
            }
            return res;
        }

        private static double prse_sym4(string stp)
        {
            double res = 0.0f;
            if (stp.Contains("/"))
            { // 1/2
                string[] xpl = stp.Split('/');
                res = Convert.ToSingle(xpl[0], CultureInfo.InvariantCulture) / Convert.ToSingle(xpl[1], CultureInfo.InvariantCulture);
            }
            else
            {
                //stp = stp.Replace(".", ",");
                res = Convert.ToSingle(stp, CultureInfo.InvariantCulture);
            }
            return res;
        }

        private static double[] prse_sym3(string stp)
        {
            //Example:  1/2x;  1/2 ; 0.25*x ; 1.33*z; x
            double[] res = new double[4];
            res[0] = 0; res[1] = 0;
            res[2] = 0; res[3] = 0;
            if (stp.Contains("x"))
            {//1/2x,0.25*x
                res[0] = prse_sym5(stp, 'x');
            }
            else if (stp.Contains("y"))
            {
                res[1] = prse_sym5(stp, 'y');
            }
            else if (stp.Contains("z"))
            {
                res[2] = prse_sym5(stp, 'z');
            }
            else
            {//: 1/2 0.33 
                res[3] = prse_sym4(stp);
            }
            return res;
        }

        private static double[] prse_sym2(string stp)
        {
            double[] res = new double[4];
            res[0] = 0; res[1] = 0;
            res[2] = 0; res[3] = 0;
            string[] spl = stp.Split('-');
            //  -x-y, _x-z
            for (int i = 0; i < spl.Length; i++)
            {
                if ((i == 0) & (spl[i] == "")) continue;
                double znak = -1.0f;
                if (i == 0) znak = 1.0f;

                double[] res2 = new double[4];
                res2 = prse_sym3(spl[i]);
                res[0] = res[0] + res2[0] * znak;
                res[1] = res[1] + res2[1] * znak;
                res[2] = res[2] + res2[2] * znak;
                res[3] = res[3] + res2[3] * znak;
            }
            return res;
        }

        private static double[] prse_sym1(string stp)
        {
            double[] res = new double[4];
            res[0] = 0; res[1] = 0;
            res[2] = 0; res[3] = 0;
            string[] spl = stp.Split('+');
            foreach (string sp2 in spl)
            {
                double[] res2 = new double[4];
                res2 = prse_sym2(sp2);
                res[0] = res[0] + res2[0];
                res[1] = res[1] + res2[1];
                res[2] = res[2] + res2[2];
                res[3] = res[3] + res2[3];
            }

            return res;
        }

        public static void construct(string name, out Matrix3x3 rot, out Vec3 trans)
        {
            rot = new Matrix3x3();
            trans = new Vec3(0, 0, 0);

            name = name.Replace(" ", "");
            name = name.Replace("X", "x");
            name = name.Replace("Y", "y");
            name = name.Replace("Z", "z");
            // Example: str=x,-y,1/2+z; 1/2*x+1/2*y,1/2*x+1/2*y,1/2
            string[] teglist = name.Split(',');
            string xp = teglist[0];
            string yp = teglist[1];
            string zp = teglist[2];

            double[] xs = new double[4];

            xs = Matrix3x3.prse_sym1(teglist[0]);
            rot[0, 0] = xs[0];
            rot[0, 1] = xs[1];
            rot[0, 2] = xs[2];
            trans.X = xs[3];

            xs = Matrix3x3.prse_sym1(teglist[1]);
            rot[1, 0] = xs[0];
            rot[1, 1] = xs[1];
            rot[1, 2] = xs[2];
            trans.Y = xs[3];

            xs = Matrix3x3.prse_sym1(teglist[2]);
            rot[2, 0] = xs[0];
            rot[2, 1] = xs[1];
            rot[2, 2] = xs[2];
            trans.Z = xs[3];

            return;
        }

        public static void dec_to_frac(double dec, ref double numerator, ref double denominator)
        {
            numerator = dec;
            denominator = 1.0f;
            while (numerator != (int)numerator)
            {
                numerator *= 10;
                denominator *= 10;
            }
            reduce(ref numerator, ref  denominator);
        }

        private static void reduce(ref double numer, ref double denom)
        {
            for (int i = 2; i <= numer; ++i)
            {
                if (((numer / i) == ((int)(numer / i))) && ((denom / i) == ((int)(denom / i))))
                {
                    numer /= i;
                    denom /= i;
                    --i;
                }
            }
        }

        public static string Dec2Frac_h1(double f, long max_LowerPart)
        {
            double df;
            long lUpperPart, lLowerPart;

            lUpperPart = 1;
            lLowerPart = 1;

            df = lUpperPart / lLowerPart;
            while (df != f)
            {
                if (lLowerPart > max_LowerPart) return "";
                if (df < f) lUpperPart = lUpperPart + 1;
                else
                {
                    lLowerPart = lLowerPart + 1;
                    lUpperPart = (long)Math.Round((f * (double)lLowerPart));
                }
                df = ((double)lUpperPart / (double)lLowerPart);
            }

            // виділяємо цілу частину -------------------------------------//
            return lUpperPart.ToString() + "/" + lLowerPart.ToString();
        }

        public static string Dec2Frac(double number, long max_LowerPart)
        {
            if (number == 0) return "0";
            if (number < 0) return "-" + Dec2Frac((-1) * number, max_LowerPart);
            if ((number - Math.Floor(number)) == 0) return number.ToString();

            /*
            string s = Dec2Frac_h1((number - (double)Math.Floor(number)), max_LowerPart);
            if (s=="") return number.ToString();
            if (Math.Floor(number) > 0) return Math.Floor(number) + s;
            */
            string s = Dec2Frac_h1(number, max_LowerPart);
            if (s == "") return number.ToString();
            return s;
        }

        private static string get_st3(double curr_num)
        {
            return Dec2Frac(curr_num, 20);
            /*
        
            double t = 5;
            double c_n = curr_num;
            string r = "";
            if (curr_num == 0) return "0";            
            if (curr_num < 0)
            {
                r = "-";
                c_n = -1.0f * curr_num;
            }

            double l = (3.0f / 8.0f);
            if (c_n == l)
            {
                double z = 0.0f;
                string re = Dec2Frac(1.0f+(34.0f/23.0f));
            }

            if ((Math.Abs(c_n - l)) < (double.Epsilon * 5))
            {
                double z = 1.0f;
            }


            double numerator = 0.0f;
            double denominator = 0.0f;
            //dec_to_frac(c_n, ref numerator, ref denominator);
        
            if (Math.Abs((c_n - (1.0f / 1.0f))) < (t * double.Epsilon)) return r + "1";
            if (Math.Abs((c_n - (1.0f / 2.0f))) < (t * double.Epsilon)) return r + "1/2";
            if (Math.Abs((c_n - (1.0f / 3.0f))) < (t * double.Epsilon)) return r + "1/3";
            if (Math.Abs((c_n - (2.0f / 3.0f))) < (t * double.Epsilon)) return r + "2/3";
            if (Math.Abs((c_n - (3.0f / 2.0f))) < (t * double.Epsilon)) return r + "3/2";
            if (Math.Abs((c_n - (1.0f / 4.0f))) < (t * double.Epsilon)) return r + "1/4";
            if (Math.Abs((c_n - (3.0f / 4.0f))) < (t * double.Epsilon)) return r + "3/4";
            if (Math.Abs((c_n - (5.0f / 4.0f))) < (t * double.Epsilon)) return r + "5/4";
            if (Math.Abs((c_n - (1.0f / 6.0f))) < (t * double.Epsilon)) return r + "1/6";                        
            if (Math.Abs((c_n - (1.0f / 8.0f))) < (t * double.Epsilon)) return r + "1/8";
            if (Math.Abs((c_n - (3.0f / 8.0f))) < (t * double.Epsilon)) return r + "3/8";
            if (Math.Abs((c_n - (1.0f / 16.0f))) < (t * double.Epsilon)) return r + "1/16";
              
            return Convert.ToString(curr_num);  
            */
        }

        private static string get_st2(string curr_st, string prefix, double num)
        {
            if (num == 0) return curr_st;
            string con = "";
            if ((num == 1) & (prefix != "")) { con = prefix; }
            else
            {
                con = get_st3(num) + prefix;
            }
            if ((num == -1) & (prefix != "")) { con = "-" + prefix; }
            if (curr_st == "") return (con); // if first param return                        
            if ((num < 0))
            {
                return curr_st + (con);// "-" will added automaticaly form conversion
            }
            return curr_st + "+" + (con);
        }

        private static string get_st1(double i1, double i2, double i3, double i4)
        {
            string retno = "";
            if (((i1 == 0) & (i2 == 0)) & (i3 == 0))
            {
                string x = get_st3(i4);
                return x.Replace(",", ".");
            }
            retno = get_st2(retno, "", i4);
            retno = get_st2(retno, "x", i1);
            retno = get_st2(retno, "y", i2);
            retno = get_st2(retno, "z", i3);
            return retno.Replace(",", ".");
        }

        public static string symetry_name(Matrix3x3 root, Vec3 trans)
        {
            string a1 = get_st1(root[0, 0], root[0, 1], root[0, 2], trans.X);
            string a2 = get_st1(root[1, 0], root[1, 1], root[1, 2], trans.Y);
            string a3 = get_st1(root[2, 0], root[2, 1], root[2, 2], trans.Z);
            return (a1 + ", " + a2 + ", " + a3);
        }


        #endregion


        public override int GetHashCode()
        {
            return _data.GetHashCode();
        }
        #region ICloneable Members

        public override bool Equals(object obj)
        {
            Matrix3x3 other = (Matrix3x3)obj;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (other.Data[i, j] != Data[i, j]) return false;
                }
            }
            return true;
        }

        public object Clone()
        {
            return new Matrix3x3((double[])Data.Clone());
        }

        #endregion


    }
}
