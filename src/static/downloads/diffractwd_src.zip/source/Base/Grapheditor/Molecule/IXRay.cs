﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Base
{
    public enum SourceType : short
    {
        Neutron,
        X_Ray
    }

    // do not change numbers 
    public enum WaveType : short
    {
        AuKa1 = 1,
        WKa1 = 2,
        TaKa1 = 3,
        AgKa1 = 4,
        MoKa1 = 5,
        CuKa1 = 6,
        CoKa1 = 7,
        FeKa1 = 8,
        CrKa1 = 9,
        TiKa1 = 10,
        Another = 11
    }

    [Serializable]
    public class XRaySource: IEquatable<XRaySource>
    {        
        private SourceType _source = SourceType.X_Ray;
        public SourceType Source
        {
            get { return _source; }
            set
            {
                if (value == SourceType.Neutron) throw new FileFormatExeption("Neutron Diffraction is currently not supported");
                _source = value;
            }
        }

        private WaveType _wave = WaveType.CuKa1;
        public WaveType Wave
        {
            get
            {
                if (Source == SourceType.Neutron) return WaveType.Another;
                return _wave;
            }
            set
            {
                if ((Source == SourceType.Neutron) & (value != WaveType.Another)) throw new NullReferenceException("Can not set radiation for Neutron Source ");
                if (_wave == value) return;
                if (value == WaveType.Another) 
                {                 
                    _wavelength = WavelengthA;
                    _wave = value;
                    return;
                }
                _wave = value;
                OnSourceChanged();                
            }
        }

        private double _wavelength = 0.0;

        public double WavelengthA
        {
            get
            {
                if (Wave == WaveType.Another) return _wavelength;
                return XRaySource.Type2WaveLenth(Wave);               
            }
            set
            {
                if (_wavelength == value) return;
                if (Wave == WaveType.Another)
                {
                   _wavelength = value;
                   OnSourceChanged();
                   return;
                }
                if (WavelengthA == value) return; 
                
                // Do not 
                throw new NullReferenceException("Incorect use of defalut wave length");
            }
        }
        [XmlIgnore]
        public double WavelengthKev
        {
            get
            {
                return (12.3984428 / WavelengthA);
            }
            set
            {
                WavelengthA = (12.3984428 / value);
            }
        }

        public static WaveType WaveLenth2Type(double Alpha1)
        {
            WaveType wt = WaveType.Another;
            double WaveTolerance = 0.001;
            if (Math.Abs(Alpha1 - 0.180195) < WaveTolerance) wt = WaveType.AuKa1;
            if (Math.Abs(Alpha1 - 0.209010) < WaveTolerance) wt = WaveType.WKa1;
            if (Math.Abs(Alpha1 - 0.215947) < WaveTolerance) wt = WaveType.TaKa1;
            if (Math.Abs(Alpha1 - 0.559360) < WaveTolerance) wt = WaveType.AgKa1;
            if (Math.Abs(Alpha1 - 0.709260) < WaveTolerance) wt = WaveType.MoKa1;
            if (Math.Abs(Alpha1 - 1.540520) < WaveTolerance) wt = WaveType.CuKa1;
            if (Math.Abs(Alpha1 - 1.788965) < WaveTolerance) wt = WaveType.CoKa1;
            if (Math.Abs(Alpha1 - 1.93597) < WaveTolerance) wt = WaveType.FeKa1;
            if (Math.Abs(Alpha1 - 2.289620) < WaveTolerance) wt = WaveType.CrKa1;
            if (Math.Abs(Alpha1 - 2.748510) < WaveTolerance) wt = WaveType.TiKa1;
            return wt;
        }

        public static double Type2WaveLenth(WaveType Wave)
        {            
            switch (Wave)
            {
                case WaveType.AuKa1: return 0.180195;
                case WaveType.WKa1: return 0.209010;
                case WaveType.TaKa1: return 0.215947;
                case WaveType.AgKa1: return 0.559360;
                case WaveType.MoKa1: return 0.709260;
                case WaveType.CuKa1: return 1.540520;
                case WaveType.CoKa1: return 1.788965;
                case WaveType.FeKa1: return 1.93597;
                case WaveType.CrKa1: return 2.289620;
                case WaveType.TiKa1: return 2.748510;
            }
            //WaveType.Another
            throw new NullReferenceException("Incorect use of Type2WaveLenth");
        }
        
        public event EventHandler SourceChanged;
        
        private void OnSourceChanged()
        {
            if (SourceChanged != null) SourceChanged(this, EventArgs.Empty);
        }

        public XRaySource()
        {           
        }

        // Construct X-Ray sourece based on Alpha1
        public XRaySource(double Alpha1)
        {
            Wave = XRaySource.WaveLenth2Type(Alpha1);
            if (Wave == WaveType.Another)
            {
                WavelengthA = Alpha1;
            }
        }

        #region IEquatable<XRaySource> Members

        public bool Equals(XRaySource other)
        {
            if (this.Source != other.Source) return false;
            // do not compare Wave lenth - compare 
            if (Math.Abs(WavelengthA -other.WavelengthA)>0.002) return false;                       
            return true;
        }

        #endregion
    }

    public enum ProfileType    
    {
        Gausian,
        Lorenz,
        Pearson,
        /* Voight */
    }
            
    public class PowderGeneratorOptions
    {        
        XRaySource _Source;
        public XRaySource Source 
        {
            get 
            {
                if (_Source == null)
                {
                    _Source = new XRaySource();                    
                    _Source.SourceChanged += new EventHandler(_Source_SourceChanged);

                }
                return _Source; 
            }
            set
            {                
                if (_Source != null)
                {                    
                    if (_Source.Equals(value)) return; // sources is the same
                    _Source.SourceChanged -= new EventHandler(_Source_SourceChanged);                    
                }
                _Source = value;
                _Source.SourceChanged += new EventHandler(_Source_SourceChanged);
                _Source_SourceChanged(this,EventArgs.Empty);
            }
        }

        void _Source_SourceChanged(object sender, EventArgs e)
        {
            OnFullRecalcNeaded();
        }
                               
        private double _LStart = 5.0;
        public double LStart
        {
            get { return _LStart; }
            set 
            {                
                _LStart = value;
                OnFullRecalcNeaded();
            }
        }
            
        private double _LStop = 45.0;
        public double LStop
        {
            get {return _LStop;}
            set 
            {
                _LStop = value;
                OnFullRecalcNeaded();
            }
        }

        private double _LStep = 0.02;
        public double LStep
        {
            get { return _LStep; }
            set 
            {
                _LStep = value;
                OnXYRecalcNeaded();
            } 

        }

        private double _FWHM = 0.08d;
        public double FWHM
        {
            get  { return _FWHM; }
            set 
            {
                _FWHM = value;
                OnXYRecalcNeaded();
            }
        }

        public void setRange(double LStart, double LStop)
        {
            _LStart = LStart;
            _LStop = LStop;
            OnFullRecalcNeaded();
        }
        
        public IProfileFunction ProfileFunction
        {
            get
            {
                switch (_profile)
                {
                    case ProfileType.Gausian: return new ProfileGausian();
                    case ProfileType.Lorenz: return new ProfileLorenz();
                    case ProfileType.Pearson: return new ProfilePearson(1.5);
                    /* case ProfileType.Voight: return new ProfileVoight(); */
                }
                throw new NullReferenceException();
            }
        }


        private ProfileType _profile = ProfileType.Pearson;
        public ProfileType Profile
        {
            get { return _profile; }
            set 
            {
                if (_profile == value) return;
                _profile = value;
                OnXYRecalcNeaded();
            }
        }


        public event EventHandler FullRecalcNeaded;
        private void OnFullRecalcNeaded()
        {
            if (FullRecalcNeaded != null) FullRecalcNeaded(this, EventArgs.Empty);
        }
        
        public event EventHandler XYRecalcNeaded;
        private void OnXYRecalcNeaded()
        {
            if (XYRecalcNeaded != null) XYRecalcNeaded(this, EventArgs.Empty);
        }       

        public event EventHandler ThetaRecalcNeaded;
        private void OnThetaRecalcNeaded()
        {
            if (ThetaRecalcNeaded != null) ThetaRecalcNeaded(this, EventArgs.Empty);
        }
               
        
       

        public PowderGeneratorOptions()
        {
        }                
    }

    public class Reflection : IEquatable<Reflection>
    {
        public int h = 0;
        public int k = 0;
        public int l = 0;
        public Vec3 hkl
        {
            get
            {
                return new Vec3(h, k, l);
            }
            set
            {
                h = (int)Math.Round(value.X);
                k = (int)Math.Round(value.Y);
                l = (int)Math.Round(value.Z);
            }
        }
        public double d = 0;
        public double Theta = 0;
        public double FRe = 0;
        public double FIm = 0;

        //  |F(hkl)|
        public double FMod
        {
            get
            {
                return Math.Sqrt(FRe * FRe + FIm * FIm);
            }
        }
        //  I ~ F^2
        //FRe * FRe + FIm * FIm
        public double I = 0.0;
        public double Irel = 0.0;

        public int multiplicity = 1;

        public Reflection()
        {
        }

        public Reflection(int h, int k, int l)
        {
            this.h = h;
            this.k = k;
            this.l = l;
        }

        public int NumPositiveIndexes
        {
            get
            {
                int ret = 0;
                if (h > 0) ret++;
                if (k > 0) ret++;
                if (l > 0) ret++;
                return ret;
            }
        }

        public static IComparer<Reflection> SortHKLAscending()
        {
            return (IComparer<Reflection>)new SortHKLAscendingHelper();
        }

        public static IComparer<Reflection> SortThetaAscending()
        {
            return (IComparer<Reflection>)new SortThetaAscendingHelper();
        }

        //  Design for sort in reflection List
        private class SortThetaAscendingHelper : IComparer<Reflection>
        {
            #region IComparer<Reflection> Members

            public int Compare(Reflection x, Reflection y)
            {
                if (x.Theta > y.Theta)
                    return 1;
                if (x.Theta < y.Theta)
                    return -1;
                else
                    return 0;
            }

            #endregion
        }

        private class SortHKLAscendingHelper : IComparer<Reflection>
        {
            #region IComparer<Reflection> Members

            /*Sort of reflections based on 
             cctbx›cctbx_sources›cctbx›include›cctbx›miller
             */
            public int Compare(Reflection x, Reflection y)
            {
                if (((x.h == y.h) & (x.k == y.k)) & (x.l == y.l)) return 0;
                if (x.NumPositiveIndexes > y.NumPositiveIndexes) return -1;
                if (y.NumPositiveIndexes > x.NumPositiveIndexes) return 1;

                int[] P = new int[] { 2, 0, 1 };
                for (int i = 0; i < 3; i++)
                {
                    if (x.hkl[P[i]] >= 0 && y.hkl[P[i]] < 0) return -1;
                    if (x.hkl[P[i]] < 0 && y.hkl[P[i]] >= 0) return 1;
                }

                for (int i = 0; i < 3; i++)
                {
                    if (Math.Abs((x.hkl[P[i]])) < Math.Abs((y.hkl[P[i]]))) return -1;
                    if (Math.Abs((x.hkl[P[i]])) > Math.Abs((y.hkl[P[i]]))) return 1;
                }

                return 0;
            }

            #endregion
        }

        #region IEquatable<Reflection> Members

        public bool Equals(Reflection other)
        {
            if (other.h != this.h) return false;
            if (other.k != this.k) return false;
            if (other.l != this.l) return false;
            return true;
        }

        #endregion

        
        /*
        #region IEquatable<Reflection> Members

        bool IEquatable<Reflection>.Equals(Reflection other)
        {
            throw new NotImplementedException();
        }

        #endregion
        */
    }

    public interface IProfileFunction
    {
        string[] paramname { get; }
        double[] paramdefalut { get; }
        double[] param { get; }

        // Full width at Height maxima
        double FWHM { get; set; }
        // Width at 1% of Maximum;
        // Usualy 40*FWHM
        double FW1M { get; }
        double Val(double dx, double I);

    }


    #region profile functions
    public abstract class AProfile : IProfileFunction
    {
        #region IProfileFunction Members

        public virtual string[] paramname { get { return new string[] { }; } }
        public virtual double[] paramdefalut { get { return new double[] { }; } }
        public virtual double[] param { get { return new double[] { }; } }

        private double _FWHM = 0.05;
        public double FWHM
        {
            get { return _FWHM; }
            set { _FWHM = value; }
        }

        public double FW1M
        {
            get { return FWHM * 30; }
        }

        public abstract double Val(double dx, double I);

        #endregion
    }

    public class ProfileGausian : AProfile, IProfileFunction
    {
        //gausian :
        // f(x) = a*e^((-(x-b)^2)/(2c^2))
        // FWHM  = 2*sqrt(2*ln(2))*c

        // return 2c^2
        double c2
        {
            get
            {
                //2*c^2  = FWHM/4*ln(2)
                // 4*ln(2) = 2.7725887222397812376689284858327
                return FWHM * FWHM * 2.77258872;
            }
        }

        public override double Val(double dx, double I)
        {
            return I * Math.Exp(-1 * dx * dx / c2);
        }
    }

    public class ProfileLorenz : AProfile, IProfileFunction
    {
        // return gamma^2
        double b
        {
            get
            {
                return FWHM / 2;
            }
        }

        //http://en.wikipedia.org/wiki/Cauchy_distribution
        public override double Val(double dx, double I)
        {
            return I / (1 + ((dx / b) * (dx / b)));
        }
    }

    public class ProfilePearson : AProfile, IProfileFunction
    {
        public override string[] paramname { get { return new string[] { "m" }; } }
        public override double[] paramdefalut { get { return _param; } }

        private double[] _param = new double[] { 1.8 };
        public override double[] param { get { return _param; } }

        private double m
        {
            get { return _param[0]; }
            set { _param[0] = value; }
        }
        // return gamma^2
        double b
        {
            get
            {
                return FWHM / xdparam;
            }
        }


        double _xdparam = 0.0;
        private double xdparam
        {
            get
            {
                if (_xdparam == 0)
                {// calculate
                    _xdparam = 1 / (2 * (Math.Sqrt(Math.Pow(2.0, 1.0 / m) - 1)));
                }
                return _xdparam;
            }
        }

        public override double Val(double dx, double I)
        {
            //::TODO:: Check Formula; Based on b,m ...
            return I / (Math.Pow((1 + ((dx / b) * (dx / b))), m));
        }

        public ProfilePearson(double m)
        {
            this.m = m;
        }
    }

    public class ProfileVoight : AProfile, IProfileFunction
    {
        public override double Val(double dx, double I)
        {
            return 0;
        }
    }


    #endregion



}
