﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ICSharpCode.Core;

namespace Base
{
    public interface IMoleculeFile
    {
        string[] Extension { get; }
        string[] Description { get; }
    }

    public class MoleculeRecord
    {
        private string Name;
        public readonly long SeekPos;
        public MoleculeRecord(string Name, long SeekPos)
        {
            this.Name = Name;
            this.SeekPos = SeekPos;
        }
        public override string ToString()
        {
            return Name.ToString();
        }
    }

    public interface IMoleculeFormat : IMoleculeFile
    {
        void LoadMolecule(IMolecule molecule, StreamReader InputFile, MoleculeRecord[] structure_list, string data_block);
        void WriteMolecule(IMolecule molecule, FileStream OutputFile);

        MoleculeRecord[] All_mol_names(StreamReader InputFile);
        bool Is_multi_structural { get; }
        /*
            string[] Extension    { get;  }
            string[] Description  { get;  }
        */
    }


    public interface IAtom
    {
        int id { get; }
        Vec3 Position { get; set; }
        double Ocupancy { get; set; }
        double Uiso { get; set; }
        Matrix3x3 U { get; set; }

        string Label { get; set; }
        string Symbol { get; set; }
        short Number { get; }
        double RCov { get; }
        double RVdW { get; }
    }


    public interface IUnitCell
    {
        double a { get; set; }
        double b { get; set; }
        double c { get; set; }
        double alpha { get; set; }
        double beta { get; set; }
        double gamma { get; set; }
        double volume { get; }

        SpaceGroup space_group { get; set; }
        List<Symetry> symetry_list { get; }

        Vec3 fract_2_orth(Vec3 coordinate);
        Vec3 orth_2_fract(Vec3 coordinate);
        Vec3 cryst_2_fract(Vec3 coordinate);
        Vec3 fract_2_cryst(Vec3 coordinate);
    }



    public interface IMolecule
    {                
        bool IsPeriodic { get; set; }
        IInformer info { get; set; }
        Unit_cell Cell { get; set; }
        List<Atom> Atoms { get; set; }
    }


    [Serializable]
    class FileFormatExeption : PwAppExeption
    {
        public FileFormatExeption(string message) : base(message)
        {
        }
    }

    [Serializable]
    class TableFormatExeption : PwAppExeption
    {
        public TableFormatExeption(string message) : base(message)
        {
        }
    }
    




}
