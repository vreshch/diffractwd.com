﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;

namespace Base
{
    public interface IPowderGraph
    {
        bool Visible
        {
          get;
          set;
        }
        double[] x
        {
            get;
        }
        double[] display_y
        {
            get;
        }
        PowderTics tics
        {
            get;            
        }
    }

    public interface IPowderTics
    {
        // 0 or 1; 0 - systematicaly absent; 1 - present;
        int[] type
        {
            get;
            set;
        }
        double[] x
        {
            get;
            set;
        }
    }

    // Rsepresent a list of reflections
    public class PowderTics : IPowderTics
    {
        int[] _type;
        public int[] type
        {
            get { return _type; }
            set { _type = value; }
        }
        double[] _x;
        public double[] x
        {
            get { return _x; }
            set { _x = value; }
        }

        public PowderTics(List<Reflection> Reflections, List<Reflection> AbsentReflections)
        {

            _x = new double[Reflections.Count + AbsentReflections.Count];
            _type = new int[Reflections.Count + AbsentReflections.Count];
            int i = 0;
            foreach (Reflection r in Reflections)
            {
                x[i] = r.Theta;
                type[i] = 1;
                i++;
            }
            foreach (Reflection r in AbsentReflections)
            {
                x[i] = r.Theta;
                type[i] = 0;
                i++;
            }
        }
    }

    public class  IPowderPeak
    {
        double[] I
        {
            get;
            set;
        }

        double[] x
        {
            get;
            set;
        }
    }

    public class PowderGraph : IPowderGraph
    {        
        private double[] _x;
        private double[] _y;

        #region IPowderGraph Members

        public double[] display_y
        {
            get
            {
                return _y;
            }
            set
            {
                _y = value;
            }
        }
              
        public double[] x
        {
            get
            {
                return _x;
            }
            set
            {
                _x = value;
            }
        }

        private PowderTics _tics;
        public PowderTics tics
        {
            get { return _tics; }
            set { _tics = value; } 
        }

        private bool _IsVisible = true;
        public bool Visible
        {
            get { return _IsVisible; }
            set {  _IsVisible = value; }
        }

        #endregion

        public PowderGraph(double[] x, double[] y, PowderTics tics)
        {
            this._x = x;
            this._y = y;
            this._tics = tics;
        }
    }

    public class PowderGenerator
    {
        private double RAD2GRAD2 = (180.0 / Math.PI) * 2;
        private double MATHPI2 = Math.PI * Math.PI;

        private PowderGeneratorOptions options;
        private IMolecule mol;
        private List<Reflection> Reflections = new List<Reflection>();
        private List<Reflection> AbsentReflections = new List<Reflection>();

        private double[] y = new double[] { };
        private double[] x = new double[] { };


        public PowderGenerator(IMolecule mol, PowderGeneratorOptions options)
        {
            this.mol = mol;
            
            // Set Changes to Data
            this.options = options;
            options.FullRecalcNeaded += new EventHandler(options_FullRecalcNeaded);
            options.ThetaRecalcNeaded += new EventHandler(options_ThetaRecalcNeaded);
            options.XYRecalcNeaded += new EventHandler(options_XYRecalcNeaded);
        }        

        private void MregReflections(bool MregI)
        {
            // Sort reflection based on Theta                        
            Reflections.Sort(Reflection.SortThetaAscending());

            List<Reflection> UniqueRefl = new List<Reflection>();
            List<Reflection> AbsentRefl = new List<Reflection>();

            while (Reflections.Count > 0)
            {
                // Take first reflection 
                // will be removed at the end of loop
                Reflection cr = Reflections[0];
                if (((cr.h == 0) & (cr.k == 0)) & (cr.l == 0))
                {
                    Reflections.Remove(cr);
                    continue;
                }

                //Lets' find all Equivalent Reflection
                List<Reflection> SymEqRef = new List<Reflection>();
                foreach (Reflection rl in Reflections)
                {
                    // Quick test by d spacing 
                    if (Math.Abs(rl.d - cr.d) > 0.001) continue;
                    // Full test by Space group operation
                    if (mol.Cell.space_group.AreReflEquiv(cr, rl)) SymEqRef.Add(rl);
                }

                // Remove reflections from parent list                
                foreach (Reflection rf in SymEqRef) Reflections.Remove(rf);



                // ~ Old solution 
                // Sort reflections                                
                // SymEqRef.Sort(Reflection.SortHKLAscending());                
                // First reflection in the list - is OK
                // Reflection Ref2Keep = SymEqRef[0];

                // Determinating reflection 2 keep
                Reflection Ref2Keep = SymEqRef[0];
                foreach (Reflection r in SymEqRef)
                {
                    if (Reflection.SortHKLAscending().Compare(r, Ref2Keep) < 0) Ref2Keep = r;
                }
                Ref2Keep.multiplicity = SymEqRef.Count; //multiplicity of current reflection

                // Systematicaly Absent -?
                bool Absent = mol.Cell.space_group.IsReflSystematicAbsent(Ref2Keep.h, Ref2Keep.k, Ref2Keep.l);



                if (MregI)
                {
                    // Skip sigma
                    // Calculation of average I if nececary;
                    double I = 0;
                    foreach (Reflection rf in SymEqRef) I = I + rf.I;
                    I = (I / SymEqRef.Count);
                    Ref2Keep.I = I;
                }


                if (Absent == false)
                {
                    UniqueRefl.Add(Ref2Keep);
                }
                else
                {
                    AbsentRefl.Add(Ref2Keep);
                }
            }
            // Add result to Reflections list
            Reflections.Clear();
            AbsentReflections.Clear();

            foreach (Reflection rf in UniqueRefl) Reflections.Add(rf);
            foreach (Reflection rf in AbsentRefl) AbsentReflections.Add(rf);
        }

        // Generate HKL table for structure factor calculation
        // Systemativaly absent reflection are not in the list
        private void GenerateHKLTable()
        {
            //Clear return reflection array list
            Reflections.Clear();
            AbsentReflections.Clear();

            /* data stored in reflection list */
            /* Generate list of All reflections*/
            double MaxTheta = (double)options.LStop;
            double WaveLength = options.Source.WavelengthA;
            Unit_cell Cell = mol.Cell;

            // determinate max H K L index allowed
            int maxH = (int)Math.Ceiling((Math.Sin(MaxTheta * Math.PI / 180.0) / WaveLength) * Cell.a * 2 + 1);
            int maxK = (int)Math.Ceiling((Math.Sin(MaxTheta * Math.PI / 180.0) / WaveLength) * Cell.b * 2 + 1);
            int maxL = (int)Math.Ceiling((Math.Sin(MaxTheta * Math.PI / 180.0) / WaveLength) * Cell.c * 2 + 1);


            // Fill Reflections with Full Range
            for (int h = -maxH; h < maxH; h++)
                for (int k = -maxK; k < maxK; k++)
                    for (int l = -maxL; l < maxL; l++)
                    {
                        // skip reflection Fridel pairs
                        if (((h == 0) & (k == 0)) & (l == 0)) continue; // Skip Reflection 0,0,0

                        // Calculate Theta for the reflection
                        double d = Cell.calculate_d(h, k, l);
                        double w = WaveLength / (2.0 * d);
                        double Theta = 90;
                        if (w < 1) { Theta = Math.Asin(w) * RAD2GRAD2; }

                        // ADD if Theta is OK
                        if (MaxTheta > Theta)
                        {
                            Reflection r = new Reflection(h, k, l);
                            r.d = d;
                            r.Theta = Theta;
                            Reflections.Add(r);
                        }
                    }

            // Mreg reflections and remove systematicaly absent
            MregReflections(false);
        }

        // Applay Lorentzcorrection; and calculate I based on Fre Fim ; Theta should be set correctly
        private void ApplayLorentzCorr(bool calcint)
        {
            foreach (Reflection refl in Reflections)
            {
                double Theta = (refl.Theta / 360.0) * Math.PI; // 2 Theta is stored
                double I = 0.0;
                if (calcint == true)
                {
                    I = (refl.FRe * refl.FRe + refl.FIm * refl.FIm) * refl.multiplicity / this.mol.Cell.volume;
                }
                else
                {
                    I = refl.I;
                }
                refl.I = I * ((1 + Math.Cos(2.0 * Theta) * Math.Cos(2.0 * Theta)) / (Math.Sin(Theta) * Math.Sin(Theta) * Math.Cos(Theta)));
            }
        }

        // Calculate I rel for All reflections
        private void CalculateIrel()
        {
            if (Reflections.Count == 0) return;
            double MaxI = Reflections[0].I;
            foreach (Reflection refl in Reflections) { if (MaxI < refl.I) { MaxI = refl.I; } }
            foreach (Reflection refl in Reflections)
            {
                refl.Irel = (refl.I / MaxI) * 100;
            }
        }

        

        // Calculate structure factors for list of reflection
        private void CalculateF()
        {
            /*
            double EPS = 0.01;

            // Fill Unit Cell With Atoms
            List<Atom> unit_cell_atoms = new List<Atom>();

            foreach (Atom a in mol.Atoms)
            {
                foreach (Symetry s in mol.Cell.space_group.operations)
                {
                    Vec3 position = a.Position * s.rootation + s.translation;
                    Atom a2 = new Atom(a.Symbol);
                    a2.Position = position;
                    a2.Ocupancy = a.Ocupancy;
                    a2.U = a.U;
                    a2.Uiso = a.Uiso;
                    unit_cell_atoms.Add(a2);
                }
            }


            // loop througth reflection list
            foreach (Reflection refl in Reflections)
            {
                double d = refl.d;
                // loop throught atom list

                double real = 0;
                double imag = 0;


                foreach (Atom a in unit_cell_atoms)
                {
                    // calculate f1 and f2                   
                    double freal = a.Setings.GetScateringRe(d, options.Source);
                    // Ignore Anomalous Scattering !!!
                    double fimag = a.Setings.GetScateringIm(d, options.Source);

                    double occ = 1; //a.Ocupancy;
                    double tiso = 1;
                    if (a.Uiso != 0)
                    {
                        double biso = 8*MATHPI2 * a.Uiso * a.Uiso; // B= 8*pi*pi*U*U
                        double bexpt = Math.Exp(-0.25 * biso / (d * d));      // T = e^(- B*Sin^2(theta)/lambda^2) = e^(- (1/4)*B*(1/d^2))
                        tiso = bexpt;
                    }

                    double phase = 2 * Math.PI * (a.Position.X * refl.h + a.Position.Y * refl.k + a.Position.Z * refl.l);
                    real += occ * (Math.Cos(phase) * freal);
                    imag += occ * (Math.Sin(phase) * freal);

                    // Ignore Anomalous Scattering !!!
                    //real += tiso * occ * (Math.Cos(phase) * freal - Math.Sin(phase) * fimag);
                    //imag += tiso * occ * (Math.Sin(phase) * freal + Math.Cos(phase) * fimag);                    
                }

                // reflection is calculated
                if (Math.Abs(real) < EPS) real = 0;
                if (Math.Abs(imag) < EPS) imag = 0;

                refl.FRe = real;
                refl.FIm = imag;
            }

            // Calculate relative intensities 

             ApplayLorentzCorr(true);
            // Normalization will be applay after calculation XY
            CalculateIrel(); 
             */

            double EPS = 0.01;

            // Fill Unit Cell With Atoms
            List<Atom> unit_cell_atoms = new List<Atom>();

            foreach (Atom a in mol.Atoms)
            {
                foreach (Symetry s in mol.Cell.space_group.operations)
                {
                    Vec3 position = a.Position * s.rootation + s.translation;
                    Atom a2 = new Atom(a.Symbol);
                    a2.Position = position;
                    a2.Ocupancy = a.Ocupancy;
                    a2.U = a.U;
                    a2.Uiso = a.Uiso;
                    unit_cell_atoms.Add(a2);
                }
            }


            // loop througth reflection list
            foreach (Reflection refl in Reflections)
            {
                double d = refl.d;
                // loop throught atom list

                double real = 0;
                double imag = 0;


                foreach (Atom a in unit_cell_atoms)
                {
                    // calculate f1 and f2                   
                    double freal = a.Setings.GetScateringRe(d, options.Source);
                    double fimag = a.Setings.GetScateringIm(d, options.Source);

                    double occ = a.Ocupancy;
                    double biso = MATHPI2 * a.Uiso * a.Uiso;


                    double phase = 2 * Math.PI * (a.Position.X * refl.h + a.Position.Y * refl.k + a.Position.Z * refl.l);
                    real += occ * (Math.Cos(phase) * freal);
                    imag += occ * (Math.Sin(phase) * freal);
                    //real    += bexpt * occ * (Math.Cos(phase)*freal - Math.Sin(phase)*fimag);
                    //imag    += bexpt * occ * (Math.Sin(phase)*freal + Math.Cos(phase)*fimag);                    
                }

                // reflection is calculated
                if (Math.Abs(real) < EPS) real = 0;
                if (Math.Abs(imag) < EPS) imag = 0;

                refl.FRe = real;
                refl.FIm = imag;
            }

            // Calculate relative intensities 

            ApplayLorentzCorr(true);
            // Normalization will be applay after calculation XY
            CalculateIrel();
        }

        // Normalize XY graph
        private void NormalizeXY()
        {            
            if (y.Length == 0) return;
            double maxY = 0;
            for (int i = 0; i < y.Length; i++)
            {
                if (y[i] > maxY) { maxY = y[i]; }
            }
            // Normilize
            for (int i = 0; i < y.Length; i++)
            {
                y[i] = (y[i] / maxY) * 100.0;
            }            
        }
        
        // Make Gausian Some Shape for all peaks. and save data in X and Y array
        private void CalculateXY()
        {
            // calculation of nunmber point nead to be generated
            int numpoints = (int)Math.Ceiling((options.LStop - options.LStart) / (options.LStep));
            x = new double[numpoints];
            y = new double[numpoints];

            // Profile function
            //IProfileFunction  Profile = new ProfilePearson(1.5);            
            IProfileFunction Profile = options.ProfileFunction;
            Profile.FWHM = options.FWHM;

            // calculation of left and right points nead to be calculated
            // Calculate aproximetly 25 points per reflection 
            int calcpoints = (int)(Profile.FW1M / options.LStep);

            // Set X ; correct value for the array
            for (int i = 0; i < x.Length; i++) { x[i] = (options.LStart + i * options.LStep); }

            // Set Y to zerro
            for (int i = 0; i < y.Length; i++) y[i] = 0;


            // loop througth reflection array
            foreach (Reflection refl in Reflections)
            {
                double peakcenter = refl.Theta;
                
                // Closes position in array X of peak center
                int apxpos = (int)Math.Round((peakcenter - options.LStart) / options.LStep);
                
                // Is Theta out of range ?
                if (((apxpos + calcpoints) < 0) | ((apxpos - calcpoints) > (y.Length - 1))) { continue; }


                // Currently calculated Theta
                double start_theta = (apxpos - calcpoints) * options.LStep + options.LStart;

                // Calculation of curve shape
                for (int i = -calcpoints; i < calcpoints; i++)
                {
                    // calculated position x in arrat
                    int calcx = apxpos + i;
                    // Is X out of range -?
                    if ((calcx < 0) | (calcx > (y.Length - 1))) { continue; }


                    // Theta for which calculation of preforming
                    double ctheta = start_theta + ((i + calcpoints) * options.LStep); 
                   
                    y[calcx] = y[calcx] + Profile.Val(ctheta - peakcenter, refl.Irel);
                }

            }


            NormalizeXY();
        }

        private double MyParsed(string s)
        {
            //return Double.Parse(s);
            return Double.Parse(s, CultureInfo.InvariantCulture);// System.Globalization.NumberStyles.AllowDecimalPoint);            
        }
               
        public IPowderGraph RecalculateXY()
        {
            CalculateXY();
            PowderTics pt = new PowderTics(Reflections, AbsentReflections);
            return new PowderGraph(x, y, pt);
        }
       
        public IPowderGraph GetfromHKL(StreamReader fs)
        {
            string input = "";
            Regex r = new Regex(@"\s+");
            Reflections.Clear();
            double WaveLength = options.Source.WavelengthA;

            while (((input = fs.ReadLine()) != null))
            {
                input = input.Trim();
                input = r.Replace(input, " ");
                string[] hkl_I_Sigma = input.Split(' ');
                int h = Convert.ToInt16(hkl_I_Sigma[0]);
                int k = Convert.ToInt16(hkl_I_Sigma[1]);
                int l = Convert.ToInt16(hkl_I_Sigma[2]);
                double I = MyParsed(hkl_I_Sigma[3]);
                double Sigma = MyParsed(hkl_I_Sigma[4]);
                Reflection refl = new Reflection(h, k, l);
                refl.I = I;


                double d = mol.Cell.calculate_d(h, k, l);
                double w = WaveLength / (2.0 * d);
                double Theta = 90;
                if (w < 1) { Theta = Math.Asin(w) * RAD2GRAD2; }

                refl.d = d;
                refl.Theta = Theta;

                Reflections.Add(refl);
            }

            // Mreg reflections and remove systematicaly absent
            MregReflections(true);

            // Applay Lorenz correlation
            ApplayLorentzCorr(false);

            // Calculation of Irel
            CalculateIrel();

            // Calculation of peak shape
            CalculateXY();// Fill with 
            return new PowderGraph(x, y, null);
        }


        private void DoFullCalculation()
        {
            GenerateHKLTable();
            CalculateF();
            CalculateXY();
            full_calc_done = true;
        }
        

        void options_ThetaRecalcNeaded(object sender, EventArgs e)
        {
            DoFullCalculation();
            OnDataChanged();
            /* Nead to be changed*/
        }

        void options_FullRecalcNeaded(object sender, EventArgs e)
        {
            DoFullCalculation();
            OnDataChanged();
        }


        void options_XYRecalcNeaded(object sender, EventArgs e)
        {
            CalculateXY();
            OnDataChanged();
        }

        private bool full_calc_done = false;
        public IPowderGraph GetGraph()
        {
            if (!full_calc_done) DoFullCalculation();            
            return new PowderGraph(x, y, new PowderTics(Reflections, AbsentReflections));
        }                
        
        public event EventHandler DataChanged;
        private void OnDataChanged()
        {
            if (DataChanged != null) DataChanged(this, EventArgs.Empty);
        }                
    
    
    
    
    }
}