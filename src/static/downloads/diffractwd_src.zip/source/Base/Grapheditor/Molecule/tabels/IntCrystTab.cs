﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Xml.Serialization;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Runtime.Serialization.Formatters.Binary;

/*
 Int Tables builed based on WEB interface to CCTBX
 http://cci.lbl.gov/sginfo/hall_symbols.html
 
 ShelX Latt instructions 
 LATT : http://macxray.chem.upenn.edu/LATT.pdf thank you, Patrick Carroll
 
 */
namespace Base
{
    public class Int_cryst_tables
    {
        [XmlArray(ElementName = "space_groups")]
        public SpaceGroup[] _space_groups
        {
            get { return space_groups; }
            set { space_groups = value; }
        }

        public static SpaceGroup[] space_groups = null;

        public static string cFileIn = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "data\\spacegr.dat");

        private static Hashtable hall_index = null;

        private static Hashtable h_m_index = null;

        //~~ static constructor
        static Int_cryst_tables()
        {
            //load_xml_file();
            //save_dat(); // Generation of DAT File
            load_dat();
        }

        public static SpaceGroup get_space_group_by_id(int id)
        {
            // 1400 - space group             
            if (id > 1000)
            {
                int sgid = (int)Math.Floor(id / 1000.0);
                int setings = id - sgid * 1000;
                if (setings == 0) return space_groups[sgid - 1];
                return space_groups[sgid - 1].other_setings[setings - 1];
            }
            return space_groups[id - 1];
        }

        public static int get_space_group_id_by_id(int id)
        {
            if ((id > 0) && (id < space_groups.Length)) return id;
            return 0;
        }

        public static int get_space_group_id_by_hall_name(string name)
        {
            SpaceGroup s = get_space_group_by_hall_name(name);
            if (s == null) return 0;
            return s.id;
        }

        public static SpaceGroup get_space_group_by_hall_name(string name)
        {
            //if (space_groups == null) load_dat(); // moved into static constructor
            if (hall_index == null) create_hall_index();
            if (hall_index.ContainsKey(name)) return (SpaceGroup)hall_index[name];
            if (hall_index.ContainsKey(name + " 1 1")) return (SpaceGroup)hall_index[name + " 1 1"];
            throw new SystemException("Crystal system " + name + " unknown");
        }

        public static int get_space_group_id_by_H_M(string name)
        {
            SpaceGroup s = get_space_group_by_H_M(name);
            if (s == null) return 0;
            return s.id;
        }

        public static SpaceGroup get_space_group_by_H_M(string name)
        {
            //if (space_groups == null) load_dat();  // moved into static constructor           
            if (h_m_index == null) create_h_m_index();
            if (h_m_index.ContainsKey(name)) return (SpaceGroup)h_m_index[name];
            if (h_m_index.ContainsKey(name + " 1 1")) return (SpaceGroup)h_m_index[name + " 1 1"];
            throw new SystemException("Crystal system " + name + " unknown");
        }

        private static bool containe_operation(List<Vec3> trlist, SpaceGroup sg, Symetry sym)
        {
            foreach (Symetry sm in sg.operations)
            {
                // is sm same as sym -?
                if (sm.rootation.Equals(sym.rootation))
                {// rootation part is the same
                    // translation part 
                    Vec3 trans = (sm.translation - sym.translation);
                    foreach (Vec3 v in trlist)
                    {
                        // 1,1,1 is equal to 0,0,0
                        if (Vec3.Equals(v, trans)) return true;
                    }
                }
            }
            return false;
        }

        private static bool containe_operation2(SpaceGroup sg, Symetry sym)
        {
            foreach (Symetry sm in sg.operations)
            {
                // is sm same as sym -?
                if (sm.rootation.Equals(sym.rootation))
                {// rootation part is the same
                    // translation part 
                    Vec3 trans = (sm.translation - sym.translation);
                    if (trans.Equals(Vec3.Zero)) return true;
                }
            }
            return false;
        }


        private static bool corespond_to_sg(List<Symetry> symetrylist, SpaceGroup sg)
        {
            int expected_operations = symetrylist.Count;
            int operation_count = sg.operations.Count;
            if (expected_operations != operation_count) return false;

            bool res = true;


            foreach (Symetry sym in symetrylist)
            {
                if (res == false) continue;
                // compare s and sym
                //if (!containe_operation(trlist, sg, sym)) { res = false; }
                if (!containe_operation2(sg, sym)) { res = false; }
            }

            return res;
        }

        private static bool corespond_to_sg(List<Vec3> trlist, List<Symetry> symetrylist, SpaceGroup sg)
        {
            int expected_operations = trlist.Count * symetrylist.Count;
            int operation_count = sg.operations.Count;
            if (expected_operations != operation_count) return false;

            bool res = true;

            List<Symetry> symetrylist_f = new List<Symetry>();
            foreach (Symetry s in symetrylist)
            {
                foreach (Vec3 t in trlist)
                {
                    symetrylist_f.Add(new Symetry(s.rootation, s.translation + t));
                }
            }

            foreach (Symetry sym in symetrylist_f)
            {
                if (res == false) continue;
                // compare s and sym
                //if (!containe_operation(trlist, sg, sym)) { res = false; }
                if (!containe_operation2(sg, sym)) { res = false; }
            }

            return res;
        }

        // Determination of Space Group
        // Based on Centring and Symetry Operations

        public static int get_space_group_id_by_symlist(List<Vec3> trlist, List<Symetry> symetrylist)
        {
            foreach (SpaceGroup sg in space_groups)
            {
                if (corespond_to_sg(trlist, symetrylist, sg)) return sg.id * 1000;
                // Check also non standart setings
                int i = 1;// setings counter
                foreach (SpaceGroup sg2 in sg.other_setings)
                {
                    if (corespond_to_sg(trlist, symetrylist, sg2))
                    {
                        return sg.id * 1000 + i;
                    }
                    i++;
                }
            }
            return 0;
        }

        public static int get_space_group_id_by_symlist(List<Symetry> symetrylist)
        {
            foreach (SpaceGroup sg in space_groups)
            {
                if (corespond_to_sg(symetrylist, sg)) return sg.id * 1000;
                // Check also non standart setings
                int i = 1;// setings counter
                foreach (SpaceGroup sg2 in sg.other_setings)
                {
                    if (corespond_to_sg(symetrylist, sg2))
                    {
                        return sg.id * 1000 + i;
                    }
                    i++;
                }
            }
            return 0;
        }



        private static void create_hall_index()
        {
            hall_index = new Hashtable();
            foreach (SpaceGroup sg in space_groups)
            {
                hall_index[sg.hall_symbol] = sg;
            }
        }

        private static void create_h_m_index()
        {
            h_m_index = new Hashtable();
            foreach (SpaceGroup sg in space_groups)
            {
                h_m_index[sg.h_m_symbol] = sg;
                if (!h_m_index.Contains(sg.h_m_symbol.Replace(" ", "")))
                {
                    h_m_index[sg.h_m_symbol.Replace(" ", "")] = sg;
                }
            }
        }

        public static void load_dat()
        {
            // load Space group setings                        
            /*
            if (!File.Exists(cFileIn))
            {
                throw new SystemException("Space group dat file not found. Check location : " + Int_cryst_tables.cFileIn + "  ");
            }            
            FileStream fStream = new FileStream(cFileIn, FileMode.Open);
            */
            System.Reflection.Assembly thisExe = System.Reflection.Assembly.GetExecutingAssembly();
            //string[] n = thisExe.GetManifestResourceNames();
            System.IO.Stream fStream = thisExe.GetManifestResourceStream("Base.data.spacegr.dat");
          
            BinaryFormatter binFormat = new BinaryFormatter();
            space_groups = (SpaceGroup[])binFormat.Deserialize(fStream);
            fStream.Close();
        }

        private static void save_dat()
        {
            FileStream fStream = new FileStream(Int_cryst_tables.cFileIn, FileMode.Create);
            BinaryFormatter binFormat = new BinaryFormatter();
            binFormat.Serialize(fStream, space_groups);
            fStream.Close();
        }

        // load Int. Tables from alternative xml file. Parsed from site : 
        private static Int_cryst_tables load_xml_file()
        {
            string filname = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "data\\spgr.xml");
            space_groups = new SpaceGroup[230];
            XmlDocument doc = new XmlDocument();

            doc.Load(filname);
            foreach (XmlNode node in doc.LastChild.ChildNodes)
            {
                int id = 0;
                string schoenflies = "";
                string hermann_mauguin = "";
                string hall_symbol = "";
                string uniq_axis = "";
                int cell_choice = 0;
                string to_standart = "";
                int representative_operations = 0;
                int total_operations = 0;
                string asymmetric_unit = "";
                List<Symetry> sym_list = new List<Symetry>();
                List<Wyckoff> weekof_list = new List<Wyckoff>();

                foreach (XmlNode el in node.ChildNodes)
                {

                    if (el.Name.StartsWith("id"))
                    {
                        id = Convert.ToInt32(el.InnerText);
                    }
                    if (el.Name.StartsWith("schoenflies"))
                    {
                        schoenflies = el.InnerText;
                    }
                    if (el.Name.StartsWith("hermann_mauguin"))
                    {
                        hermann_mauguin = el.InnerText;
                    }
                    if (el.Name.StartsWith("hall_symbol"))
                    {
                        hall_symbol = el.InnerText;
                    }
                    if (el.Name.StartsWith("uniq_axis"))
                    {
                        uniq_axis = el.InnerText;
                    }
                    if (el.Name.StartsWith("cell_choice"))
                    {
                        if (el.InnerText != "") cell_choice = Convert.ToInt32(el.InnerText);
                    }
                    if (el.Name.StartsWith("to_standart"))
                    {
                        to_standart = el.InnerText;
                    }
                    if (el.Name.StartsWith("representative_operations"))
                    {
                        representative_operations = Convert.ToInt32(el.InnerText);
                    }
                    if (el.Name.StartsWith("total_operations"))
                    {
                        total_operations = Convert.ToInt32(el.InnerText);
                    }
                    if (el.Name.StartsWith("asymmetric_unit"))
                    {
                        asymmetric_unit = el.InnerText;
                    }
                    if (el.Name.StartsWith("symety_list"))
                    { // symetry list
                        foreach (XmlNode sl in el.ChildNodes)
                        {
                            Symetry sym = new Symetry(sl.InnerText);
                            sym_list.Add(sym);
                        }
                    }
                    if (el.Name.StartsWith("weekof_list"))
                    { //~~ weekof list

                        foreach (XmlNode wlx in el.ChildNodes)
                        {
                            string leter = "";
                            int multiplicity = 0;
                            string site_symmetry = "";
                            string position_operator = "";

                            foreach (XmlNode wl in wlx.ChildNodes)
                            {

                                if (wl.Name.StartsWith("leter"))
                                {
                                    leter = wl.InnerText;
                                }
                                if (wl.Name.StartsWith("multiplicity"))
                                {
                                    multiplicity = Convert.ToInt32(wl.InnerText);
                                }
                                if (wl.Name.StartsWith("site_symmetry"))
                                {
                                    site_symmetry = wl.InnerText;
                                }
                                if (wl.Name.StartsWith("position_operator"))
                                {
                                    position_operator = wl.InnerText;
                                }
                            }
                            Wyckoff wf = new Wyckoff(leter, multiplicity, site_symmetry, position_operator);
                            weekof_list.Add(wf);
                        }
                    }
                }

                SpaceGroup sg = new SpaceGroup();
                sg.id = id;
                sg.cell_choice = cell_choice;
                sg.schoenflies_symbol = schoenflies;
                sg.h_m_symbol = hermann_mauguin;
                sg.hall_symbol = hall_symbol;
                sg.uniq_axis = uniq_axis;
                sg.cell_choice = cell_choice;
                sg.to_standart = to_standart;
                sg.representative_operations = representative_operations;
                sg.wyckoff_positions = weekof_list;
                sg.operations = sym_list;
                sg.asymmetric_unit = asymmetric_unit;


                if (total_operations != sym_list.Count)
                {
                    throw new SystemException();
                }
                if (space_groups[(id - 1)] == null)
                {  // Standart cell Setins
                    space_groups[(id - 1)] = sg;
                }
                else
                {  //Non Standart cell Setins
                    space_groups[(id - 1)].other_setings.Add(sg);
                }
            }

            return null;
        }

    }
}
