﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Base
{

    [Serializable]
    public class Symetry : ICloneable, IEquatable<Symetry>
    {
        private const float translation_tolerance = 0.00001f;
        // Cash
        [XmlIgnore, NonSerialized]
        private string _code = null;

        // Do not save in Bin formater, oly in Xml formater
        [XmlElement(ElementName = "code")] //NonSerialized
        public string code
        {
            get
            {
                if (_code == null) _code = Matrix3x3.symetry_name(rootation, translation);
                return _code;
            }
            set
            {
                Matrix3x3.construct(value, out rootation, out translation);
                _code = Matrix3x3.symetry_name(rootation, translation);
            }
        }

        [XmlIgnore] // Save in bin formater
        public Matrix3x3 rootation = null;

        [XmlIgnore] // Save in bin formater
        public Vec3 translation = null;

        public bool IsE
        {
            get
            {
                return ((rootation.Equals(Matrix3x3.Equiv)) && (translation.Equals(Vec3.Zero, translation_tolerance)));
            }
        }

        public bool IsTranslation
        {
            get
            {
                return (rootation.Equals(Matrix3x3.Equiv));
            }
        }

        #region Constructors
        public Symetry()
        {
            this.code = "x,y,z";
        }

        public Symetry(string name)
        {
            this.code = name;
        }

        public override string ToString()
        {
            return code;
        }

        public Symetry(Matrix3x3 root, Vec3 trans)
        {
            this.rootation = root;
            this.translation = trans;
        }
        #endregion

        #region Common Operation

        // symetry + translation
        public static Symetry operator +(Symetry p1, Vec3 translation)
        {
            return new Symetry(p1.rootation, (p1.translation + translation));
        }

        public static Symetry operator -(Symetry p1, Vec3 translation)
        {
            return new Symetry(p1.rootation, (p1.translation - translation));
        }
        #endregion

        #region ICloneable Members

        public object Clone()
        {
            return this;
        }

        #endregion

        public static Vec3 operator *(Symetry sym, Vec3 coord)
        {
            return ((sym.rootation * coord) + sym.translation);
        }

        public static readonly Symetry IE = new Symetry("x, y, z");


        #region IEquatable<Symetry> Members

        public bool Equals(Symetry other)
        {
            if (!this.translation.Equals(other.translation)) return false;
            if (!this.rootation.Equals(other.rootation)) return false;
            return true;
        }

        #endregion
    }

}
