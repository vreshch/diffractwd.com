﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;

namespace Base
{

    static class PeriodicTable
    {
        private static ElementSetings[] _elem_setings = new ElementSetings[]
        {           
            new ElementSetings(0,	"Q",	0.77,	0.0,	0,	   0,	        "Dummy",	    It1992.data["C"],   F1F2.data["C"],  1,  	7),	
            new ElementSetings(1,	"D",	0.37,	1.2,	1,	   2,	        "Diyterium",	It1992.data["H"],   F1F2.data["H"],  1,	    8),	
            new ElementSetings(1,	"H",	0.37,	1.2,	1,	   1.00794,	    "Hydrogen", 	It1992.data["H"],   F1F2.data["H"],  1,	    1),	
            new ElementSetings(2,	"He",	0.32,	1.4,	0,	   4.002602,	"Helium",	    It1992.data["He"],  F1F2.data["He"], 1,	    18),	
            new ElementSetings(3,	"Li",	1.34,	2.2,	1,	   6.941,	    "Lithium",	    It1992.data["Li"],  F1F2.data["Li"], 2,	    1),	
            new ElementSetings(4,	"Be",	0.9,	1.9,	2,	   9.012182,	"Beryllium",	It1992.data["Be"],  F1F2.data["Be"], 2,	    2),	
            new ElementSetings(5,	"B",	0.82,	1.8,	3,	   10.811,	    "Boron",	    It1992.data["B"],   F1F2.data["B"],  2,	    13),	
            new ElementSetings(6,	"C",	0.77,	1.7,	4,	   12.0107,	    "Carbon",	    It1992.data["C"],   F1F2.data["C"],  2,	    14),
            new ElementSetings(7,	"N",	0.75,	1.6,	4,     14.0067,	    "Nitrogen", 	It1992.data["N"],   F1F2.data["N"],  2,	    15),	
            new ElementSetings(8,	"O",	0.73,	1.55,	2,     15.9994,	    "Oxygen",	    It1992.data["O"],   F1F2.data["O"],  2,	    16),	
            new ElementSetings(9,	"F",	0.71,	1.5,	1,     18.9984032,	"Fluorine",	    It1992.data["F"],   F1F2.data["F"],  2,	    17),	
            new ElementSetings(10,	"Ne",	0.69,	1.54,	0,     20.1797,	    "Neon",         It1992.data["Ne"],  F1F2.data["Ne"], 2,	    18),	
            new ElementSetings(11,	"Na",	1.54,	2.4,	1,     22.98977,	"Sodium",	    It1992.data["Na"],  F1F2.data["Na"], 3,	    1),	
            new ElementSetings(12,	"Mg",	1.3,	2.2,	2,     24.305,	    "Magnesium",	It1992.data["Mg"],  F1F2.data["Mg"], 3,	    2),	
            new ElementSetings(13,	"Al",	1.18,	2.1,	6,     26.981538,	"Aluminium",	It1992.data["Al"],  F1F2.data["Al"], 3,	    13),	
            new ElementSetings(14,	"Si",	1.11,	2.1,	6,     28.0855,	    "Silicon",	    It1992.data["Si"],  F1F2.data["Si"], 3,	    14),	
            new ElementSetings(15,	"P",	1.06,	1.95,	5,	   30.973761,	"Phosphorus",	It1992.data["P"],   F1F2.data["P"],  3,	    15),	
            new ElementSetings(16,	"S",	1.02,	1.8,	6,	   32.065,	    "Sulfur",	    It1992.data["S"],   F1F2.data["S"],  3,  	16),	
            new ElementSetings(17,	"Cl",	0.99,	1.8,	1,	   35.453, 	    "Chlorine",	    It1992.data["Cl"],  F1F2.data["Cl"], 3,  	17),	
            new ElementSetings(18,	"Ar",	0.97,	1.88,	0,	   39.948,	    "Argon",	    It1992.data["Ar"],  F1F2.data["Ar"], 3,	    18),	
            new ElementSetings(19,	"K",	1.96,	2.8,	1,	   39.0983,	    "Potassium",	It1992.data["K"],   F1F2.data["K"],  4,	    1),	
            new ElementSetings(20,	"Ca",	1.74,	2.4,	2,	   40.078,	    "Calcium",	    It1992.data["Ca"],  F1F2.data["Ca"], 4,  	2),	
            new ElementSetings(21,	"Sc",	1.44,	2.3,	6,	   44.95591,	"Scandium", 	It1992.data["Sc"],  F1F2.data["Sc"], 4,  	3),	
            new ElementSetings(22,	"Ti",	1.36,	2.15,	6,	   47.867,	    "Titanium", 	It1992.data["Ti"],  F1F2.data["Ti"], 4,  	4),	
            new ElementSetings(23,	"V",	1.25,	2.05,	6,	   50.9415,	    "Vanadium",	    It1992.data["V"],   F1F2.data["V"],  4,	    5),	
            new ElementSetings(24,	"Cr",	1.27,	2.05,	6,	   51.9961, 	"Chromium",	    It1992.data["Cr"],  F1F2.data["Cr"], 4,  	6),	
            new ElementSetings(25,	"Mn",	1.39,	2.05,	8,	   54.938049,	"Manganese",	It1992.data["Mn"],  F1F2.data["Mn"], 4,	    7),	
            new ElementSetings(26,	"Fe",	1.25,	2.05,	6,	   55.845,	    "Iron",	        It1992.data["Fe"],  F1F2.data["Fe"], 4,  	8),	
            new ElementSetings(27,	"Co",	1.26,	2.0,	6,	   58.9332,	    "Cobalt",   	It1992.data["Co"],  F1F2.data["Co"], 4,	    9),	
            new ElementSetings(28,	"Ni",	1.21,	2.0,	6,	   58.6934,	    "Nickel",   	It1992.data["Ni"],  F1F2.data["Ni"], 4,	    10),	
            new ElementSetings(29,	"Cu",	1.38,	2.0,	6,	   63.546,	    "Copper",	    It1992.data["Cu"],  F1F2.data["Cu"], 4,	    11),	
            new ElementSetings(30,	"Zn",	1.31,	2.1,	6,	   65.409,	    "Zinc",	        It1992.data["Zn"],  F1F2.data["Zn"], 4,	    12),	
            new ElementSetings(31,	"Ga",	1.26,	2.1,	3,	   69.723,	    "Gallium",  	It1992.data["Ga"],  F1F2.data["Ga"], 4,	    13),	
            new ElementSetings(32,	"Ge",	1.22,	2.1,	4,	   72.64,	    "Germanium",	It1992.data["Ge"],  F1F2.data["Ge"], 4,	    14),	
            new ElementSetings(33,	"As",	1.19,	2.05,	3,	   74.9216, 	"Arsenic",	    It1992.data["As"],  F1F2.data["As"], 4,	    15),	
            new ElementSetings(34,	"Se",	1.16,	1.9,	2,	   78.96,	    "Selenium", 	It1992.data["Se"],  F1F2.data["Se"], 4,	    16),	
            new ElementSetings(35,	"Br",	1.14,	1.9,	1,	   79.904,	    "Bromine",	    It1992.data["Br"],  F1F2.data["Br"], 4,	    17),	
            new ElementSetings(36,	"Kr",	1.1,	2.02,	0,	   83.798,	    "Krypton",	    It1992.data["Kr"],  F1F2.data["Kr"], 4,	    18),	
            new ElementSetings(37,	"Rb",	2.11,	2.9,	1,	   85.4678,	    "Rubidium",	    It1992.data["Rb"],  F1F2.data["Rb"], 5,	    1),	
            new ElementSetings(38,	"Sr",	1.92,	2.55,	2,	   87.62,	    "Strontium",	It1992.data["Sr"],  F1F2.data["Sr"], 5,	    2),	
            new ElementSetings(39,	"Y",	1.62,	2.4,	6,	   88.90585,	"Yttrium",	    It1992.data["Y"],   F1F2.data["Y"],  5,	    3),	
            new ElementSetings(40,	"Zr",	1.48,	2.3,	6,	   91.224,	    "Zirconium",	It1992.data["Zr"],  F1F2.data["Zr"], 5,	    4),	
            new ElementSetings(41,	"Nb",	1.37,	2.15,	6,	   92.90638,	"Niobium",	    It1992.data["Nb"],  F1F2.data["Nb"], 5,	    5),	
            new ElementSetings(42,	"Mo",	1.45,	2.1,	6,	   95.94,  	    "Molybdenum",	It1992.data["Mo"],  F1F2.data["Mo"], 5,	    6),	
            new ElementSetings(43,	"Tc",	1.56,	2.05,	6,	   98,	        "Technetium",	It1992.data["Tc"],  F1F2.data["Tc"], 5,	    7),	
            new ElementSetings(44,	"Ru",	1.26,	2.05,	6,	   101.07,	    "Ruthenium",	It1992.data["Ru"],  F1F2.data["Ru"], 5,     8),	
            new ElementSetings(45,	"Rh",	1.35,	2.0,	6,	   102.9055,	"Rhodium",	    It1992.data["Rh"],  F1F2.data["Rh"], 5,	    9),	
            new ElementSetings(46,	"Pd",	1.31,	2.05,	6,	   106.42,	    "Palladium",	It1992.data["Pd"],  F1F2.data["Pd"], 5,	    10),	
            new ElementSetings(47,	"Ag",	1.53,	2.1,	6,	   107.8682,	"Silver",	    It1992.data["Ag"],  F1F2.data["Ag"], 5,	    11),	
            new ElementSetings(48,	"Cd",	1.48,	2.2,	6,	   112.411,	    "Cadmium",  	It1992.data["Cd"],  F1F2.data["Cd"], 5,	    12),	
            new ElementSetings(49,	"In",	1.44,	2.2,	3,	   114.818,	    "Indium",	    It1992.data["In"],  F1F2.data["In"], 5,	    13),	
            new ElementSetings(50,	"Sn",	1.41,	2.25,	4,	   118.71,	    "Tin",	        It1992.data["Sn"],  F1F2.data["Sn"], 5,	    14),	
            new ElementSetings(51,	"Sb",	1.38,	2.2,	3,	   121.76,  	"Antimony",	    It1992.data["Sb"],  F1F2.data["Sb"], 5,	    15),	
            new ElementSetings(52,	"Te",	1.35,	2.1,	2,	   127.6,	    "Tellurium",	It1992.data["Te"],  F1F2.data["Te"], 5,	    16),	
            new ElementSetings(53,	"I",	1.33,	2.1,	1,	   126.90447,	"Iodine",	    It1992.data["I"],   F1F2.data["I"],  5,	    17),	
            new ElementSetings(54,	"Xe",	1.3,	2.16,	0,	   131.293,	    "Xenon",	    It1992.data["Xe"],  F1F2.data["Xe"], 5,	    18),	
            new ElementSetings(55,	"Cs",	2.25,	3.0,	1,	   132.90545,	"Cesium",	    It1992.data["Cs"],  F1F2.data["Cs"], 6,	    1),	
            new ElementSetings(56,	"Ba",	1.98,	2.7,	2,	   137.327,	    "Barium",	    It1992.data["Ba"],  F1F2.data["Ba"], 6,	    2),	
            new ElementSetings(57,	"La",	1.69,	2.5,	12,	   138.9055,	"Lanthanum",	It1992.data["La"],  F1F2.data["La"], 9,	    1),	
            new ElementSetings(58,	"Ce",	1.6,	2.48,	6,	   140.116,	    "Cerium",	    It1992.data["Ce"],  F1F2.data["Ce"], 9,	    2),	
            new ElementSetings(59,	"Pr",	1.6,	2.47,	6,	   140.90765,	"Praseodymium",	It1992.data["Pr"],  F1F2.data["Pr"], 9,	    3),	
            new ElementSetings(60,	"Nd",	1.6,	2.45,	6,	   144.24, 	    "Neodymium",	It1992.data["Nd"],  F1F2.data["Nd"], 9,	    4),	
            new ElementSetings(61,	"Pm",	1.6,	2.43,	6,	   145,	        "Promethium",	It1992.data["Pm"],  F1F2.data["Pm"], 9,	    5),	
            new ElementSetings(62,	"Sm",	1.6,	2.42,	6,	   150.36,	    "Samarium",	    It1992.data["Sm"],  F1F2.data["Sm"], 9,	    6),	
            new ElementSetings(63,	"Eu",	1.6,	2.4,	6,	   151.964,	    "Europium",	    It1992.data["Eu"],  F1F2.data["Eu"], 9,  	7),	
            new ElementSetings(64,	"Gd",	1.6,	2.38,	6,	   157.25,	    "Gadolinium",	It1992.data["Gd"],  F1F2.data["Gd"], 9,	    8),	
            new ElementSetings(65,	"Tb",	1.6,	2.37,	6,	   158.92534,	"Terbium",	    It1992.data["Tb"],  F1F2.data["Tb"], 9,	    9),	
            new ElementSetings(66,	"Dy",	1.6,	2.35,	6,	   162.5,	    "Dysprosium",	It1992.data["Dy"],  F1F2.data["Dy"], 9,	    10),	
            new ElementSetings(67,	"Ho",	1.6,	2.33,	6,	   164.93032,	"Holmium",	    It1992.data["Ho"],  F1F2.data["Ho"], 9,	    11),	
            new ElementSetings(68,	"Er",	1.6,	2.32,	6,	   167.259,	    "Erbium",	    It1992.data["Er"],  F1F2.data["Er"], 9,	    12),	
            new ElementSetings(69,	"Tm",	1.6,	2.3,	6,	   168.93421,	"Thulium",	    It1992.data["Tm"],  F1F2.data["Tm"], 9,	    13),	
            new ElementSetings(70,	"Yb",	1.6,	2.28,	6,	   173.04, 	    "Ytterbium",	It1992.data["Yb"],  F1F2.data["Yb"], 9,	    14),	
            new ElementSetings(71,	"Lu",	1.6,	2.27,	6,	   174.967,	    "Lutetium", 	It1992.data["Lu"],  F1F2.data["Lu"], 9,	    15),	
            new ElementSetings(72,	"Hf",	1.5,	2.25,	6,	   178.49,	    "Hafnium",	    It1992.data["Hf"],  F1F2.data["Hf"], 6,	    4),	
            new ElementSetings(73,	"Ta",	1.38,	2.2,	6,	   180.9479,	"Tantalum",	    It1992.data["Ta"],  F1F2.data["Ta"], 6,	    5),	
            new ElementSetings(74,	"W",	1.46,	2.1,	6,	   183.84,	    "Tungsten",	    It1992.data["W"],   F1F2.data["W"],  6,	    6),	
            new ElementSetings(75,	"Re",	1.59,	2.05,	6,	   186.207,	    "Rhenium",	    It1992.data["Re"],  F1F2.data["Re"], 6,  	7),	
            new ElementSetings(76,	"Os",	1.28,	2.0,	6,	   190.23,	    "Osmium",	    It1992.data["Os"],  F1F2.data["Os"], 6,	    8),	
            new ElementSetings(77,	"Ir",	1.37,	2.0,	6,	   192.217,	    "Iridium",	    It1992.data["Ir"],  F1F2.data["Ir"], 6,	    9),	
            new ElementSetings(78,	"Pt",	1.28,	2.05,	6,	   195.078,	    "Platinum",	    It1992.data["Pt"],  F1F2.data["Pt"], 6,	    10),	
            new ElementSetings(79,	"Au",	1.44,	2.1,	6,	   196.96655,	"Gold",	        It1992.data["Au"],  F1F2.data["Au"], 6,	    11),	
            new ElementSetings(80,	"Hg",	1.49,	2.05,	6,	   200.59,	    "Mercury",	    It1992.data["Hg"],  F1F2.data["Hg"], 6,	    12),	
            new ElementSetings(81,	"Tl",	1.48,	2.2,	3,	   204.3833,	"Thallium",	    It1992.data["Tl"],  F1F2.data["Tl"], 6,	    13),	
            new ElementSetings(82,	"Pb",	1.47,	2.3,	4,	   207.2,	    "Lead",	        It1992.data["Pb"],  F1F2.data["Pb"], 6,	    14),	
            new ElementSetings(83,	"Bi",	1.46,	2.3,	3,	   208.98038,	"Bismuth",  	It1992.data["Bi"],  F1F2.data["Bi"], 6,	    15),	
            new ElementSetings(84,	"Po",	1.6,	2.0,	2,	   209,	        "Polonium",	    It1992.data["Po"],  F1F2.data["Po"], 6,	    16),	
            new ElementSetings(85,	"At",	1.6,	2.0,	1,	   210,	        "Astatine",	    It1992.data["At"],  F1F2.data["At"], 6,	    17),	
            new ElementSetings(86,	"Rn",	1.45,	2.0,	0,	   222,	        "Radon",	    It1992.data["Rn"],  F1F2.data["Rn"], 6,	    18),	
            new ElementSetings(87,	"Fr",	1.6,	2.0,	1,	   223,	        "Francium",	    It1992.data["Fr"],  F1F2.data["Fr"], 7,	    1),	
            new ElementSetings(88,	"Ra",	1.6,	2.0,	2,	   226,	        "Radium",	    It1992.data["Ra"],  F1F2.data["Ra"], 7,	    2),	
            new ElementSetings(89,	"Ac",	1.6,	2.0,	6,	   227,	        "Actinium",	    It1992.data["Ac"],  F1F2.data["Ac"], 10,	1),	
            new ElementSetings(90,	"Th",	1.6,	2.4,	6,	   232.0381,	"Thorium",	    It1992.data["Th"],  F1F2.data["Th"], 10,	2),	
            new ElementSetings(91,	"Pa",	1.6,	2.0,	6,	   231.03588,	"Protactinium",	It1992.data["Pa"],  F1F2.data["Pa"], 10, 	3),	
            new ElementSetings(92,	"U",	1.6,	2.3,	6,	   238.02891,	"Uranium",	    It1992.data["U"],   F1F2.data["U"],  10,	4),	
            new ElementSetings(93,	"Np",	1.6,	2.0,	6,	   237,	        "Neptunium",	It1992.data["Np"],  F1F2.data["Np"], 10,	5),	
            new ElementSetings(94,	"Pu",	1.6,	2.0,	6,	   244,	        "Plutonium",	It1992.data["Pu"],  F1F2.data["Pu"], 10,	6),	
            new ElementSetings(95,	"Am",	1.6,	2.0,	6,	   243,	        "Americium",	It1992.data["Am"],  F1F2.data["Am"], 10,	7),	
            new ElementSetings(96,	"Cm",	1.6,	2.0,	6,	   247,	        "Curium",	    It1992.data["Cm"],  F1F2.data["Cm"], 10, 	8),	
            new ElementSetings(97,	"Bk",	1.6,	2.0,	6,	   247,	        "Berkelium",	It1992.data["Bk"],  F1F2.data["Bk"], 10,	9),	
            new ElementSetings(98,	"Cf",	1.6,	2.0,	6,	   251,	        "Californium",	It1992.data["Cf"],  F1F2.data["Cf"], 10, 	10)
            /*                                                                                                      
            new ElementSetings(99,	"Es",	1.6,	2.0,	6,	   252,	        "Einsteinium",	It1992.data["Es"],  F1F2.data["Es"], 10,	    11),	
            new ElementSetings(100,	"Fm",	1.6,	2.0,	6,	   257,	        "Fermium",	    It1992.data["Fm"],  F1F2.data["Fm"], 10,	    12),	
            new ElementSetings(101,	"Md",	1.6,	2.0,	6,	   258,	        "Mendelevium",	It1992.data["Md"],  F1F2.data["Md"], 10,	    13),	
            new ElementSetings(102,	"No",	1.6,	2.0,	6,	   259,	        "Nobelium",	    It1992.data["No"],  F1F2.data["No"], 10,	    14),	
            new ElementSetings(103,	"Lr",	1.6,	2.0,	6,	   262,	        "Lawrencium",	It1992.data["Lr"],  F1F2.data["Lr"], 10,	    15),	
            new ElementSetings(104,	"Rf",	1.6,	2.0,	6,	   261,	        "Rutherfordium",It1992.data["Rf"],  F1F2.data["Rf"], 11, 	4),	
            new ElementSetings(105,	"Db",	1.6,	2.0,	6,	   262,	        "Dubnium",	    It1992.data["Db"],  F1F2.data["Db"], 11,	    5),	
            new ElementSetings(106,	"Sg",	1.6,	2.0,	6,	   266,	        "Seaborgium",	It1992.data["Sg"],  F1F2.data["Sg"], 11, 	6),	
            new ElementSetings(107,	"Bh",	1.6,	2.0,	6,	   264,	        "Bohrium",	    It1992.data["Bh"],  F1F2.data["Bh"], 11, 	7),	
            new ElementSetings(108,	"Hs",	1.6,	2.0,	6,	   277,	        "Hassium",	    It1992.data["Hs"],  F1F2.data["Hs"], 11,	    8),	
            new ElementSetings(109,	"Mt",	1.6,	2.0,	6,	   268,	        "Meitnerium",	It1992.data["Mt"],  F1F2.data["Mt"], 11, 	9),	
            new ElementSetings(110,	"Ds",	1.6,	2.0,	6,	   281,	        "Darmstadtium",	It1992.data["Ds"],  F1F2.data["Ds"], 11,	    10),	
            new ElementSetings(111,	"Rg",	1.6,	2.0,	6,	   272,	        "Roentgenium",	It1992.data["Rg"],  F1F2.data["Rg"], 11,	    11),	
            new ElementSetings(112,	"Uub",	1.6,	2.0,	6,	   285,	        "Ununbium",	    It1992.data["Uub"], F1F2.data["Uub"],11,	    12),	
            new ElementSetings(113,	"Uut",	1.6,	2.0,	6,	   284,	        "Ununtrium",	It1992.data["Uut"], F1F2.data["Uut"],11,	    13),	
            new ElementSetings(114,	"Uuq",	1.6,	2.0,	6,	   289,         "Ununquadium",	It1992.data["Uuq"], F1F2.data["Uuq"],11,	    14),	
            new ElementSetings(115,	"Uup",	1.6,	2.0,	6,	   288,	        "Ununpentium",	It1992.data["Uup"], F1F2.data["Uup"],11,	    15),	
            new ElementSetings(116,	"Uuh",	1.6,	2.0,	6,	   292,	        "Ununhexium",	It1992.data["Uuh"], F1F2.data["Uuh"],11,	    16)    
                                           
            */
        };

        static PeriodicTable()
        {

        }

        private static SortedList<string, ElementSetings> element_list;

        private static void Init_list()
        {
            if (element_list != null) return;
            element_list = new SortedList<string, ElementSetings>();
            foreach (ElementSetings e in _elem_setings) element_list.Add(e.Symb.ToUpper(), e);
        }

        public static ElementSetings GetElement(int index)
        {
            return _elem_setings[index + 1];
        }

        public static bool IsCorrectElementName(string name)
        {
            Init_list();
            return (element_list.ContainsKey(name.ToUpper()));
        }

        public static ElementSetings GetElement(string name)
        {
            Init_list();
            if (element_list.ContainsKey(name.ToUpper())) return element_list[name.ToUpper()];
            throw new TableFormatExeption("Unknown element Name: " + name);
        }

        public static int element_count
        {
            get
            {
                return _elem_setings.Length;
            }
        }

    }



}