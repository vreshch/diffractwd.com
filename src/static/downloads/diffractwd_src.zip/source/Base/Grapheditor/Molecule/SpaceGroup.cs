﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Base
{
    public enum Crystal_system : byte
    {
        Triclinic,
        Monoclinic,
        Orthorhombic,
        Tetragonal,
        Trigonal,
        Hexagonal,
        Cubic
    }

    [Serializable]
    public class SpaceGroup
    {
        [XmlAttribute]
        public int id;

        [XmlElement(ElementName = "hall_symbol")]
        public string hall_symbol;

        [XmlElement(ElementName = "group_name_H-M")]
        public string h_m_symbol;

        [XmlElement(ElementName = "schoenflies_symbol")]
        public string schoenflies_symbol;

        [XmlElement(ElementName = "uniq_axis")]
        public string uniq_axis;

        [XmlElement(ElementName = "cell_choice")]
        public int cell_choice;

        [XmlElement(ElementName = "to_standart")]
        public string to_standart;

        [XmlElement(ElementName = "asymmetric_unit")]
        public string asymmetric_unit;

        [XmlElement(ElementName = "representative_operations")]
        public int representative_operations;

        [XmlArray(ElementName = "symetry_code")]
        public List<Symetry> operations;

        [XmlArray(ElementName = "weekof_list")]
        public List<Wyckoff> wyckoff_positions = new List<Wyckoff>();

        [XmlArray(ElementName = "other_setings")]
        public List<SpaceGroup> other_setings = new List<SpaceGroup>();

        public int total_operations
        {
            get { return operations.Count; }
        }

        [XmlIgnore]
        private int _IsCentric = 0;
        public bool IsCentric
        {
            get
            {
                if (_IsCentric == 0)
                {
                    bool ret = SpaceGroup.IsCentricSet(operations);
                    if (ret) { _IsCentric = 1; } else { _IsCentric = -1; };
                }
                if (_IsCentric == -1) return false;
                if (_IsCentric == 1) return true;
                throw new SystemException(" Incorect Run");
            }
        }

        public Wyckoff get_wyckoff(Vec3 vec)
        {
            Wyckoff iewf = null;
            foreach (Wyckoff wf in wyckoff_positions)
            {
                if (!wf.IsE)
                {
                    foreach (Symetry sm in operations)
                    {
                        if (wf.is_correspond(sm * vec)) return wf;
                    }
                }
                else iewf = wf;
            }
            if (iewf == null) throw new SystemException("General position is missed ");
            return iewf;
        }

        public Crystal_system crystal_system
        {
            get
            {
                if ((id >= 1) && (id <= 2)) return Crystal_system.Triclinic;
                if ((id >= 3) && (id <= 15)) return Crystal_system.Monoclinic;
                if ((id >= 16) && (id <= 74)) return Crystal_system.Orthorhombic;
                if ((id >= 75) && (id <= 142)) return Crystal_system.Tetragonal;
                if ((id >= 143) && (id <= 167)) return Crystal_system.Trigonal;
                if ((id >= 168) && (id <= 194)) return Crystal_system.Hexagonal;
                if ((id >= 195) && (id <= 230)) return Crystal_system.Cubic;
                throw new SystemException("Error in Space Group id");
            }
        }

        public SpaceGroup()
        {
        }

        public static bool IsCentricSet(List<Symetry> operations)
        {
            foreach (Symetry s in operations)
            {
                if (!s.translation.Equals(Vec3.Zero)) continue;
                if (s.rootation.Equals(-1 * Matrix3x3.Once)) return true;
            }
            return false;
        }

        #region a, b, c, alpha, beta, gamma, restriction
        // if true correspondind edit must be set to enable=true;
        public bool a_fixed
        {
            get
            {
                return false;
            }
        }

        public bool b_fixed
        {
            get
            {
                Crystal_system cs = crystal_system;
                return ((cs == Crystal_system.Cubic) | (cs == Crystal_system.Hexagonal) | (cs == Crystal_system.Trigonal) | (cs == Crystal_system.Tetragonal));
            }
        }

        public bool c_fixed
        {
            get
            {
                Crystal_system cs = crystal_system;
                return ((cs == Crystal_system.Cubic));
            }
        }

        public bool alpha_fixed
        {
            get
            {
                Crystal_system cs = crystal_system;
                return ((cs != Crystal_system.Triclinic) && (cs != Crystal_system.Trigonal));
            }
        }

        public bool beta_fixed
        {
            get
            {
                Crystal_system cs = crystal_system;
                return (!((cs == Crystal_system.Monoclinic) | (cs == Crystal_system.Triclinic)));
            }
        }

        public bool gamma_fixed
        {
            get
            {
                Crystal_system cs = crystal_system;
                return (cs != Crystal_system.Triclinic);
            }
        }

        // -1: equal to a; 0: any val;
        public int b_val
        {
            get
            {
                if (b_fixed) return -1;
                return 0;
            }
        }
        public int c_val
        {
            get
            {
                if (c_fixed) return -1;
                return 0;
            }
        }

        public int alpha_val
        {
            get
            {
                if (alpha_fixed) return 90;
                return 0;
            }
        }
        public int beta_val
        {
            get
            {
                if (beta_fixed) return -1;
                return 0;
            }
        }
        public int gamma_val
        {
            get
            {
                Crystal_system cs = crystal_system;
                if (cs == Crystal_system.Hexagonal) return 120; // == 120
                if (cs != Crystal_system.Triclinic) return -1;  // == alpha
                return 0;                                       // == any value
            }
        }

        #endregion

        #region HKL manipulation
        // Return true if reflection is systematicly Absent
        // Details on reflection calculation can be found
        // http://iucrcomputing.ccp14.ac.uk/iucr-top/comm/ccom/siena2005/notes/tutorials/gms_siena_tutorial.pdf
        public bool IsReflSystematicAbsent(int h, int k, int l)
        {
            const double eps = 0.1;
            Vec3 hkl = new Vec3(h, k, l);
            // loop throught all symetries
            foreach (Symetry s in operations)
            {
                //generated symetry vector
                Vec3 newhkl = s.rootation * hkl;

                // phase shift 
                double ph = Math.Abs(s.translation.DotProduct(hkl));

                //if HR == H and HT != 0 mod 1
                if (Vec3.Zero.Equals((newhkl - hkl), eps))
                {
                    ph = ph - Math.Floor(ph);
                    if (ph > eps) return true;
                }
                // Symmetry-restricted phases
                // HR == -H: phi(H) = pi*HT + n*pi

            }
            return false;
        }


        public bool AreReflEquiv(Reflection cr, Reflection rl)
        {
            const double eps = 0.1;
            Vec3 hkl1 = new Vec3(cr.h, cr.k, cr.l);
            Vec3 hkl2 = new Vec3(rl.h, rl.k, rl.l);
            foreach (Symetry s in operations)
            {
                Vec3 newhkl = s.rootation * hkl1;
                if (Vec3.Zero.Equals((newhkl - hkl2), eps))
                {
                    return true;
                }
                if (Vec3.Zero.Equals((newhkl + hkl2), eps))
                {
                    //if (this.IsCentric) return true;
                    return true;
                }
            }
            return false;
        }

        #endregion
    }

}
