﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Base
{
    /* 
     * Class for unit cell representation
     * Hold symetry information
     * Can calculate coordinate transform
     * 
     */

    public class Unit_cell : IUnitCell
    {
        #region Space Group, Defalut P1
        private SpaceGroup _space_group = null;


        [XmlIgnore]
        public SpaceGroup space_group
        {
            get
            {
                if (_space_group == null) _space_group = Int_cryst_tables.get_space_group_by_H_M("P 1");
                return _space_group;
            }
            set
            {
                _space_group = value;
            }
        }

        public int space_group_id
        {
            get { return space_group.id; }
            set { _space_group = Int_cryst_tables.get_space_group_by_id(value); }
        }

        public string space_group_name
        {
            get { return space_group.h_m_symbol; }
        }

        [XmlIgnore]
        public List<Symetry> symetry_list
        {
            get { return space_group.operations; }
        }
        #endregion

        #region Cell parameters a, b, c, alpha, beta, gamma, volume;

        private double _a, _b, _c, _alpha, _beta, _gamma, _volume;

        public double a
        {
            get { return _a; }
            set { _a = value; init_matrix(); }
        }
        public double b
        {
            get { return _b; }
            set { _b = value; init_matrix(); }
        }
        public double c
        {
            get { return _c; }
            set { _c = value; init_matrix(); }
        }
        public double alpha
        {
            get { return _alpha; }
            set { _alpha = value; init_matrix(); }
        }
        public double beta
        {
            get { return _beta; }
            set { _beta = value; init_matrix(); }
        }
        public double gamma
        {
            get { return _gamma; }
            set { _gamma = value; init_matrix(); }
        }

        public double volume
        {
            get { if (_volume == 0) init_matrix(); return _volume; }
        }
        #endregion

        #region reciprocal space parameters
        double aa, bb, cc, alphaa, betaa, gammaa;//reciprocal space parameters

        #endregion

        #region init_matrix region + transformation

        private Matrix3x3 mOrthMatrix = new Matrix3x3();
        private Matrix3x3 mBMatrix = new Matrix3x3();
        private Matrix3x3 mOrthMatrixInvert = new Matrix3x3();

        public void init_matrix()
        {// calculate matrix
            double p_alpha, p_beta, p_gamma;
            p_alpha = alpha * 0.017453292519943295;// pi/180 ;
            p_beta = beta * 0.017453292519943295;
            p_gamma = gamma * 0.017453292519943295;

            double v;//volume of the unit cell
            v = (Math.Sqrt(1 - Math.Cos(p_alpha) * Math.Cos(p_alpha) - Math.Cos(p_beta) * Math.Cos(p_beta) - Math.Cos(p_gamma) * Math.Cos(p_gamma) + 2 * Math.Cos(p_alpha) * Math.Cos(p_beta) * Math.Cos(p_gamma)));

            aa = (Math.Sin(p_alpha) / a / v);
            bb = (Math.Sin(p_beta) / b / v);
            cc = (Math.Sin(p_gamma) / c / v);

            alphaa = (Math.Acos((Math.Cos(p_beta) * Math.Cos(p_gamma) - Math.Cos(p_alpha)) / Math.Sin(p_beta) / Math.Sin(p_gamma)));
            betaa = (Math.Acos((Math.Cos(p_alpha) * Math.Cos(p_gamma) - Math.Cos(p_beta)) / Math.Sin(p_alpha) / Math.Sin(p_gamma)));
            gammaa = (Math.Acos((Math.Cos(p_alpha) * Math.Cos(p_beta) - Math.Cos(p_gamma)) / Math.Sin(p_alpha) / Math.Sin(p_beta)));

            mBMatrix[0, 0] = (float)aa;
            mBMatrix[0, 1] = (float)(bb * Math.Cos(gammaa));
            mBMatrix[0, 2] = (float)(cc * Math.Cos(betaa));
            mBMatrix[1, 0] = 0.0f;
            mBMatrix[1, 1] = (float)(bb * Math.Sin(gammaa));
            mBMatrix[1, 2] = (float)(-cc * Math.Sin(betaa) * Math.Cos(p_alpha));
            mBMatrix[2, 0] = 0.0f;
            mBMatrix[2, 1] = 0.0f;
            mBMatrix[2, 2] = (float)(1 / c);

            mOrthMatrix[0, 0] = (float)a;
            mOrthMatrix[0, 1] = (float)(b * Math.Cos(p_gamma));
            mOrthMatrix[0, 2] = (float)(c * Math.Cos(p_beta));
            mOrthMatrix[1, 0] = 0.0f;
            mOrthMatrix[1, 1] = (float)(b * Math.Sin(p_gamma));
            mOrthMatrix[1, 2] = (float)(-c * Math.Sin(p_beta) * Math.Cos(alphaa));
            mOrthMatrix[2, 0] = 0.0f;
            mOrthMatrix[2, 1] = 0.0f;
            mOrthMatrix[2, 2] = (float)(1 / cc);

            mOrthMatrixInvert = mOrthMatrix.Invert;

            // Set volume of the unit cell
            this._volume = v * a * b * c;
        }

        public Vec3 fract_2_orth(Vec3 coordinate)
        {
            return mOrthMatrix * coordinate;
        }

        public Vec3 orth_2_fract(Vec3 coordinate)
        {
            return mOrthMatrixInvert * coordinate;
        }

        public Vec3 cryst_2_fract(Vec3 coordinate)
        {
            return new Vec3((float)(coordinate.X / a), (float)(coordinate.Y / b), (float)(coordinate.Z / c));
        }

        public Vec3 fract_2_cryst(Vec3 coordinate)
        {
            return new Vec3((float)(coordinate.X * a), (float)(coordinate.Y * b), (float)(coordinate.Z * c));
        }

        #endregion

        #region constructor

        public Unit_cell()
        {
        }

        public Unit_cell(double a, double b, double c, double alpha, double beta, double gamma, SpaceGroup space_group)
        {
            this._a = a;
            this._b = b;
            this._c = c;
            this._alpha = alpha;
            this._beta = beta;
            this._gamma = gamma;
            // for calculation
            this.space_group = space_group;

            // Calculate transformation matrix
            init_matrix();
        }
        #endregion





        public double calculate_d(int h, int k, int l)
        {
            Vec3 hkl = new Vec3(h, k, l);
            Vec3 ret = hkl * mBMatrix; // convert Miler coord to Orthonormal
            return (1 / ret.Length);
        }

        public bool AreReflEquiv(Reflection cr, Reflection rl)
        {


            throw new NotImplementedException();
        }
    }
}
