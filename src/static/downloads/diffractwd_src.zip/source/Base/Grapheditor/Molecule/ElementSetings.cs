﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;


namespace Base
{
  
    public class ElementSetings
    {
        public byte Num;
        public string Symb;
        public double RCov;
        public double RVdW;
        public byte MaxBond;
        public double Mass;
        public string Name;
        public double[] Scatering;
        public double[] f1f2;
        public byte PosX;
        public byte PosY;

        public ElementSetings(byte number, string Symb, double RCov, double RVdW, byte MaxBond, double Mass, string Name, double[] Scatering, double[] f1f2, byte PosX, byte PosY)
        {
            this.Num = number;
            this.Symb = Symb;
            this.RCov = RCov;
            this.RVdW = RVdW;
            this.MaxBond = MaxBond;
            this.Mass = Mass;
            this.Name = Name;
            this.Scatering = Scatering;
            this.f1f2 = f1f2;
            this.PosX = PosX;
            this.PosY = PosY;
        }

        // Img and Re component of Scatering

        public double GetF0(double d, XRaySource Source)
        {
            if (Source.Source == SourceType.Neutron) throw new FileFormatExeption("Neutron diffraction not implemented yet");
            // 1/4*d^2 
            // (sin(Theta)/Lambda)^2
            double sthela = 1 / (4 * d * d);
            double f0 = 0;
            if (Scatering.Length == 9)
            {
                //It1992
                /* table format : a1 a2 a3 a4 b1 b2 b3 b4 c1 */
                // f = a1*Exp(-b1*sthela) + ..+ a4*Exp(-b4*sthela) + c1;
                f0 = Scatering[0] * Math.Exp(-Scatering[4] * sthela) + Scatering[1] * Math.Exp(-Scatering[5] * sthela) + Scatering[2] * Math.Exp(-Scatering[6] * sthela) + Scatering[3] * Math.Exp(-Scatering[7] * sthela) + Scatering[8];
            }
            else if (Scatering.Length == 11)
            {
                //WK1995
                /* table format :  b1 b2 b3 b4 b5 a1 a2 a3 a4 a5 c1 */
                f0 = Scatering[5] * Math.Exp(-Scatering[0] * sthela) + Scatering[6] * Math.Exp(-Scatering[1] * sthela) + Scatering[7] * Math.Exp(-Scatering[2] * sthela) + Scatering[8] * Math.Exp(-Scatering[3] * sthela) + Scatering[9] * Math.Exp(-Scatering[4] * sthela) + Scatering[10];
            }
            else throw new FileFormatExeption("Unknown Scatering type; Array Size:" + Scatering.Length);
            return f0;
        }

        public double GetF1(double d, XRaySource Source)
        {
            // Re and Im part of Compton Scartering
            double f1 = 0;
            int wavetype = (short)Source.Wave;
            if (wavetype == 11)
            {// Nonstandart Wave lenth 
                // Henke Table with linear aproximation
                int Z = this.Num;
                if (Z == 0) Z = 12; // Z- Q peak; set it to Carbon                
                double[] nf1f2 = HenkeTable.getf1f2(this.Symb, Source.WavelengthKev*1000, Z);
                f1 = nf1f2[0];
            }
            else
            { // tabulated wavelenth
                f1 = f1f2[wavetype - 1];
            }
            return f1;
        }

        public double GetScateringRe(double d, XRaySource Source)
        {
            double f0 = GetF0(d, Source);
            double f1 = GetF1(d, Source);
            return f0 + f1;
        }

        public double GetScateringIm(double d, XRaySource Source)
        {
            if (Source.Source == SourceType.Neutron) throw new FileFormatExeption("Neutron diffraction not implemented yet");
            double f2 = 0;

            int wavetype = (short)Source.Wave;
            if (wavetype == 11)
            {// Nonstandart Wave lenth 
                // Henke Table with linear aproximation
                int Z = this.Num;
                if (Z == 0) Z = 12; // Z- Q peak; set it to Carbon                
                double[] nf1f2 = HenkeTable.getf1f2(this.Symb, Source.WavelengthKev*1000, Z);
                f2 = nf1f2[1];
            }
            else
            { // tabulated wavelenth
                f2 = f1f2[wavetype - 1 + 10];
            }
            return f2;
        }
    }
}