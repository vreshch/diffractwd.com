﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Base
{
    [Serializable]
    public class Atom : IAtom
    {
        static int count_id = 0;
        private int _id = count_id + 1;

        public int id
        {
            get { return _id; }
        }

        [XmlIgnore]
        public ElementSetings Setings = null;

        private string _label = "";
        public string Label
        {
            get { return _label; }
            set { _label = value; }
        }

        public string Symbol
        {
            get
            {
                return Setings.Symb;
            }
            set
            {
                // Can throw Exception 
                ElementSetings e_s = PeriodicTable.GetElement(value);
                this.Setings = e_s;
            }
        }

        public short Number
        {
            get
            {
                return Setings.Num;
            }
        }

        public double RCov
        {
            get
            {
                return Setings.RCov;
            }
        }
        public double RVdW
        {
            get
            {
                return Setings.RVdW;
            }
        }

        private Vec3 _position = new Vec3(0, 0, 0);
        public Vec3 Position
        {
            get { return _position; }
            set { _position = value; }
        }

        private double _ocupancy = 1;
        public double Ocupancy
        {
            get { return _ocupancy; }
            set { _ocupancy = value; }
        }

        private double _uiso = 1;
        public double Uiso
        {
            get { return _uiso; }
            set { _uiso = value; }
        }

        private Matrix3x3 _u = new Matrix3x3();


        public Matrix3x3 U
        {
            get
            {
                return _u;
            }
            set
            {
                _u = value;
            }
        }


        public Atom()
        {
            Atom.count_id++;
        }

        public Atom(string type_symbol)
        {
            Atom.count_id++;
            this.Symbol = type_symbol;
        }

        public Atom(int id)
        {
            Atom.count_id++;
            this.Setings = PeriodicTable.GetElement(id);
        }
    }
}
