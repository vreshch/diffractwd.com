﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;
using System.Globalization;


namespace Base
{
    /* 
    * Main class - Describe molecule 
    * Serilizable* Can be saved
    * Hold Unit Cell and collection of atoms    
    */
    /*
    [Serializable]
    public class Molecule : IMolecule
    {
        // Title of the molecule
        private string _title = "";

        [XmlElement(ElementName = "Title")]
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        private string _comment = "";

        [XmlElement(ElementName = "Comment")]
        public string Comment
        {
            get { return _title; }
            set { _title = value; }
        }


        // For compatibility with other softwere
        private bool _is_periodic = true;
        [XmlElement(ElementName = "IsPeriodic")]
        public bool IsPeriodic
        {
            get { return _is_periodic; }
            set { _is_periodic = value; }
        }

        // Unit Cell
        private Unit_cell _cell = null;
        [XmlElement(ElementName = "Cell")]
        public Unit_cell Cell //Unit_cell
        {
            get
            {
                if (_cell == null) { _cell = new Unit_cell(1, 1, 1, 90, 90, 90, null); }
                return _cell;
            }
            set
            {
                Unit_cell _old = _cell;
                _cell = value;

                //if (OnUnitCellChanged != null) { OnUnitCellChanged(this, new MolUnitCellEventArgs(_old, _cell)); }
            }
        }

        private List<Atom> _atoms = new List<Atom>();

        [XmlArray(ElementName = "Atoms")]
        public List<Atom> Atoms
        {
            get { return _atoms; }
            set { _atoms = value; }
        }



        public MInformer _info = new MInformer();

        [XmlElement(ElementName = "info")]
        public IInformer info
        {
            get
            {
                return (_info as IInformer);
            }
            set
            {
                _info = (MInformer)value;
            }
        }

    }

    public interface IInformer
    {
        XmlDocument data
        {
            set;
            get;
        }
        void set(string value_name, string value);

        string get_string(string value_name, bool d_throw);
        string get_string(XmlNode doc, string value_name, bool d_throw);

        double get_double(string value_name, bool d_throw);
        double get_double(XmlNode doc, string value_name, double deffalut, bool d_throw);
        double get_double(XmlNode doc, string value_name, bool d_throw);

        XmlNode create_list(string value_name);
        void add_item(XmlNode node, Hashtable inf_data);
    }

    [Serializable]
    public class MInformer : IInformer
    {
        private XmlDocument _data;
        public XmlDocument data
        {
            set { _data = value; }
            get
            {
                if (_data == null)
                {
                    _data = new XmlDocument();
                    _data.LoadXml("<CIF><Data></Data></CIF>");
                }
                return _data;
            }
        }
        public void set(string value_name, string value)
        {
            XmlNode doc = data.SelectSingleNode("/CIF/Data");
            XmlNode node = doc.SelectSingleNode(value_name);
            if (node == null)
            {
                node = data.CreateElement(value_name);
                doc.AppendChild(node);
            }
            node.InnerText = value;
        }

        public string get_string(string value_name, bool d_throw)
        {
            XmlNode doc = data.SelectSingleNode("/CIF/Data");
            XmlNode node = doc.SelectSingleNode(value_name);
            if ((node == null) && (d_throw)) throw new FormatException("Record : _" + value_name + " not found!");
            if (node == null) return null;
            return node.InnerText;
        }
        public double get_double(string value_name, bool d_throw)
        {
            string s = get_string(value_name, d_throw);
            if (s == null) return -1;
            return CIFNumeric2Double(s);
        }

        public double get_double(XmlNode doc, string value_name, double deffalut, bool d_throw)
        {
            string s = get_string(doc, value_name, d_throw);
            if (s == null) return deffalut;
            return CIFNumeric2Double(s);
        }

        public double get_double(XmlNode doc, string value_name, bool d_throw)
        {
            string s = get_string(doc, value_name, d_throw);
            return CIFNumeric2Double(s);
        }

        public string get_string(XmlNode doc, string value_name, bool d_throw)
        {
            XmlNode node = doc.SelectSingleNode(value_name);
            if ((node == null) && (d_throw)) throw new FormatException("Record : _" + value_name + " not found!");
            if (node == null) return null;
            return node.InnerText;
        }

        public XmlNode create_list(string value_name)
        {
            XmlNode doc = data.SelectSingleNode("/CIF/Data");
            XmlNode node = doc.SelectSingleNode(value_name);
            if (node == null)
            {
                node = data.CreateElement(value_name);
                doc.AppendChild(node);
            }
            node.RemoveAll();
            return node;
        }

        public void add_item(XmlNode node, Hashtable inf_data)
        {
            XmlNode doc = data.SelectSingleNode("/CIF/Data");
            XmlNode item = data.CreateElement("Item");
            foreach (DictionaryEntry de in inf_data)
            {
                XmlNode el = data.CreateElement(de.Key as string);
                el.InnerText = (de.Value as string);
                item.AppendChild(el);
            }
            node.AppendChild(item);
        }

        private double MyParsed(string s)
        {
            //return Double.Parse(s);
            return Double.Parse(s, CultureInfo.InvariantCulture);// System.Globalization.NumberStyles.AllowDecimalPoint);            
        }

        private int MyParsei(string s)
        {
            return int.Parse(s);
        }


        private double CIFNumeric2Double(string s)
        {
            if ((s == ".") || (s == "?")) return 0.0;
            double v;
            if (s.Length > 1)
            {
                int z = s.IndexOf('(');
                if (z > 0)
                {
                    s = s.Substring(0, z);
                }
            }
            //s = s.Replace(".", ",");
            v = MyParsed(s);
            //v = double.Parse(s);
            return v;
        }

    }

    */

}
