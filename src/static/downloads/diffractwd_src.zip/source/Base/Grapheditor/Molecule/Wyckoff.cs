﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Base
{
    [Serializable]
    public class Wyckoff
    {
        [XmlElement(ElementName = "leter")]
        public string leter;

        [XmlElement(ElementName = "multiplicity")]
        public int multiplicity;

        [XmlElement(ElementName = "site_symmetry")]
        public string site_symmetry;

        [XmlIgnore, NonSerialized]
        private const float tolerance = 0.00001f;

        [XmlIgnore, NonSerialized]
        private const float tolerance_2 = 0.0000001f;
        // Cash
        [XmlIgnore]
        private string _code = null;

        [XmlElement(ElementName = "position_operator")]
        public string position_operator
        {
            get
            {
                if (_code == null) _code = Matrix3x3.symetry_name(rootation, translation);
                return _code;
            }
            set
            {
                Matrix3x3.construct(value, out _rootation, out _translation);
                _code = Matrix3x3.symetry_name(rootation, translation);
            }
        }
        [XmlIgnore, NonSerialized] // Save in bin formater
        public Matrix3x3 _rootation = null;

        [XmlIgnore] // Save in bin formater
        public Matrix3x3 rootation
        {
            get
            {
                if (_rootation == null) Matrix3x3.construct(_code, out _rootation, out _translation);
                return _rootation;
            }
            set
            {
                _rootation = value;
            }
        }

        [XmlIgnore, NonSerialized] // Save in bin formater
        public Vec3 _translation = null;

        [XmlIgnore] // Save in bin formater
        public Vec3 translation
        {
            get
            {
                if (_translation == null) Matrix3x3.construct(_code, out _rootation, out _translation);
                return _translation;
            }
            set
            {
                _translation = value;
            }
        }

        public bool IsE
        {
            get
            {
                return ((rootation.Equals(Matrix3x3.Equiv)) && (translation.Equals(Vec3.Zero, 0.0001f)));
            }
        }

        public Wyckoff() { }

        public Wyckoff(string leter, int multiplicity, string site_symmetry, string position_operator)
        {
            this.leter = leter;
            this.multiplicity = multiplicity;
            this.site_symmetry = site_symmetry;
            this.position_operator = position_operator;
        }

        public static Vec3 operator *(Wyckoff wyc, Vec3 coord)
        {
            return ((wyc.rootation * coord) + wyc.translation);
        }

        public bool is_correspond(Vec3 coord)
        {
            Vec3 co = Vec3.GetCoordWithoutTranslation(coord, double.Epsilon * 5);
            double d = ((this * co) - co).Length_Pow2;
            return (d < double.Epsilon * 5);
        }

        public override string ToString()
        {
            return multiplicity.ToString() + " " + leter + " :  " + position_operator;
        }
    }
}
