﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Xml;
using System.Windows.Forms;
using System.Drawing;
using System.Collections.Generic;


namespace Base
{

    public interface IProjectItem : IPropertiesEditable, ISelectable, IVisible
    {        
        event EventHandler<ItemEventArgs> SelectionChanged;
        event EventHandler<ItemEventArgs> VisibleChanged;
        event EventHandler<ObjModifeedEventArgs> Modified;
        
       
        Solution Parent { get; set; }
        ILineItem LineTag { get; set; }
        Color LineColor { get; set; }

        List<IProjectSubitem> SubItems
        {
            get;                        
        }

        void AddSubItem(IProjectSubitem item);
        void RemoveSubItem(IProjectSubitem item);
        
        string Title { get; set; }        
               
        void Close();


        /*
        /// <exception cref="ArgumentNullException">
        /// <paramref name="node"/> is null.
        /// </exception>+
        void Serialize(XmlElement node);

        /// <exception cref="InvalidDataException">
        /// The serialized format is corrupt and could not be loaded.
        /// </exception>
        /// <exception cref="ArgumentNullException">
        /// <paramref name="node"/> is null.
        /// </exception>
        void Deserialize(XmlElement node);  
        */
    }

    /*                                    
     */


    
    public interface IModifiable
    {
        event EventHandler Modified;

        bool IsDirty { get; }

        void Clean();
    }



}