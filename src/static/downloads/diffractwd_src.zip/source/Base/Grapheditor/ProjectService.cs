﻿using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.Core;
using System.IO;
using System.Xml.Serialization;
using System.Windows.Forms;
using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Zip;

namespace Base
{
    public class ProjectService
    {   
        private static string GetFileFilter(string addInTreePath1, string addInTreePath2)
        {
            StringBuilder b = new StringBuilder();
            b.Append("All known file types|");
            foreach (string filter in AddInTree.BuildItems(addInTreePath1, null, true))
            {
                b.Append(filter.Substring(filter.IndexOf('|') + 1));
                b.Append(';');
            }
            foreach (string filter in AddInTree.BuildItems(addInTreePath2, null, true))
            {
                b.Append(filter.Substring(filter.IndexOf('|') + 1));
                b.Append(';');
            }

            //All
            foreach (string filter in AddInTree.BuildItems(addInTreePath1, null, true))
            {
                b.Append('|');
                b.Append(filter);
            }

            foreach (string filter in AddInTree.BuildItems(addInTreePath2, null, true))
            {
                b.Append('|');
                b.Append(filter);
            }

            b.Append("|All files|*.*");
            return b.ToString();
        }
               
        private static bool FileFilterIssupported(string addInTreePath1, string addInTreePath2, string Extention)
        {
            foreach (string filter in AddInTree.BuildItems(addInTreePath1, null, true))
            {
                string s = filter.Substring(filter.IndexOf('|') + 1).Replace("*", "");
                if (s.ToUpper() == Extention.ToUpper()) return true;
            }
            foreach (string filter in AddInTree.BuildItems(addInTreePath2, null, true))
            {
                string s = filter.Substring(filter.IndexOf('|') + 1).Replace("*", "");
                if (s.ToUpper() == Extention.ToUpper()) return true;
            }
            return false;
        }        

        public static string GetOpenFileFilter()
        {
            return GetFileFilter("/Workspace/FileFilter", "/Workspace/FileImportData");
        }

        public static string GetSaveFileFilter()
        {
            return "DiffractWD Project File (*.pcw)|*.pcw";
        }
            
        public static bool IsSupportedFileType(string Ext)
        {
            return FileFilterIssupported("/Workspace/FileFilter", "/Workspace/FileImportData", Ext);            
        }

        public static void LoadFile(Workbench workbench, string filename)
        {
            // Is file alredy Loaded ???
            List<string> openfilelist = workbench.OpenFileList;
            if (workbench.OpenFileList.Contains(filename))
            {
                foreach (ISolutionView isv in workbench.ViewContents)
                {
                    if (isv.FileName == filename)
                    {
                        // Activate current Window; Do not load New Window
                        workbench.BringViewToFront(isv);                        
                        return;
                    }
                }
            }

            
            ISolutionView content = DisplayBindingManager.CreateViewContent(filename);
            if (content != null)
            {// This is open
                workbench.ShowView(content);
                PreformFileHistoryUpdate(filename);
                // Save Oped Directory;                
            }
            else
            { //  this is Import
                ISolutionView isv = workbench.ActiveViewContent;

                if (isv == null)
                {
                    // Import to new window
                    if (workbench.ViewContents.Count != 0) throw new NullReferenceException();
                    isv = new GraphViewContent();
                    // Add title to new document
                    isv.Sln.Title = "Document" + new_id;
                    new_id++;

                    IProjectItem ipi = DisplayBindingManager.CreateProjectItem(filename);
                    if (ipi != null)
                    {
                        isv.Add(ipi);
                        
                        workbench.ShowView(isv, true);
                        PreformFileHistoryUpdate(filename);
                        ipi.Selected = true;
                    }
                }
                else
                {
                    // Import to active window
                    IProjectItem ipi = DisplayBindingManager.CreateProjectItem(filename);
                    if (ipi != null)
                    {
                        isv.Add(ipi);
                        PreformFileHistoryUpdate(filename);
                        ipi.Selected = true;
                    }
                }
            }
        }
        
        public static List<string> ProjectListHistory
        {
            get 
            {
                string defalut = "";
                string s = "";
                List<string> filelist = new List<string>();
                s = PropertyService.Get("ProjectHistory1", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("ProjectHistory2", defalut);
                if (s != "") { filelist.Add(s); }
                s = PropertyService.Get("ProjectHistory3", defalut);
                if (s != "") {  filelist.Add(s); }
                s = PropertyService.Get("ProjectHistory4", defalut);
                if (s != "") {  filelist.Add(s); }
                s = PropertyService.Get("ProjectHistory5", defalut);
                if (s != "") {  filelist.Add(s); }
                s = PropertyService.Get("ProjectHistory6", defalut);
                if (s != "") {  filelist.Add(s); }
                s = PropertyService.Get("ProjectHistory7", defalut);
                if (s != "") {  filelist.Add(s); }
                s = PropertyService.Get("ProjectHistory8", defalut);
                if (s != "") {  filelist.Add(s); }
                s = PropertyService.Get("ProjectHistory9", defalut);
                if (s != "") {  filelist.Add(s); }
                s = PropertyService.Get("ProjectHistory10", defalut);
                if (s != "") {  filelist.Add(s); }

                // Remove from History List NonExisting Files
                for (int i = 0; i < filelist.Count; i++)
                {
                    string fn = filelist[filelist.Count - i - 1];
                    if (!File.Exists(fn))
                    {
                        filelist.Remove(fn);
                    }
                }


                return filelist;
            }
            set 
            {
                List<string> list = value;
                // Remove oldest record to make shure only 10 records;
                while (list.Count > 10) { list.RemoveAt(0); }
                // Add this list to history
                for (int i = 0; i < 9; i++)
                {
                    if (i > (list.Count - 1)) continue;
                    string curr = list[i];
                    PropertyService.Set("ProjectHistory" + (i + 1).ToString(), curr);
                }
            } 
        }

        public static List<string> FileListHistory
        {
            get
            {
                string defalut = "";
                string s = "";
                List<string> filelist = new List<string>();
                s = PropertyService.Get("FileHistory1", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("FileHistory2", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("FileHistory3", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("FileHistory4", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("FileHistory5", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("FileHistory6", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("FileHistory7", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("FileHistory8", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("FileHistory9", defalut);
                if (s != "") {  filelist.Add(s); } 
                s = PropertyService.Get("FileHistory10", defalut);
                if (s != "") {  filelist.Add(s); } 

                // Remove from History List NonExisting Files
                for (int i = 0; i < filelist.Count; i++)
                {
                    string fn = filelist[filelist.Count - i - 1];
                    if (!File.Exists(fn))
                    {
                        filelist.Remove(fn);
                    }
                }
                
                return filelist;
            }
            set
            {
                List<string> list = value;             
                // Remove oldest record to make shure only 10 records;
                while (list.Count >10 ) { list.RemoveAt(0); }
                // Add this list to history
                for (int i = 0; i < 9; i++)
                {
                    if (i > (list.Count-1)) continue;
                    string curr = list[i];
                   PropertyService.Set("FileHistory" + (i+1).ToString(), curr);                    
                }
            }
        }

        public static string FormatFileName(string filename, int maxlenght)
        {                    
            if (filename.Length < maxlenght) return filename;            
            string[] parts = filename.Split(Path.DirectorySeparatorChar);
            if (parts.Length <1) throw new NullReferenceException ("Incorect file name");


            string data_begin = parts[0] + Path.DirectorySeparatorChar + "..." + Path.DirectorySeparatorChar;            
            string data_end   = parts[parts.Length-1];
            string data_medium = "";

            for (int i = (parts.Length-2); i > 1; i--)
            {
                string curr_part = parts[i];
                int expected_length = (data_begin + data_medium + data_end).Length + curr_part.Length;
                if (expected_length > maxlenght) break;
                data_medium = curr_part + Path.DirectorySeparatorChar + data_medium; 
            }
            
            return (data_begin+data_medium+data_end);

        }

        private static void PreformFileHistoryUpdate(string openfilename)
        {
            string ext = Path.GetExtension(openfilename);
            
            PropertyService.Set("DefalutOpenDir", Path.GetDirectoryName(openfilename));

            if (ext==".pcw")
            {
                // Project File List Update
                List<string> filelist = ProjectListHistory;                             //  Load File List From Config
                if (filelist.Contains(openfilename)) filelist.Remove(openfilename);     //  Remove File At Current Position
                filelist.Add(openfilename);                                             //  Add it at the End of List
                ProjectListHistory = filelist;                                          //  Save the List
            }
            else
            {
                // Same, but just for Imported  Files
                List<string> filelist = FileListHistory;
                if (filelist.Contains(openfilename)) filelist.Remove(openfilename);
                filelist.Add(openfilename);
                FileListHistory = filelist;
            }
            
        }

        public static string GetInitialDirectory
        {
            get
            {
                return PropertyService.Get("DefalutOpenDir", "C:\\");
            }
        }      


        private static int new_id = 1;
        
        public static void OpenNewFile(Workbench workbench)
        {
            GraphViewContent gvc = new GraphViewContent();
            gvc.Sln.Title = "Document" + new_id;
            new_id++;
            workbench.ShowView(gvc);
            gvc.Sln.Selected = true;
        }
       
        public static bool Save(string fileName, GraphViewContent gvc)
        {
            bool ret_res = true;
            Stream sr = new FileStream(fileName, FileMode.Create);
            GZipOutputStream gzip_stream = new GZipOutputStream(sr);

            ContentData full_data = new ContentData(gvc.Sln, gvc.ZGC.Properties);
            try
            {
                XmlSerializer x = new XmlSerializer(full_data.GetType());
                x.Serialize(gzip_stream, full_data);
            }
            catch (Exception e)
            {
                MessageBox.Show("Can not save the file :" + e.ToString(), "Error");
                ret_res = false;
            }
            finally
            {
                if (gzip_stream!=null) gzip_stream.Close();
                if (sr!=null) sr.Close();
            }

            return ret_res;
        }       

        public static void LoadSolution(string fileName, GraphViewContent graphViewContent)
        {  
            
            Stream ReadFileStream = new FileStream(fileName, FileMode.Open);
            GZipInputStream gzip_stream = new GZipInputStream(ReadFileStream);

            XmlSerializer SerializerObj = new XmlSerializer(typeof(ContentData));

            ContentData LoadedObj = (ContentData)SerializerObj.Deserialize(gzip_stream);
            ReadFileStream.Close();


            graphViewContent.Sln = LoadedObj.Project;
            LoadedObj.Project.DeserializationFinish();

            graphViewContent.ZGC.Properties = LoadedObj.GraphProperties;        
            graphViewContent.RedrawContent();
            
            // Select Object Properties
            graphViewContent.Sln.Selected = true;

        }
        
    }


    public class FileHistoryMenuBuilder : ISubmenuBuilder
    {
        class MyMenuItem : MenuCommand
        {
            string FileName;

            public MyMenuItem(string FileName): base(null, null)
            {
                this.FileName = FileName;
                this.Text = ProjectService.FormatFileName(FileName, 40); 
            }

            protected override void OnClick(EventArgs e)
            {
                base.OnClick(e);
                ProjectService.LoadFile(Workbench.Instance, this.FileName);                
            }
        }

        public ToolStripItem[] BuildSubmenu(Codon codon, object owner)
        {
            List<ToolStripItem> items = new List<ToolStripItem>();
            List<string> filelist = ProjectService.FileListHistory;
            // Reverce order - biger number - newer file;
            for(int i = (filelist.Count -1); i>=0; i--)
            {               
                items.Add(new MyMenuItem(filelist[i]));
            }
            return items.ToArray();
        }
    }


    public class ProjectHistoryMenuBuilder : ISubmenuBuilder
    {
        class MyMenuItem : MenuCommand
        {
            string FileName;

            public MyMenuItem(string FileName): base(null, null)
            {
                this.FileName = FileName;
                this.Text = ProjectService.FormatFileName(FileName, 40);                    
            }

            protected override void OnClick(EventArgs e)
            {
                base.OnClick(e);
                ProjectService.LoadFile(Workbench.Instance, this.FileName);  
            }
        }

        public ToolStripItem[] BuildSubmenu(Codon codon, object owner)
        {
            List<ToolStripItem> items = new List<ToolStripItem>();
            List<string> filelist = ProjectService.ProjectListHistory;
            List<string> openfilelist =  Workbench.Instance.OpenFileList; 

            for (int i = (filelist.Count - 1); i >= 0; i--)
            {
                string currfile = filelist[i];
                if (!openfilelist.Contains(currfile))
                {
                    items.Add(new MyMenuItem(filelist[i]));
                }
            }
            return items.ToArray();
        }
    }


    [Serializable]
    public class ContentData
    {
        [XmlElement(ElementName = "Project")]
        public Solution Project = null;
        [XmlElement(ElementName = "GraphProperties")]
        public GraphProperties GraphProperties = null;

        public ContentData()
        {
        }
        public ContentData(Solution Project, GraphProperties Properties)
        {
            this.Project = Project;
            this.GraphProperties = Properties;
        }
    }


}
