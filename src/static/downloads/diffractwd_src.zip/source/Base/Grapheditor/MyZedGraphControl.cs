﻿using System;
using System.Collections.Generic;
using System.Text;
using ZedGraph;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using ICSharpCode.Core;

namespace Base
{
           
    public class MyZedGraphControl : ZedGraphControl
    {                        
        private GraphProperties _Properties = null;
        public GraphProperties Properties
        {
            get 
            {
                if (_Properties == null)
                _Properties = new GraphProperties(this);
                _Properties.PropertiesChanged += new EventHandler<ObjModifeedEventArgs>(_Properties_PropertiesChanged);
                return _Properties;
            }
            set
            {
                _Properties = value;
                _Properties.PropertiesChanged -= new EventHandler<ObjModifeedEventArgs>(_Properties_PropertiesChanged);
                Properties.Applay(this);
                this.Invalidate();
            }
        }

        private void _Properties_PropertiesChanged(object sender, ObjModifeedEventArgs e)
        {
            if (e.InvadiateNeaded) this.Invalidate();
            if (e.RedrawNeaded)
            {
                throw new NotImplementedException();
            }
        }

        private double _ScaleXAxisMinX = 0;// TODO nead to be loaded setings file!!!
        public double ScaleXAxisMin
        {
            get { return _ScaleXAxisMinX; }
            set
            {
                _ScaleXAxisMinX = value;
                GraphPane.XAxis.Scale.Min = value;
                ScrollMinX = value;
                AxisChange();
            }
        }

        private double _ScaleXAxisMaxX = 50;// TODO nead to be loaded setings file!!!
        // Display Axis 2 theta  options
        public double ScaleXAxisMax
        {
            get { return _ScaleXAxisMaxX; }
            set
            {
                _ScaleXAxisMaxX = value;
                GraphPane.XAxis.Scale.Max = value;
                ScrollMaxX = value;
                AxisChange();
            }
        }

        private const double MaxXAllowed = 180.0;
        private const double MinXAllowed = 5.0;
        private const double ZoomAxisFactor = 1.3;

        public void ApplayAxisX()
        {
            this.ScaleXAxisMin = _ScaleXAxisMinX;
            this.ScaleXAxisMax = _ScaleXAxisMaxX;
        }

        public MyZedGraphControl()
        {
            this.Font = new System.Drawing.Font("Times New Roman", 8F);
            this.IsEnableVZoom = false;


            this.GraphPane.Title.IsVisible = false;
            this.GraphPane.XAxis.Title.Text = "2 Theta";
            this.GraphPane.YAxis.Title.Text = "%";
            this.GraphPane.IsFontsScaled = false;

            this.GraphPane.XAxis.Title.IsVisible = false;
            this.GraphPane.YAxis.Title.IsVisible = false;
            this.GraphPane.XAxis.MajorTic.Size = 10;
            this.GraphPane.XAxis.MinorTic.Size = 6;
            this.GraphPane.XAxis.MinorTic.IsOpposite = false;


            // Show X Grid
            this.GraphPane.XAxis.MajorGrid.IsVisible = true;
            // Minimal Marign
            //graphPane.Margin.All = 5;

            // Y - Invisible!
            //graphPane.YAxis.Scale.IsVisible = false;
            this.GraphPane.YAxis.MajorTic.IsOutside = false;
            this.GraphPane.YAxis.MinorTic.IsOutside = false;


            //graphPane.YAxis.Scale.IsVisible = false;            
            //graphPane.YAxis.Scale.IsSkipLastLabel = false;
            this.GraphPane.YAxis.Scale.Max = 100;
            this.GraphPane.YAxis.Scale.Min = -3;
            this.GraphPane.YAxis.Color = Color.Gray;


            this.GraphPane.XAxis.Scale.Max = 50;
            this.GraphPane.XAxis.Scale.Min = 0;
            this.GraphPane.XAxis.MajorTic.IsInside = false;
            this.GraphPane.XAxis.MinorTic.IsInside = false;


            // Add 10% to scale range//   zgc.ScrollGrace = 0.1;
            this.GraphPane.Border.IsVisible = false;
            this.GraphPane.Legend.IsVisible = false;

            this.GraphPane.IsBoundedRanges = true;   // Automatic X Intensity modification !!!
            this.IsAutoScrollRange = true;
            this.IsShowHScrollBar = true;            // Show Scroll Bar!!!

            // Zoom 
            this.ZoomStepFraction = 0.1;
      
            //this.IsZoomOnMouseCenter = true;            
            //IsZoomOnMouseCenter

            // Important to do this;
             // X Axis work incorently sometimes.            
        }
        
        public bool IsZoomInAllowed
        {
            get 
            {
                return ((this.GraphPane.XAxis.Scale.Max - this.GraphPane.XAxis.Scale.Min) > MinXAllowed);
            }
        }

        public bool IsZoomOutAllowed
        {
            get 
            {
                return ((this.GraphPane.XAxis.Scale.Max - this.GraphPane.XAxis.Scale.Min) < MaxXAllowed);
            }
        }

        public bool IsZoomUndoAllowed
        {
            get 
            {
                return (!this.GraphPane.ZoomStack.IsEmpty);
            }
        }
        
        public void MyZoomIn()
        {
            if (((this.GraphPane.XAxis.Scale.Max - this.GraphPane.XAxis.Scale.Min) > MinXAllowed) == false) return;

            ZoomState oldState = this.GraphPane.ZoomStack.Push(this.GraphPane, ZoomState.StateType.Zoom);
            
            double zoomfraction = (1.0 / ZoomAxisFactor);            
            this.ZoomPane(this.GraphPane, zoomfraction, new PointF(0, 0), false);
            
            //if (this.ZoomEvent != null) this.ZoomEvent(this, oldState, new ZoomState(this.GraphPane, ZoomState.StateType.Zoom)); 
        }

        public void MyZoomOut()
        {
            if (((this.GraphPane.XAxis.Scale.Max - this.GraphPane.XAxis.Scale.Min) < MaxXAllowed) == false) return;

            ZoomState oldState = this.GraphPane.ZoomStack.Push(this.GraphPane, ZoomState.StateType.Zoom);
            
            double zoomfraction = ZoomAxisFactor;            
            this.ZoomPane(this.GraphPane, zoomfraction, new PointF(0, 0), false);

            //if (this.ZoomEvent != null) this.ZoomEvent(this, oldState, new ZoomState(this.GraphPane, ZoomState.StateType.Zoom)); 
        }

        // Allow user Zoom only to 5 deg per window, and zoom out not more than 180;
        protected override void OnMouseWheel(MouseEventArgs e)
        {
            double delta = (e.Delta < 0 ? 1.0 : -1.0);

            if (delta > 0)
            {
                if (((this.GraphPane.XAxis.Scale.Max - this.GraphPane.XAxis.Scale.Min) < MaxXAllowed) == false) return;
            }
            if (delta < 0)
            {
                if (((this.GraphPane.XAxis.Scale.Max - this.GraphPane.XAxis.Scale.Min) > MinXAllowed) == false) return;
            }
            base.OnMouseWheel(e);
        }

        public void MyZoomUndo()
        {
            GraphPane pane = this.GraphPane;
            ZoomOut(pane);
        }

        public void MyPrint()
        {
            this.DoPrint();
        }
        
        public void MyPrintPreview()
        {
            this.DoPrintPreview();
        }
        
        public void MyPrintPageSetup()
        {
            this.DoPageSetup();
        }

        public void MyExportImage()
        {
            try
            {
                this.SaveAsEmf();
            }
            catch (Exception e)
            {
                MessageService.ShowError(e);
            }
        }
    }


    [Serializable]
    public class GraphProperties
    {
        private MyZedGraphControl _MyControl = null;
        private MyZedGraphControl MyControl
        {
            get { return _MyControl; }
            set { _MyControl = value; }
        }

        private double _GraphStart = 5;
        [XmlElement(ElementName = "GraphStart")]
        public double GraphStart
        {
            get
            {
                if (MyControl != null) return MyControl.ScaleXAxisMin;
                return _GraphStart; 
            }
            set 
            {
                if (MyControl != null) { MyControl.ScaleXAxisMin = value; }
                if (_GraphStart!=value)
                {
                    OnPropertiesChanged(this, true, false);
                }
                _GraphStart = value;
            }
        }

        private double _GraphEnd = 45;
        [XmlElement(ElementName = "GraphEnd")]
        public double GraphEnd
        {
            get 
            {
                if (MyControl != null) return MyControl.ScaleXAxisMax;
                return _GraphEnd; 
            }
            set 
            {
                if (MyControl != null) { MyControl.ScaleXAxisMax = value; }

                if (_GraphEnd != value)
                {
                    OnPropertiesChanged(this, true, false); ;
                }
                _GraphEnd = value; 
            }
        }

        private Padding _Margin  = new Padding ();
        [XmlElement(ElementName="Margin")]
        public Padding Margin 
        {
            get 
            {
                if (MyControl!= null) return MyControl.Margin;
                return _Margin;
            }
            set 
            {
               if(MyControl != null) { MyControl.Margin = value; }

               if (_Margin != value)
               {
                   OnPropertiesChanged(this, true, false);
               }
                _Margin = value;
            } 
        }        
        
        private GraphGridOptions _MajorGridX = null;        
        [XmlElement(ElementName="MajorGridX")]
        public GraphGridOptions MajorGridX 
        {
            get 
            {
                if (_MajorGridX != null){ return _MajorGridX; }
                if (MyControl != null) 
                {
                    _MajorGridX = new GraphGridOptions(MyControl.GraphPane.XAxis.MajorGrid);
                    return  _MajorGridX;
                }
                throw new NullReferenceException("Improper use if MajorGrid X");
            }
            set 
            {                
                if (_MajorGridX != null)
                {
                    _MajorGridX.PropertiesChanged -= new EventHandler(_Ch_PropertiesChanged);
                }
                _MajorGridX = value;
                _MajorGridX.PropertiesChanged += new EventHandler(_Ch_PropertiesChanged);


                if (MyControl != null) 
                {
                    _MajorGridX.Applay(MyControl.GraphPane.XAxis.MajorGrid);
                }                
            }
        }
            
                            
        private GraphGridOptions _MinorGridX = null;
        [XmlElement(ElementName = "MinorGridX")]
        public GraphGridOptions MinorGridX 
        {
            get
            {
                if (_MinorGridX != null) { return _MinorGridX; }
                if (MyControl != null)
                {
                    _MinorGridX = new GraphGridOptions(MyControl.GraphPane.XAxis.MajorGrid);
                    return _MinorGridX;
                }
                throw new NullReferenceException("Improper use if MinorGrid X");
            }
            set
            {
                if (_MinorGridX != null)
                {
                    _MinorGridX.PropertiesChanged -= new EventHandler(_Ch_PropertiesChanged);
                }
                _MinorGridX = value;
                _MinorGridX.PropertiesChanged += new EventHandler(_Ch_PropertiesChanged);


                if (MyControl != null)
                {
                    _MinorGridX.Applay(MyControl.GraphPane.XAxis.MinorGrid);
                }
            }
        }

        
        private GraphGridOptions _MajorGridY = null;
        [XmlElement(ElementName = "MajorGridY")]
        public GraphGridOptions MajorGridY
        {
            get
            {
                if (_MajorGridY != null) { return _MajorGridY; }
                if (MyControl != null)
                {
                    _MajorGridY = new GraphGridOptions(MyControl.GraphPane.YAxis.MajorGrid);
                    return _MajorGridY;
                }
                throw new NullReferenceException("Improper use if MajorGrid Y");
            }
            set
            {
                if (_MajorGridY != null)
                {
                    _MajorGridY.PropertiesChanged -= new EventHandler(_Ch_PropertiesChanged);
                }
                _MajorGridY = value;
                _MajorGridY.PropertiesChanged += new EventHandler(_Ch_PropertiesChanged);

                if (MyControl != null)
                {                    
                    _MajorGridX.Applay(MyControl.GraphPane.YAxis.MajorGrid);
                }                
            }
        }


        private GraphGridOptions _MinorGridY = null;
        [XmlElement(ElementName = "MinorGridY")]
        public GraphGridOptions MinorGridY
        {
            get
            {
                if (_MinorGridY != null) { return _MinorGridY; }
                if (MyControl != null)
                {
                    _MinorGridY = new GraphGridOptions(MyControl.GraphPane.YAxis.MajorGrid);
                    return _MinorGridY;
                }
                throw new NullReferenceException("Improper use if MinorGrid Y");
            }
            set
            {
                if (_MinorGridY != null)
                {
                    _MinorGridY.PropertiesChanged -= new EventHandler(_Ch_PropertiesChanged);
                }
                _MinorGridY = value;
                _MinorGridY.PropertiesChanged += new EventHandler(_Ch_PropertiesChanged);

                if (MyControl != null)
                {
                    _MinorGridY.Applay(MyControl.GraphPane.YAxis.MinorGrid);
                }                
            }
        }


        private GraphAxisOptions _AxisX = null;
        [XmlElement(ElementName = "AxisX")]
        public GraphAxisOptions AxisX
        {
            get
            {
                if (_AxisX != null) { return _AxisX; }
                if (MyControl != null)
                {
                    _AxisX = new GraphAxisOptions(MyControl.GraphPane.XAxis);
                    return _AxisX;
                }
                throw new NullReferenceException("Improper use of Axis X");
            }
            set
            {
                if (_AxisX != null)
                {
                    _AxisX.PropertiesChanged -= new EventHandler(_Ch_PropertiesChanged);
                }
                _AxisX = value;
                _AxisX.PropertiesChanged += new EventHandler(_Ch_PropertiesChanged);
                if (MyControl != null)
                {
                    _AxisX.Applay(MyControl.GraphPane.XAxis);
                }
            }
        }


        private GraphAxisOptions _AxisY = null;
        [XmlElement(ElementName = "AxisY")]
        public GraphAxisOptions AxisY
        {
            get
            {
                if (_AxisY != null) { return _AxisY; }
                if (MyControl != null)
                {
                    _AxisY = new GraphAxisOptions(MyControl.GraphPane.YAxis);
                    return _AxisY;
                }
                throw new NullReferenceException("Improper use of Axis Y");
            }
            set
            {
                if (_AxisY != null)
                {
                    _AxisY.PropertiesChanged -= new EventHandler(_Ch_PropertiesChanged);
                }
                _AxisY = value;
                _AxisY.PropertiesChanged += new EventHandler(_Ch_PropertiesChanged);
                if (MyControl != null)
                {
                    _AxisY.Applay(MyControl.GraphPane.YAxis);
                }
            }
        }


        public event EventHandler<ObjModifeedEventArgs> PropertiesChanged;
        private void OnPropertiesChanged(object sender, bool InvadiateNeaded, bool RedrawNeaded)
        {
            if (PropertiesChanged != null)
            {
                PropertiesChanged(this, new ObjModifeedEventArgs(sender,InvadiateNeaded, RedrawNeaded));
            }
        }


        private void _Ch_PropertiesChanged(object sender, EventArgs e)
        {
            OnPropertiesChanged(this, true, false);
        }


        public GraphProperties()
        {
        }
        

        public GraphProperties(MyZedGraphControl myZedGraphControl): base()
        {            
            this.MajorGridX = new GraphGridOptions(myZedGraphControl.GraphPane.XAxis.MajorGrid);
            this.MinorGridX = new GraphGridOptions(myZedGraphControl.GraphPane.XAxis.MinorGrid);
            this.MajorGridY = new GraphGridOptions(myZedGraphControl.GraphPane.YAxis.MajorGrid);
            this.MinorGridY = new GraphGridOptions(myZedGraphControl.GraphPane.YAxis.MinorGrid);

            this.AxisX = new GraphAxisOptions(myZedGraphControl.GraphPane.XAxis);
            this.AxisY = new GraphAxisOptions(myZedGraphControl.GraphPane.XAxis);
            
            this.MyControl = myZedGraphControl;
        }


        public void Applay(MyZedGraphControl myZedGraphControl)
        {
            myZedGraphControl.ScaleXAxisMin = GraphStart;
            myZedGraphControl.ScaleXAxisMax = GraphEnd;
            //myZedGraphControl.AxisChange();
            myZedGraphControl.Margin = Margin;


            MajorGridX.Applay(myZedGraphControl.GraphPane.XAxis.MajorGrid);
            MinorGridX.Applay(myZedGraphControl.GraphPane.XAxis.MinorGrid);
            MajorGridY.Applay(myZedGraphControl.GraphPane.YAxis.MajorGrid);
            MinorGridY.Applay(myZedGraphControl.GraphPane.YAxis.MinorGrid);

            AxisX.Applay(myZedGraphControl.GraphPane.XAxis);
            AxisY.Applay(myZedGraphControl.GraphPane.YAxis);

            this.MyControl = myZedGraphControl;
        }
    }


    [Serializable]
    public class GraphGridOptions
    {
        private MinorGrid _MyGrid = null;
        private MinorGrid MyGrid
        {
            get { return _MyGrid;  }
            set { _MyGrid = value; }
        }
        
        private bool _Visible;
        [XmlElement(ElementName = "Visible")]
        public bool Visible
        {
            get 
            {
                if (MyGrid != null) { return MyGrid.IsVisible; }
                return _Visible;
            }
            set 
            {
                if (MyGrid != null) { MyGrid.IsVisible = value; }
                if (_Visible != value)
                {
                    OnPropertiesChanged(this);
                }
                _Visible = value;
            }
        }

        private Color _Color;
        [XmlIgnore]
        public Color Color
        {
            get 
            {
                if (MyGrid != null) { return MyGrid.Color; }
                return _Color;
            }
            set
            {
                if (MyGrid != null) { MyGrid.Color = value; }
                if (_Color != value)
                {
                    OnPropertiesChanged(this);
                }
                _Color = value;
            }
        }

        [XmlElement(ElementName = "Color")]
        public int ColorAsInt
        {
            get             
            {
                return this.Color.ToArgb();
            }
            set 
            {
                this.Color = Color.FromArgb(value);
            }
        }

        private float _DashOn;
        [XmlElement(ElementName = "DashOn")]
        public float DashOn
        {
            get 
            {
                if (MyGrid != null) return MyGrid.DashOn;
                return _DashOn;
            }
            set
            {
                if (MyGrid != null) { MyGrid.DashOn = value; }

                if (_DashOn != value)
                {
                    OnPropertiesChanged(this);
                }
                _DashOn = value;
            }
        }
        private float _DashOff;

        [XmlElement(ElementName = "DashOff")]
        public float DashOff
        {
            get
            {
                if (MyGrid != null) return MyGrid.DashOff;
                return _DashOff;
            }
            set
            {
                if (MyGrid != null) MyGrid.DashOff = value;

                if (_DashOff != value)
                {
                    OnPropertiesChanged(this);
                }
                _DashOff = value;
            }
        }

        public event EventHandler PropertiesChanged;
        
        private void OnPropertiesChanged(object sender)
        {
            if (PropertiesChanged != null)
            {
                PropertiesChanged(sender, EventArgs.Empty);
            }
        }

        public GraphGridOptions()
        { 
        }
        public GraphGridOptions(MinorGrid MinorGrid):base()
        {
            this.MyGrid = MinorGrid;
        }
        public void Applay(MinorGrid Grid)
        {            
            Grid.IsVisible = Visible;
            Grid.Color = Color;
            Grid.DashOn = DashOn;
            Grid.DashOff = DashOff;
            this.MyGrid = Grid;
        }
    }

    [Serializable]
    public class GraphAxisOptions
    {
        private Axis _MyAxis = null;
        private Axis MyAxis
        {
            get { return _MyAxis; }
            set { _MyAxis = value; }
        }

        private bool _Visible;
        [XmlElement(ElementName = "Visible")]
        public bool IsVisible
        {
            get
            {
                if (MyAxis != null) { return MyAxis.IsVisible; }
                return _Visible;
            }
            set
            {
                if (MyAxis != null) { MyAxis.IsVisible = value; }
                if (_Visible != value)
                {
                    OnPropertiesChanged(this);
                }
                _Visible = value;
            }
        }     

        private bool _MajorTic_IsOpposite;
        [XmlElement(ElementName = "MajorTic_IsOpposite")]
        public bool MajorTic_IsOpposite
        {
            get
            {
                if (MyAxis != null) { return MyAxis.MajorTic.IsOpposite; }
                return _MajorTic_IsOpposite;
            }
            set
            {
                if (MyAxis != null) { MyAxis.MajorTic.IsOpposite = value; }
                if (_MajorTic_IsOpposite != value)
                {
                    OnPropertiesChanged(this);
                }
                _MajorTic_IsOpposite = value;
            }
        }     

        private bool _MinorTic_IsOpposite;
        [XmlElement(ElementName = "MinorTic_IsOpposite")]
        public bool MinorTic_IsOpposite
        {
            get
            {
                if (MyAxis != null) { return MyAxis.MinorTic.IsOpposite; }
                return _MinorTic_IsOpposite;
            }
            set
            {
                if (MyAxis != null) { MyAxis.MinorTic.IsOpposite = value; }
                if (_MinorTic_IsOpposite != value)
                {
                    OnPropertiesChanged(this);
                }
                _MinorTic_IsOpposite = value;
            }
        }     


        private bool _NumbersVisible;
        [XmlElement(ElementName = "NumbersVisible")]
        public bool NumbersVisible
        {
            get
            {
                if (MyAxis != null) { return MyAxis.Scale.IsVisible; }
                return _NumbersVisible;
            }
            set
            {
                if (MyAxis != null) { MyAxis.Scale.IsVisible = value; }
                if (_NumbersVisible != value)
                {
                    OnPropertiesChanged(this);
                }
                _NumbersVisible = value;
            }
        }


        private double _MajorStep;
        [XmlElement(ElementName = "MajorStep")]
        public double MajorStep
        {
            get
            {
                if (MyAxis != null) { return MyAxis.Scale.MajorStep; }
                return _MajorStep;
            }
            set
            {
                if (MyAxis != null) { MyAxis.Scale.MajorStep = value; }
                if (_MajorStep != value)
                {
                    OnPropertiesChanged(this);
                }
                _MajorStep = value;
            }
        }


        private double _MinorStep;
        [XmlElement(ElementName = "MinorStep")]
        public double MinorStep
        {
            get
            {
                if (MyAxis != null) { return MyAxis.Scale.MinorStep; }
                return _MinorStep;
            }
            set
            {
                if (MyAxis != null) { MyAxis.Scale.MinorStep = value; }

                if (_MinorStep != value)
                {
                    OnPropertiesChanged(this);
                }
                _MinorStep = value;
            }
        }
        

        private float _MajorTic_Size;
        [XmlElement(ElementName = "MajorTic_Size")]
        public float MajorTic_Size
        {
            get
            {
                if (MyAxis != null) { return MyAxis.MajorTic.Size; }
                return _MajorTic_Size;
            }
            set
            {
                if (MyAxis != null) { MyAxis.MajorTic.Size = value; }
                if (_MajorTic_Size != value)
                {
                    OnPropertiesChanged(this);
                }
                _MajorTic_Size = value;
            }
        }


        private float _MinorTic_Size;
        [XmlElement(ElementName = "MinorTic_Size")]
        public  float MinorTic_Size
        {
            get
            {
                if (MyAxis != null) { return MyAxis.MinorTic.Size; }
                return _MinorTic_Size;
            }
            set
            {
                if (MyAxis != null) { MyAxis.MinorTic.Size = value; }

                if (_MinorTic_Size != value)
                {
                    OnPropertiesChanged(this);
                }

                _MinorTic_Size = value;
            }
        }


        private bool _TitleVisible;
        [XmlElement(ElementName = "TitleVisible")]
        public  bool TitleVisible
        {
            get
            {
                if (MyAxis != null) { return MyAxis.Title.IsVisible; }
                return _TitleVisible;
            }
            set
            {
                if (MyAxis != null) { MyAxis.Title.IsVisible = value; }

                if (_TitleVisible != value)
                {
                    OnPropertiesChanged(this);
                }

                _TitleVisible = value;
            }
        }

        private string _Text;
        [XmlElement(ElementName = "Text")]
        public  string Text
        {
            get
            {
                if (MyAxis != null) { return MyAxis.Title.Text; }
                return _Text;
            }
            set
            {
                if (MyAxis != null) { MyAxis.Title.Text = value; }

                if (_Text != value)
                {
                    OnPropertiesChanged(this);
                }

                _Text = value;
            }
        }

        public event EventHandler PropertiesChanged;
        private void OnPropertiesChanged(object sender)
        {
            if (PropertiesChanged != null)
            {
                PropertiesChanged(sender, EventArgs.Empty);
            }
        }

        public GraphAxisOptions()
        { 
        }
        public GraphAxisOptions(Axis Axis): base()
        {
            this.MyAxis = Axis;
        }
        public void Applay(Axis Axis)
        {            
            Axis.IsVisible = this.IsVisible;
            Axis.MajorTic.IsOpposite = this.MajorTic_IsOpposite;
            Axis.MinorTic.IsOpposite = this.MinorTic_IsOpposite;
            Axis.Scale.IsVisible = this.NumbersVisible;
            Axis.Scale.MajorStep = this.MajorStep;
            Axis.Scale.MinorStep = this.MinorStep;
            Axis.MajorTic.Size = this.MajorTic_Size;
            Axis.Title.IsVisible = this.TitleVisible;
            Axis.Title.Text = this.Text;
            this.MyAxis = Axis;
        }
    }

}
