﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace Base
{
    public interface IProjectSubitem : ISelectable, IVisible, IPropertiesEditable
    {
        event EventHandler<ItemEventArgs> SelectionChanged;
        event EventHandler<ItemEventArgs> VisibleChanged;        
        event EventHandler<ObjModifeedEventArgs> Modified;

        IProjectItem Parent
        {
            get;
            set;
        }

        string Group
        {
            get;
        }

        string Name
        {
            get;
        }             
      

        void Serialize(XmlElement node);
        void Deserialize(XmlElement node);        
    }

    // - Interface for filter;
	// In           Out
	// (x,y)    ->  (x,y)	
	// Calculate();

    public class PowderData
    {
        public readonly double LStart = 0.0;
        public readonly double LStop = 0.0;
        public readonly double LStep = 0.0;
        public readonly Single Alpha1 = 0.0F;
        public readonly Single Alpha2 = 0.0F;
        public readonly Single Ratio = 0.0F;

        public double[] y;
        
        private double[] _x = null;
        // Autocalcuation based on LStart, LStop, LStep varibles.
        public double[] x
        {
            get
            {

                if (_x == null)
                {
                    _x = new double[y.Length];
                    for (int i = 0; (i < y.Length); i++)
                    {
                        _x[i] = (double)((i * LStep) + LStart);
                    }
                }
                return _x;
            }
        }

        public static PowderData Clone(PowderData item)
        {
            return new PowderData(item.LStart, item.LStop, item.LStep, item.y, item.Alpha1, item.Alpha2, item.Ratio);
        }

        public PowderData(double LStart, double LStop, double LStep, double[] y, Single Alpha1, Single Alpha2, Single Ratio) 
        {
            this.LStart = LStart;
            this.LStop  = LStop;
            this.LStep  = LStep;
            this.y = y;
            this.Alpha1 = Alpha1;
            this.Alpha2 = Alpha2;
            this.Ratio = Ratio;
        }
    }

    public interface IPowFilter : IProjectSubitem
    {
        PowderData ApplayFilter(PowderData data);
    }



}
