﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing;
using System.Runtime.Serialization;
using ZedGraph;
using System.Xml.Serialization;

namespace Base
{

    [Serializable]
    public class Solution : IPropertiesEditable, ISelectable
    {
        #region Base Solution for files
        
        public event EventHandler TitleChanged;                        
        private string title ;
        
        [XmlIgnore]
        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                if (title != value)
                {
                    title = value;
                    if (TitleChanged != null)
                    {
                        TitleChanged(this, EventArgs.Empty);
                    }
                }
            }
        }            
        public event EventHandler<ObjModifeedEventArgs> Modified;
        
        
        public bool IsEmpty
        {
            get { return (PowderItems.Count + MolItems.Count) == 0; }
        }
        public int ItemsCount
        {
            get { return (PowderItems.Count + MolItems.Count);  }
        }
        public List<IProjectItem> Items
        {
            get 
            {
                List<IProjectItem> Itemf = new List<IProjectItem>();
               Itemf.AddRange(PowderItems.ToArray());
               Itemf.AddRange(MolItems.ToArray());
               return Itemf;
            } 
        }


        #endregion                
        
        private IGraphContent igc = null;
        
        public void SetIGC(IGraphContent igc)
        {
            this.igc = igc;
        }
        
        public Solution()
        {            
        }

        public Solution(IGraphContent igc):base()
        {
            this.igc = igc;
        }

        [NonSerialized]
        public List<PowderItem> PowderItems = new List<PowderItem>();

        [NonSerialized]
        public List<MolItem> MolItems = new List<MolItem>();

        public ISelectable SelectedItem
        {
            get
            {
                if (this.Selected == true) return null;
                foreach (PowderItem pi in PowderItems)
                {
                    if (pi.Selected) return (pi as IProjectItem);
                    // Check subitems
                    foreach (IProjectSubitem ps in pi.SubItems)
                    {
                        if (ps.Selected) return (ps as IProjectSubitem);
                    }
                }
                foreach (MolItem mi in MolItems)
                {
                    if (mi.Selected) return (mi as IProjectItem);
                    // Check subitems
                    foreach (IProjectSubitem ps in mi.SubItems)
                    {
                        if (ps.Selected) return (ps as IProjectSubitem);
                    }
                }
                return null;
            }
        }

        

        public event EventHandler<ProjectItemEventArgs> ItemAdded;        
        public event EventHandler<ProjectItemEventArgs> ItemRemoved;  
        public event EventHandler<ItemEventArgs> SelectionChanged;     
        public event EventHandler<ItemEventArgs> VisibleChanged;


        private bool _ItemsAutoGraphRange = true;
        public bool ItemsAutoGraphRange
        {
            get { return _ItemsAutoGraphRange; }
            set { _ItemsAutoGraphRange = value; }
        }

        private bool _ItemsAutoXRaySource = true;
        public bool ItemsAutoXRaySource
        {
            get { return _ItemsAutoXRaySource; }
            set { _ItemsAutoXRaySource = value; } 
        }

    
        public void CloseItems()
        {
            foreach (IProjectItem item in PowderItems)
            {
                item.Close();
            }
            foreach (IProjectItem item in MolItems)
            {
                item.Close();
            }
        }

        
        private double GraphLStart
        {
            get { return this.igc.ScaleXAxisMin; }
            set
            {
                igc.ScaleXAxisMin = value;
                foreach (IMolItem imi in MolItems)
                {
                    imi.pgo.LStart = value;                    
                }
            }
        }
        private double GraphLStop
        {
            get             
            {
                return igc.ScaleXAxisMax;
            }
            set 
            {
                igc.ScaleXAxisMax = value;                
                foreach (IMolItem imi in MolItems)
                {
                    imi.pgo.LStop = value;
                } 
            }
        }

        // Similar to previous except that only with one run;
        // Recalculation of simulated spectra will be done once
        private void SetGraphStartStop(double min, double max)
        {
            igc.ScaleXAxisMin = min;
            igc.ScaleXAxisMax = max;
            
            foreach (IMolItem imi in MolItems)
            {
                imi.pgo.setRange(igc.ScaleXAxisMin, igc.ScaleXAxisMax);
            }
        }

        private double MinStartPowderTheta()
        {
            if (PowderItems.Count == 0) throw new NullReferenceException("Incorect use of MinStartPowderTheta");
            
            double MinTheta = PowderItems[0].LStart;             
            foreach (IPowderItem pitem in PowderItems)
            {
               if (pitem.LStart < MinTheta) MinTheta = pitem.LStart;                    
            }
            return MinTheta;                        
        }

        private double MaxStartPowderTheta()
        {
            if (PowderItems.Count == 0) throw new NullReferenceException("Incorect use of MaxStartPowderTheta");

            double MaxTheta = PowderItems[0].LStart;
            foreach (IPowderItem pitem in PowderItems)
            {
                if (pitem.LStart > MaxTheta) MaxTheta = pitem.LStart;
            }
            return MaxTheta;                     
        }

        private double MinEndPowderTheta()
        {
            if (PowderItems.Count == 0) throw new NullReferenceException("Incorect use of MinStartPowderTheta");

            double MinTheta = PowderItems[0].LStop;
            foreach (IPowderItem pitem in PowderItems)
            {
                if (pitem.LStart < MinTheta) MinTheta = pitem.LStop;
            }
            return MinTheta; 
        }
        
        private double MaxEndPowderTheta()
        {
            if (PowderItems.Count == 0) throw new NullReferenceException("Incorect use of MaxEndPowderTheta");
            double MaxTheta = PowderItems[0].LStop;
            foreach (IPowderItem pitem in PowderItems)
            {
                if (pitem.LStart > MaxTheta) MaxTheta = pitem.LStop;
            }
            return MaxTheta;                                    
        }
               
        public double GeDefalutMinX()
        {
            if (PowderItems.Count > 0) return MaxStartPowderTheta();            
            return GraphLStart;            
        }

        public double GeDefalutMaxX()
        {
            if (PowderItems.Count > 0) return MinEndPowderTheta();
            return GraphLStop;
        }

        private XRaySource _DefalutXray = null;
        private XRaySource DefalutXray
        {
            get
            {
                if (_DefalutXray != null) return _DefalutXray;
                if (PowderItems.Count > 0)
                {
                    return new XRaySource(PowderItems[0].Alpha1);
                }
                return new XRaySource();                
            }
        }     


        /// <exception cref="ArgumentException">
        /// <paramref name="item"/> has been already added to the project.
        /// </exception>
        /// <exception cref="ArgumentNullException">
        /// <paramref name="item"/> is null.
        /// </exception>
        public void Add(IProjectItem item)
        {

            if (item == null) throw new ArgumentNullException("item");
            if (item is IPowderItem)
            {
                if (PowderItems.Contains(item as PowderItem)) throw new ArgumentException("The project already contains this item.");
            }
            else
            {
                if (MolItems.Contains(item as MolItem)) throw new ArgumentException("The project already contains this item.");
            }

            if (item is PowderItem)
            {
                PowderItem ipi = (PowderItem)item;
                // Graph Auto Range - ?
                if (ItemsAutoGraphRange)
                {
                    if (PowderItems.Count > 0)
                    {
                        double MinTheta = MinStartPowderTheta();
                        double MaxTheta = MaxEndPowderTheta();                       
                        if ((MinTheta<ipi.LStart)|(MaxTheta>ipi.LStop))
                        {
                            if (ipi.LStart < MinTheta) MinTheta = ipi.LStart;
                            if (ipi.LStop > MaxTheta) MaxTheta = ipi.LStop;
                            SetGraphStartStop(ipi.LStart,ipi.LStop);
                        }
                    }
                    else
                    {
                        SetGraphStartStop(ipi.LStart,ipi.LStop);
                    }
                }
                // Inform user if different radiation
                if (ItemsAutoXRaySource)
                {
                    if (PowderItems.Count > 0)
                    {
                        bool same = true;
                        foreach (IPowderItem pitem in PowderItems)
                        {
                            if (Math.Abs(pitem.Alpha1 - ipi.Alpha1) > 0.01) same = false;
                        }
                        if (!same) MessageBox.Show("X-ray source of two spectra is different", "Warning");
                    }
                    else
                    {                        
                        // Convert and check Sources of Simulated X-Ray
                        if (MolItems.Count > 0)
                        {                            
                            bool sources_equal = true;
                            XRaySource xrc = new XRaySource(ipi.Alpha1);
                            foreach (MolItem imi in MolItems)
                            {
                                if (!imi.pgo.Source.Equals(xrc)) sources_equal = false;
                            }                            

                            if (!sources_equal)
                            {
                                MessageBox.Show("New X-Ray Source will be applay to simulated spectra", "Warning");

                                foreach (IMolItem imi in MolItems)
                                {
                                    imi.pgo.Source = xrc;
                                }
                            }
                        }
                    }
                }
                PowderItems.Add(ipi);
            }
            else
            {
                //::TODO:: Load defalut setings from xml setings file
                PowderGeneratorOptions pgo = new PowderGeneratorOptions();
                pgo.LStart = GraphLStart;
                pgo.LStop = GraphLStop;
                pgo.Source = DefalutXray; //(From Powder Patern)

                IMolItem imi = item as IMolItem;
                imi.pgo = pgo;
                // Generate powder spectra now. 
                imi.GeneratePowder();

                MolItems.Add(item as MolItem);
            }


            AttachItemEvents(item);

            OnItemAdded(new ProjectItemEventArgs(item));

            // Redraw content
            OnModified(this, new ObjModifeedEventArgs(this, false, true));

            item.Selected = true;
        }

        private void AttachItemEvents(IProjectItem item)
        {
            item.Parent = this;

            item.Modified += new EventHandler<ObjModifeedEventArgs>(item_Modified);
            item.SelectionChanged += new EventHandler<ItemEventArgs>(item_SelectionChanged);
            item.VisibleChanged += new EventHandler<ItemEventArgs>(item_VisibleChanged);
        }

        private void DetachItemEvents(IProjectItem item)
        {
            item.Parent = null;

            item.Modified -= new EventHandler<ObjModifeedEventArgs>(item_Modified);
            item.SelectionChanged -= new EventHandler<ItemEventArgs>(item_SelectionChanged);
            item.VisibleChanged -= new EventHandler<ItemEventArgs>(item_VisibleChanged);
        }


        void item_Modified(object sender, ObjModifeedEventArgs e)
        {
            OnModified(this,e);
        }
        
        public void Remove(IProjectItem item)
        {
            if (item == null) throw new ArgumentNullException("item");

            if (item is PowderItem)
            {
                if (!PowderItems.Contains(item as PowderItem)) throw new ArgumentException("The project already contains this item.");
            }
            else
            {
                if (!MolItems.Contains(item as MolItem)) throw new ArgumentException("The project already contains this item.");
            }
           

            item.Close();
            DetachItemEvents(item);


            if (item is PowderItem)
            {
                PowderItems.Remove(item as PowderItem);
            }
            else
            {
                MolItems.Remove(item as MolItem);
            }

            OnItemRemoved(new ProjectItemEventArgs(item));

            OnModified(this, new ObjModifeedEventArgs(this, false, true));
        }

        private void OnModified(object sender, ObjModifeedEventArgs e)
        {
            if (Modified != null) Modified(this, e);
        }
       
        void item_SelectionChanged(object sender, ItemEventArgs e)
        {
            OnSelectionChanged(e);            
        }

        void item_VisibleChanged(object sender, ItemEventArgs e)
        {
            OnVisibleChanged(e);
        }
      
        private void OnItemAdded(ProjectItemEventArgs e)
        {
            if (ItemAdded != null) ItemAdded(this, e);
        }

        private void OnItemRemoved(ProjectItemEventArgs e)
        {
            if (ItemRemoved != null) ItemRemoved(this, e);
        }

        private void OnSelectionChanged(ItemEventArgs e)
        {                            
            if (SelectionChanged != null) SelectionChanged(this, e);
        }

        private void OnVisibleChanged(ItemEventArgs e)
        {                      
            if (VisibleChanged != null) VisibleChanged(this, e);
        }
               
        public void Draw(IGraphContent GraphContent)
        {            
            foreach (IPowderItem ipi in PowderItems)
            {
                if (!ipi.Visible) { continue; }                              
                ILineItem ili = GraphContent.DrawCurve(ipi as IPowderGraph, ipi.LineColor);
                ipi.LineTag = ili;
            }
            
            foreach (IMolItem imi in MolItems)
            {
                ILineItem ili = GraphContent.DrawCurve(imi as IPowderGraph, imi.LineColor);
                ITicsSet its  = GraphContent.DrawTics((imi as IPowderGraph).tics, imi.MainTicsColor, imi.AbsenceTicsColor, imi.ShowMainTics, imi.ShowMainTics);
                imi.LineTag = ili;
                imi.TicsSet = its;
            }
        }
                
        public object ObjProperties
        {
            get 
            {
                //return this.igc.Properties;
                return new SolutionProperties(this);
            }
        }
                               
        public System.Windows.Forms.Control PropertiesControl
        {
            get { return null; }
        }

                
        #region ISelectable Members
        
        private bool _Selected = false;
     
        public bool Selected
        {
            get
            {
                return _Selected;
            }
            set
            {                
                _Selected = value;
                if (value == true)
                {
                    OnSelectionChanged(new ItemEventArgs(this));
                }
            }
        }




        #endregion

        #region private class SolutionProperties

        
        [TypeConverter(typeof(PropertySorter))]
        class SolutionProperties : FilterablePropertyBase
        {
           
            [BrowsableAttribute(false), DefaultValueAttribute(false)]
            Solution sln;

            [BrowsableAttribute(false), DefaultValueAttribute(false)]
            public GraphPane graphPane
            {
                get
                {
                    if (sln == null) return null;
                    return sln.igc.ZGC.GraphPane;
                }
            }
            
            [BrowsableAttribute(false), DefaultValueAttribute(false)]
            public ZedGraphControl zgc
            {
                get 
                {
                    if (sln == null) return null;
                    return sln.igc.ZGC; 
                }                
            }

            public GraphProperties Properties            
            {
                get
                {
                    return sln.igc.Properties;
                }
            }


            private void InvalidateControl()
            {
                sln.OnModified(this,new ObjModifeedEventArgs(this,false,false)); 
                sln.igc.DoInvadiate();
            }

            [PropertyOrder(10), DisplayName("Title"), CategoryAttribute("General"), DescriptionAttribute("Project Title")]            
            public string Title
            {
                get { return sln.Title; }
                set
                {
                    // Validation
                    if (value == null)
                    {
                        MessageBox.Show("Can not set Empty value for project name");
                        return;
                    }
                    if (value == "")
                    {
                        MessageBox.Show("Can not set Empty value for project name");
                        return;
                    }
                    sln.Title = value;
                }
            }

            [PropertyOrder(20), DisplayName("2 Theta: Start"), CategoryAttribute("General"), DescriptionAttribute("X axis Start")]
            public double GraphStart
            {
                get 
                {                    
                    return Properties.GraphStart;
                }
                set 
                {
                    if (value < 0)
                    {
                        MessageBox.Show("Min X Axis value can not be negative");
                    }
                    if (value >180)
                    {
                        MessageBox.Show("Min X Axis value can not be heigher than 90");
                        return;
                    }
                    if (value > GraphEnd)
                    {
                        MessageBox.Show("Min X can not be biger than Max X = " + GraphEnd.ToString());
                        return;
                    }
                    Properties.GraphStart = value;                                
                }
            }

            [PropertyOrder(30), DisplayName("2 Theta: Finish"), CategoryAttribute("General"), DescriptionAttribute("X axis End")]
            public double GraphEnd
            {
                get 
                {
                    return Properties.GraphEnd;                        
                }
                set 
                {
                    if (value < 0)
                    {
                        MessageBox.Show("Max X Axis value can not be negative");
                    }
                    if (value > 180)
                    {
                        MessageBox.Show("Max X Axis value can not be heigher than 90");
                        return;
                    }
                    if (value < GraphStart)
                    {
                        MessageBox.Show("Max X can not be biger than Max X = " + GraphStart.ToString());
                        return;
                    
                    }
                    Properties.GraphEnd = value;
                }
            }

            [PropertyOrder(40), DisplayName("Font"), CategoryAttribute("General"), DescriptionAttribute("Font of Graph")]
            public Font Font
            {
                get
                {
                    FontFamily ff = new FontFamily(graphPane.XAxis.Scale.FontSpec.Family.ToString());
                    if (ff == null) ff = new FontFamily("Arial");
                    Font f = new Font(graphPane.XAxis.Scale.FontSpec.Family, graphPane.XAxis.Scale.FontSpec.Size);
                    return f;                    
                }
                set
                {
                    graphPane.XAxis.Scale.FontSpec.Family = value.FontFamily.Name;
                    graphPane.XAxis.Scale.FontSpec.Size = value.Size;

                    graphPane.YAxis.Scale.FontSpec.Family = value.FontFamily.Name;
                    graphPane.YAxis.Scale.FontSpec.Size = value.Size;
                    InvalidateControl();
                }
            }

            [PropertyOrder(50), DisplayName("MarginAll"), CategoryAttribute("General"), DescriptionAttribute("Margin of Main Graph")]
            public Padding Margin
            {
                get
                {
                    Padding p = new Padding((int)graphPane.Margin.Left, (int)graphPane.Margin.Top, (int)graphPane.Margin.Right, (int)graphPane.Margin.Bottom);
                    return p;
                }
                set
                {
                    graphPane.Margin.Left = value.Left;
                    graphPane.Margin.Top = value.Top;
                    graphPane.Margin.Right = value.Right;
                    graphPane.Margin.Bottom = value.Bottom;
                    InvalidateControl();
                }
            }

            [PropertyOrder(60), DisplayName("X Axis Visible"), CategoryAttribute("General"), DescriptionAttribute("Show/Hide X Axis")]
            public bool XAxisIsVisible
            {
                get
                {
                    return graphPane.XAxis.IsVisible;
                }
                set
                {
                    graphPane.XAxis.IsVisible = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(70), DisplayName("Y Axis Visible"), CategoryAttribute("General"), DescriptionAttribute("Show/Hide Y Axis")]
            public bool YAxisIsVisible
            {
                get
                {
                    return graphPane.YAxis.IsVisible;
                }
                set
                {
                    graphPane.YAxis.IsVisible = value;
                    InvalidateControl();
                }
            }


      
            #region ZedGraph Properties

            [PropertyOrder(80), DisplayName("Visible"), CategoryAttribute("MajorGrid X"), DescriptionAttribute("Is MajorGrid visible")]            
            public bool XAxisMajorGridIsVisible
            {
                get
                {
                    return graphPane.XAxis.MajorGrid.IsVisible;
                }
                set
                {
                    graphPane.XAxis.MajorGrid.IsVisible = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(90), DisplayName("Color"), CategoryAttribute("MajorGrid X"), DescriptionAttribute("MajorGrid X Color")]
            [DynamicPropertyFilter("XAxisMajorGridIsVisible", "True")]
            public Color XAxisMMajorGridColor
            {
                get
                {
                    return graphPane.XAxis.MajorGrid.Color;
                }
                set
                {
                    graphPane.XAxis.MajorGrid.Color = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(100), DisplayName("Dash Size"), CategoryAttribute("MajorGrid X"), DescriptionAttribute("MajorGrid dash Size")]
            [DynamicPropertyFilter("XAxisMajorGridIsVisible", "True")]
            public float XAxisMajorGridDashOn
            {
                get
                {
                    return graphPane.XAxis.MajorGrid.DashOn;
                }
                set
                {
                    graphPane.XAxis.MajorGrid.DashOn = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(110), DisplayName("Dash Interval"), CategoryAttribute("MajorGrid X"), DescriptionAttribute("MajorGrid Interval betwean dash")]
            [DynamicPropertyFilter("XAxisMajorGridIsVisible", "True")]
            public float XAxisMajorGridDashOff
            {
                get
                {
                    return graphPane.XAxis.MajorGrid.DashOff;
                }
                set
                {
                    graphPane.XAxis.MajorGrid.DashOff = value;
                    InvalidateControl();
                }
            }



            [PropertyOrder(120), DisplayName("Visible"), CategoryAttribute("MinorGrid X"), DescriptionAttribute("Is MinorGrid visible")]
            public bool XAxisMinorGridIsVisible
            {
                get
                {
                    return graphPane.XAxis.MinorGrid.IsVisible;
                }
                set
                {
                    graphPane.XAxis.MinorGrid.IsVisible = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(130), DisplayName("Color"), CategoryAttribute("MinorGrid X"), DescriptionAttribute("MinorGrid X Color")]
            [DynamicPropertyFilter("XAxisMinorGridIsVisible", "True")]
            public Color XAxisMMinorGridColor
            {
                get
                {
                    return graphPane.XAxis.MinorGrid.Color;
                }
                set
                {
                    graphPane.XAxis.MinorGrid.Color = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(140), DisplayName("Dash Size"), CategoryAttribute("MinorGrid X"), DescriptionAttribute("MinorGrid Dash Size")]
            [DynamicPropertyFilter("XAxisMinorGridIsVisible", "True")]
            public float XAxisMinorGridDashOn
            {
                get
                {
                    return graphPane.XAxis.MinorGrid.DashOn;
                }
                set
                {
                    graphPane.XAxis.MinorGrid.DashOn = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(150), DisplayName("Dash Interval"), CategoryAttribute("MinorGrid X"), DescriptionAttribute("MinorGrid Interval betwean dash")]
            [DynamicPropertyFilter("XAxisMinorGridIsVisible", "True")]
            public float XAxisMinorGridDashOff
            {
                get
                {
                    return graphPane.XAxis.MinorGrid.DashOff;
                }
                set
                {
                    graphPane.XAxis.MinorGrid.DashOff = value;
                    InvalidateControl();
                }
            }



            [PropertyOrder(160), DisplayName("Visible"), CategoryAttribute("MajorGrid Y"), DescriptionAttribute("Is MajorGrid visible")]
            public bool YAxisMajorGridIsVisible
            {
                get
                {
                    return graphPane.YAxis.MajorGrid.IsVisible;
                }
                set
                {
                    graphPane.YAxis.MajorGrid.IsVisible = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(170), DisplayName("Color"), CategoryAttribute("MajorGrid Y"), DescriptionAttribute("MajorGrid Y Color")]
            [DynamicPropertyFilter("YAxisMajorGridIsVisible", "True")]
            public Color YAxisMMajorGridColor
            {
                get
                {
                    return graphPane.YAxis.MajorGrid.Color;
                }
                set
                {
                    graphPane.YAxis.MajorGrid.Color = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(180), DisplayName("Dash Size"), CategoryAttribute("MajorGrid Y"), DescriptionAttribute("MajorGrid dash Size")]
            [DynamicPropertyFilter("YAxisMajorGridIsVisible", "True")]
            public float YAxisMajorGridDashOn
            {
                get
                {
                    return graphPane.YAxis.MajorGrid.DashOn;
                }
                set
                {
                    graphPane.YAxis.MajorGrid.DashOn = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(190), DisplayName("Dash Interval"), CategoryAttribute("MajorGrid Y"), DescriptionAttribute("MajorGrid Interval betwean dash")]
            [DynamicPropertyFilter("YAxisMajorGridIsVisible", "True")]
            public float YAxisMajorGridDashOff
            {
                get
                {
                    return graphPane.YAxis.MajorGrid.DashOff;
                }
                set
                {
                    graphPane.YAxis.MajorGrid.DashOff = value;
                    InvalidateControl();
                }
            }



            [PropertyOrder(200), DisplayName("Visible"), CategoryAttribute("MinorGrid Y"), DescriptionAttribute("Is MinorGrid visible")]
            public bool YAxisMinorGridIsVisible
            {
                get
                {
                    return graphPane.YAxis.MinorGrid.IsVisible;
                }
                set
                {
                    graphPane.YAxis.MinorGrid.IsVisible = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(210), DisplayName("Color"), CategoryAttribute("MinorGrid Y"), DescriptionAttribute("MinorGrid Y Color")]
            [DynamicPropertyFilter("YAxisMinorGridIsVisible", "True")]
            public Color YAxisMMinorGridColor
            {
                get
                {
                    return graphPane.YAxis.MinorGrid.Color;
                }
                set
                {
                    graphPane.YAxis.MinorGrid.Color = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(220), DisplayName("Dash Size"), CategoryAttribute("MinorGrid Y"), DescriptionAttribute("MinorGrid Dash Size")]
            [DynamicPropertyFilter("YAxisMinorGridIsVisible", "True")]
            public float YAxisMinorGridDashOn
            {
                get
                {
                    return graphPane.YAxis.MinorGrid.DashOn;
                }
                set
                {
                    graphPane.YAxis.MinorGrid.DashOn = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(230), DisplayName("Dash Interval"), CategoryAttribute("MinorGrid Y"), DescriptionAttribute("MinorGrid Interval betwean dash")]
            [DynamicPropertyFilter("YAxisMinorGridIsVisible", "True")]
            public float YAxisMinorGridDashOff
            {
                get
                {
                    return graphPane.YAxis.MinorGrid.DashOff;
                }
                set
                {
                    graphPane.YAxis.MinorGrid.DashOff = value;
                    InvalidateControl();
                }
            }





            [PropertyOrder(240), DisplayName("Color"), CategoryAttribute("Tic"), DescriptionAttribute("Tic's Color")]
            public Color XAxisTicColor
            {
                get
                {
                    return graphPane.XAxis.MajorTic.Color;
                }
                set
                {
                    graphPane.XAxis.MajorTic.Color = value;
                    graphPane.XAxis.MinorTic.Color = value;
                    graphPane.YAxis.MajorTic.Color = value;
                    graphPane.YAxis.MinorTic.Color = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(250), DisplayName("Visible Opposite Major"), CategoryAttribute("Tic"), DescriptionAttribute("Show/Hide major Tics oposite")]
            public bool XAxisIsMajorOpposite
            {
                get
                {
                    return graphPane.XAxis.MajorTic.IsOpposite;
                }
                set
                {
                    graphPane.XAxis.MajorTic.IsOpposite = value;
                    graphPane.YAxis.MajorTic.IsOpposite = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(260), DisplayName("Visible Opposite Minor "), CategoryAttribute("Tic"), DescriptionAttribute("Show/Hide minor Tics on top")]
            public bool XAxisIsMinorOpposite
            {
                get
                {
                    return graphPane.XAxis.MinorTic.IsOpposite;
                }
                set
                {
                    graphPane.XAxis.MinorTic.IsOpposite = value;
                    graphPane.YAxis.MinorTic.IsOpposite = value;
                    InvalidateControl();
                }
            }


            [PropertyOrder(270), DisplayName("Visible Major Y"), CategoryAttribute("Tic"), DescriptionAttribute("Major Tics Visible")]
            public bool YAxisTicMajorVisible
            {
                get
                {
                    return graphPane.YAxis.MajorTic.IsInside;
                }
                set
                {
                    graphPane.YAxis.MajorTic.IsInside = value;
                    if (value == false)
                    {
                        graphPane.YAxis.MajorTic.IsOpposite = false;
                    }
                    InvalidateControl();
                }
            }

            [PropertyOrder(280), DisplayName("Visible Minor Y"), CategoryAttribute("Tic"), DescriptionAttribute("Minor Tics Visible")]
            public bool YAxisTicMinorVisible
            {
                get
                {
                    return graphPane.YAxis.MinorTic.IsInside;
                }
                set
                {
                    graphPane.YAxis.MinorTic.IsInside = value;
                    if (value == false)
                    {
                        graphPane.YAxis.MinorTic.IsOpposite = false;
                    }
                    InvalidateControl();
                }
            }


            [PropertyOrder(290), DisplayName("Size Major X"), CategoryAttribute("Tic"), DescriptionAttribute("Major Tics Size")]
            public float XAxisTicMajorSize
            {
                get
                {
                    return graphPane.XAxis.MajorTic.Size;
                }
                set
                {
                    graphPane.XAxis.MajorTic.Size = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(300), DisplayName("Size Major Y"), CategoryAttribute("Tic"), DescriptionAttribute("Major Tics Size")]
            public float YAxisTicMajorSize
            {
                get
                {
                    return graphPane.YAxis.MajorTic.Size;
                }
                set
                {
                    graphPane.YAxis.MajorTic.Size = value;
                    InvalidateControl();
                }
            }


            [PropertyOrder(310), DisplayName("Size Minor X"), CategoryAttribute("Tic"), DescriptionAttribute("Minor Tics Size")]
            public float XAxisTicMinorSize
            {
                get
                {
                    return graphPane.XAxis.MinorTic.Size;
                }
                set
                {                    
                    graphPane.XAxis.MinorTic.Size = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(320), DisplayName("Size Minor Y"), CategoryAttribute("Tic"), DescriptionAttribute("Minor Tics Size")]
            public float YAxisTicMinorSize
            {
                get
                {
                    return graphPane.YAxis.MinorTic.Size;
                }
                set
                {
                    graphPane.YAxis.MinorTic.Size = value;
                    InvalidateControl();
                }
            }


            [PropertyOrder(330), DisplayName("Visible X"), CategoryAttribute("Title"), DescriptionAttribute("MajorTic X Color")]
            public bool XAxisTitleIsVisible
            {
                get
                {
                    return graphPane.XAxis.Title.IsVisible;
                }
                set
                {
                    graphPane.XAxis.Title.IsVisible = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(340), DisplayName("Text X"), CategoryAttribute("Title"), DescriptionAttribute("MajorTic X Color")]
            [DynamicPropertyFilter("XAxisTitleIsVisible", "True")]
            public string XAxisTitleText
            {
                get
                {
                    return graphPane.XAxis.Title.Text;
                }
                set
                {
                    graphPane.XAxis.Title.Text = value;
                    InvalidateControl();
                }
            }


            [PropertyOrder(350), DisplayName("Visible Y"), CategoryAttribute("Title"), DescriptionAttribute("MajorTic Y Color")]
            public bool YAxisTitleIsVisible
            {
                get
                {
                    return graphPane.YAxis.Title.IsVisible;
                }
                set
                {
                    graphPane.YAxis.Title.IsVisible = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(360), DisplayName("Text Y"), CategoryAttribute("Title"), DescriptionAttribute("MajorTic Y Color")]
            [DynamicPropertyFilter("YAxisTitleIsVisible", "True")]
            public string YAxisTitleText
            {
                get
                {
                    return graphPane.YAxis.Title.Text;
                }
                set
                {
                    graphPane.YAxis.Title.Text = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(370), DisplayName("FontSize"), CategoryAttribute("Title"), DescriptionAttribute("MajorTic Y Color")]
            public float YAxisTitleFontSpec
            {
                get
                {
                    return graphPane.YAxis.Title.FontSpec.Size;
                }
                set
                {
                    graphPane.YAxis.Title.FontSpec.Size = value;
                    graphPane.XAxis.Title.FontSpec.Size = value;
                    InvalidateControl();
                }
            }


            [PropertyOrder(380), DisplayName("Y Numbers Visible"), CategoryAttribute("YAxis"), DescriptionAttribute("Show/Hide Y Axis Numbers")]
            public bool YAxisScaleIsVisible
            {
                get
                {
                    return graphPane.YAxis.Scale.IsVisible;
                }
                set
                {
                    graphPane.YAxis.Scale.IsVisible = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(390), DisplayName("Y Major Step"), CategoryAttribute("YAxis"), DescriptionAttribute("Spep of Y Major Steps")]
            [DynamicPropertyFilter("YAxisScaleIsVisible", "True")]
            public double YAxisScaleMajorStep
            {
                get
                {
                    return graphPane.YAxis.Scale.MajorStep;
                }
                set
                {
                    graphPane.YAxis.Scale.MajorStep = value;
                    InvalidateControl();
                }
            }

            [PropertyOrder(400), DisplayName("Y Minor Step"), CategoryAttribute("YAxis"), DescriptionAttribute("Spep of Y Minor Steps")]
            [DynamicPropertyFilter("YAxisScaleIsVisible", "True")]
            public double YAxisScaleMinorStepStep
            {
                get
                {
                    return graphPane.YAxis.Scale.MinorStep;
                }
                set
                {
                    graphPane.YAxis.Scale.MinorStep = value;
                    InvalidateControl();
                }
            }


            #endregion        
            
            public SolutionProperties(Solution sln)
            {

                this.sln = sln;
            }
        }

        #endregion


        //[OnDeserialized]
        // Not Supported By XML
        internal void DeserializationFinish()
        {
            // Set parent to all Items
            foreach (PowderItem pi in PowderItems)
            {             
                AttachItemEvents(pi);
                pi.DeserializationFinish();
            }
            foreach (MolItem mi in MolItems)
            {                
                AttachItemEvents(mi);
                mi.DeserializationFinish();
            }            
        }
    }
    

}


