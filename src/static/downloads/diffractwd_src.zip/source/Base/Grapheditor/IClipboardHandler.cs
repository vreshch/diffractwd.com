﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/


using System;

namespace Base
{
	public interface IClipboardHandler
	{
		bool CanPaste { get; }
		void Paste();
		
		bool CanCut { get; }
		void Cut();
		
		bool CanCopy { get; }
		void Copy();
		
		bool CanDelete { get; }
		void Delete();
	}
}
