﻿/*-------------------------------------------------------------------
DiffractWD  Program for basic manipulation with powder patterns.
Copyright (c) 2010, Volodimir Vreshch
All rights reserved.
Email : vreshch@DiffractWD.com

You  should  have  received  a copy of the BSD License along with this
program. If not, see <http://diffractwd.com/license.html>.
---------------------------------------------------------------------*/


using System.Reflection;
using System.Runtime.CompilerServices;

// Information about this assembly is defined by the following
// attributes.
//
// change them to the information which is associated with the assembly
// you compile.

[assembly: AssemblyTitle("Base")]
[assembly: AssemblyDescription("Base AddIn for DiffractWD")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Diffract code")]
[assembly: AssemblyProduct("DiffractWD")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// The assembly version has following format :
//
// Major.Minor.Build.Revision
//
// You can specify all values by your own or you can build default build and revision
// numbers with the '*' character (the default):

//[assembly: AssemblyVersion("1.0.*")]

[assembly: AssemblyVersionAttribute("1.0.0.1")]
[assembly: AssemblyFileVersionAttribute("1.0.0.1")]
